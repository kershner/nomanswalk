# This contains a collection of in-game engine related functions, modified to be easier to call directly.

import ctypes

import nmspy.data.basic_types as basic
from nmspy.data.types import Engine


def GetNodeAbsoluteTransMatrix(node: basic.TkHandle) -> basic.cTkMatrix34:
    """Disabled on Cosmos: the native output ABI is not yet mapped safely."""
    raise RuntimeError("GetNodeAbsoluteTransMatrix is disabled for Cosmos")


def GetNodePositions(node: basic.TkHandle) -> tuple[basic.Vector3f, basic.Vector3f]:
    """Return a node's local and absolute Cosmos position vectors."""
    local_position = basic.Vector3f(0, 0, 0)
    absolute_position = basic.Vector3f(0, 0, 0)
    Engine.GetNodePositions(
        ctypes.c_uint32(int(node.lookupInt)),
        ctypes.byref(local_position),
        ctypes.byref(absolute_position),
    )
    return local_position, absolute_position


def GetNodeAbsolutePosition(node: basic.TkHandle) -> basic.Vector3f:
    """Return a node's absolute position through Cosmos's position-only API."""
    return GetNodePositions(node)[1]


def ShiftAllTransformsForNode(node: basic.TkHandle, shift: basic.Vector3f):
    """Shift all transforms for the provided node handle."""
    Engine.ShiftAllTransformsForNode(node, ctypes.byref(shift))
