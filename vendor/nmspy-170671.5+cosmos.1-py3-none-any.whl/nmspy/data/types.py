import ctypes.wintypes as wintypes
import types
from contextlib import contextmanager
from ctypes import (
    POINTER,
    _Pointer,
    c_bool,
    c_char,
    c_char_p,
    c_double,
    c_float,
    c_int16,
    c_int32,
    c_int64,
    c_ubyte,
    c_uint8,
    c_uint16,
    c_uint32,
    c_uint64,
    c_void_p,
    cast,
)
from enum import IntEnum
from logging import getLogger
from typing import TYPE_CHECKING, Annotated, Generator, Generic, Optional, Type, TypeVar

from pymhf.core.hooking import Structure, function_hook, static_function_hook
from pymhf.core.memutils import _get_memview_with_size
from pymhf.core.structs import ContainerStruct, Field, Pattern, partial_struct
from pymhf.extensions.cpptypes import std
from pymhf.extensions.ctypes import c_char_p64, c_enum8, c_enum16, c_enum32
from pymhf.utils.winapi import get_filepath_from_handle

import nmspy.data.basic_types as basic
import nmspy.data.enums as enums
import nmspy.data.exported_types as nmse
import nmspy.data.vulkan as vulkan

T = TypeVar("T", bound=basic.CTYPES)

# Exported functions


logger = getLogger(__name__)


class cGcInteractionData(nmse.cGcInteractionData):
    @function_hook("66 0F 6F 05 ? ? ? ? 33 C0 0F 11 01 48 89 41 ? 48 89 41 ? C3")
    def SetDefaults(self, this: "_Pointer[cGcInteractionData]"): ...


@partial_struct
class cTkSmartResHandle(Structure):
    # This field is technically another type which just contains an int field, so we'll simplify it.
    miInternalHandle: Annotated[int, Field(c_int32, 0x0)]


class cTkTypedSmartResHandle(Structure, Generic[T]):
    _template_type: Type[T]
    mHandle: cTkSmartResHandle
    if TYPE_CHECKING:
        mpPointer: _Pointer[T]

    def __class_getitem__(cls: Type["cTkTypedSmartResHandle"], type_: Type[T]):
        _cls: Type[cTkTypedSmartResHandle[T]] = types.new_class(f"cTkTypedSmartResHandle<{type_}>", (cls,))
        _cls._template_type = type_
        _cls._fields_ = [  # type: ignore
            ("mHandle", cTkSmartResHandle),
            ("_padding0x4", c_ubyte * 4),
            ("mpPointer", POINTER(type_)),
        ]
        return _cls


class cTkRefCntContainer(Structure, Generic[T]):
    mRef: Annotated[int, c_int32]
    _template_type: Type[T]
    if TYPE_CHECKING:
        mPtr: _Pointer[T]

    def __class_getitem__(cls: Type["cTkRefCntContainer"], type_: Type[T]):
        _cls: Type[cTkRefCntContainer[T]] = types.new_class(f"cTkRefCntContainer<{type_}>", (cls,))
        _cls._template_type = type_
        _cls._fields_ = [  # type: ignore
            ("mPtr", POINTER(type_)),
            ("mRef", c_int32),
        ]
        return _cls


class cTkSharedPtr(Structure, Generic[T]):
    _template_type: Type[T]
    if TYPE_CHECKING:
        mRefCntr: _Pointer[cTkRefCntContainer[T]]

    def __class_getitem__(cls: Type["cTkSharedPtr"], type_: Type[T]):
        _cls: Type[cTkSharedPtr[T]] = types.new_class(f"cTkSharedPtr<{type_}>", (cls,))
        _cls._template_type = type_
        _cls._fields_ = [  # type: ignore
            ("mRefCntr", POINTER(cTkRefCntContainer[type_])),
        ]
        return _cls


@partial_struct
class FIOS2HANDLE(Structure):
    mFH: Annotated[int, Field(c_uint32)]

    @property
    def filename(self) -> str:
        return get_filepath_from_handle(self.mFH)


class XMLNode(Structure):
    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 41 0F B6 E8 48 8B FA")
    def createXMLTopNode(
        self,
        result: "_Pointer[XMLNode]",
        lpszName: c_uint64,
        isDeclaration: Annotated[bool, c_bool],
    ) -> c_uint64:  # XMLNode *
        ...

    @function_hook("40 53 57 41 54 41 56 41 57 48 81 EC")
    def writeToFile(
        self,
        this: "_Pointer[XMLNode]",
        filename: c_char_p64,
        encoding: c_char_p64,
        nFormat: c_uint8,
    ) -> c_uint64:
        # Writes the XMLNode to file. Return value is an integer indicating some status.
        # Return values are 0, 14 and 15.
        ...


@static_function_hook(
    "48 89 5C 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? B8"
)
def MiniDumpFunction(a1: c_uint64, a2: c_uint64, CurrentThreadId: wintypes.DWORD) -> c_uint64: ...


@partial_struct
class cTkResourceDescriptor(Structure):
    maDescriptors: Annotated[basic.TkStd.tk_vector[basic.TkID0x20], 0x0]
    mSeed: Annotated[basic.cTkSeed, 0x10]
    mSecondarySeed: Annotated[basic.cTkSeed, 0x20]


@partial_struct
class cTkResource(Structure):
    _total_size_ = 0x1C0  # ?
    # __vftable: Annotated[c_uint64, Field(c_uint64, 0)]
    # Found in cTkResource::cTkResource and cEgGeometryResource::cEgGeometryResource
    miType: Annotated[c_enum32[enums.ResourceTypes], 0x8]
    msName: Annotated[basic.cTkFixedString[0x100], 0xC]
    mxFlags: Annotated[int, Field(c_int32, 0x110)]
    mHandle: Annotated[int, Field(c_int32, 0x128)]
    muRefCount: Annotated[int, Field(c_int32, 0x12C)]
    mbNoQuery: Annotated[bool, Field(c_bool, 0x131)]
    mbReplaceWithDefault: Annotated[bool, Field(c_bool, 0x13B)]
    mDescriptor: Annotated[cTkResourceDescriptor, 0x188]  # TODO: Test
    muHotRequestNumber: Annotated[int, Field(c_uint16, 0x1B8)]

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? C6 41")
    def cTkResource(
        self,
        this: "_Pointer[cTkResource]",
        liType: Annotated[int, c_int32],
        lsName: _Pointer[basic.cTkFixedString0x100],
        lxFlags: Annotated[int, c_int32],
    ): ...


@partial_struct
class cEgRenderQueueEntry(Structure):
    mRenderSpaceTransform: Annotated[basic.cTkMatrix34, 0x0]


@partial_struct
class cEgRenderQueueBuffer(Structure):
    mpFinalBuffer: Annotated[_Pointer[cEgRenderQueueEntry], 0x0]
    muNumEntries: Annotated[int, Field(c_int32, 0x48)]
    muCapacity: Annotated[int, Field(c_int32, 0x48)]


@partial_struct
class TkGpuAddress(Structure):
    mBuffer: Annotated[_Pointer[vulkan.VkBuffer_T], 0x0]
    mOffset: Annotated[int, Field(c_uint64, 0x8)]


@partial_struct
class cTkRenderStateCache(Structure):
    # Offsets found in cEgRenderer::DrawMeshes above vkCmdBindIndexBuffer
    mSetIndexBuffer: Annotated[_Pointer[vulkan.VkBuffer_T], 0x2F8]
    mSetIndexOffset: Annotated[int, Field(c_uint64, 0x300)]
    mSetIndexType: Annotated[int, Field(c_uint32, 0x308)]
    mpBoundIndexData: Annotated[TkGpuAddress, 0x7E0]


@partial_struct
class cEgThreadableRenderCall(Structure):
    @partial_struct
    class cRendererData(Structure):
        _total_size_ = 0x290

    mRendererData: Annotated[cRendererData, 0x10]
    # Found in cEgRenderer::DrawMeshes at the top.
    mRenderStateCache: Annotated[cTkRenderStateCache, 0x290]
    _mpFunctionParams: Annotated[c_void_p, 0x2A0]

    @property
    def mpFunctionParams(self):
        return cast(self._mpFunctionParams, _Pointer[cEgDrawGeometry])


@partial_struct
class cEgDrawGeometry(Structure):
    # These are found in cEgDrawGeometry::Draw as arguments to cEgRenderer::DrawRenderables
    mNodeType: Annotated[_Pointer[basic.TkID0x10], 0x8]

    @static_function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ? 65 48 8B 04 25 ? ? ? ? 48 8D B1 ? ? ? "
        "? 48 8B BE ? ? ? ? 48 8B D9 48 8B 28 B8 ? ? ? ? 80 3C 28 ? 75 ? E8 ? ? ? ? B8 ? ? ? ? 48 89 34 28 "
        "80 BF ? ? ? ? ? 74 ? 48 8D 8F ? ? ? ? 41 B0 ? 33 D2 E8 ? ? ? ? 48 8B BB"
    )
    @staticmethod
    def Draw(
        lpData: _Pointer[cEgThreadableRenderCall],
        # Not sure if the following args are real...
        a2: c_uint64,
        a3: c_uint64,
        a4: c_uint64,
    ): ...


class AK(Structure):
    class SoundEngine(Structure):
        @static_function_hook(exported_name="?RegisterGameObj@SoundEngine@AK@@YA?AW4AKRESULT@@_KPEBD@Z")
        @staticmethod
        def RegisterGameObj(
            in_GameObj: c_uint64,
            in_pszObjName: c_uint64,
        ) -> c_int64: ...

        @static_function_hook(
            exported_name=(
                "?PostEvent@SoundEngine@AK@@YAII_KIP6AXW4AkCallbackType@@PEAUAkCallbackInfo@@@ZPEAXIPEAUAkExt"
                "ernalSourceInfo@@I@Z"
            )
        )
        @staticmethod
        def PostEvent(
            in_ulEventID: Annotated[int, c_uint32],
            in_GameObjID: Annotated[int, c_uint64],
            in_uiFlags: Annotated[int, c_uint32] = 0,
            callback: Annotated[int, c_uint64] = 0,
            in_pCookie: c_void_p = 0,
            in_cExternals: Annotated[int, c_uint32] = 0,
            in_pExternalSources: Annotated[int, c_uint64] = 0,
            in_PlayingID: Annotated[int, c_uint32] = 0,
        ) -> c_uint64: ...


@partial_struct
class cTkPersonalRNG(Structure):
    mState0: Annotated[int, Field(c_uint32)]
    mState1: Annotated[int, Field(c_uint32)]


@partial_struct
class TkAudioID(Structure):
    mpacName: Annotated[Optional[str], Field(c_char_p)]
    muID: Annotated[int, Field(c_uint32)]
    mbValid: Annotated[bool, Field(c_bool)]


@partial_struct
class cTkAudioManager(Structure):
    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 56 48 83 EC ? 48 8B F1 48 8B C2")
    def Play_attenuated(
        self,
        this: "_Pointer[cTkAudioManager]",
        event: _Pointer[TkAudioID],
        position: c_uint64,
        object: c_int64,
        attenuationScale: Annotated[float, c_float],
    ) -> c_bool: ...

    @function_hook("48 83 EC ? 33 C9 4C 8B D2 89 4C 24 ? 49 8B C0 48 89 4C 24 ? 45 33 C9")
    def Play(
        self,
        this: "_Pointer[cTkAudioManager]",
        event: _Pointer[TkAudioID],
        object: c_int64,
    ) -> c_bool: ...


@partial_struct
class cGcNGuiElement(Structure):
    class eLayoutChangeEvent(IntEnum):
        Nothing = 0x0
        PositionMode = 0x1
        WidthMode = 0x2
        HeightMode = 0x3
        ConstrainMode = 0x4
        Size = 0x5
        Width = 0x6
        Height = 0x7
        Value = 0x8
        ColourPreset = 0x9

    mpElementData: Annotated[_Pointer[nmse.cGcNGuiElementData], 0x48]
    meLayoutChangeEvent: Annotated[c_enum8[eLayoutChangeEvent], 0x51]

    @function_hook("48 83 EC ? 48 8B 41 ? 45 85 C0")
    def GetPosition(
        self,
        this: "_Pointer[cGcNGuiElement]",
        result: _Pointer[basic.Vector2f],
        lType: c_uint32,  # cGcNGuiElement::PositionType
    ) -> c_uint64:  # cTkVector2 *
        ...

    @function_hook("48 83 EC ? 4C 8B 59 ? 4C 8B D1")
    def SetPosition(
        self,
        this: "_Pointer[cGcNGuiElement]",
        lPosition: _Pointer[basic.Vector2f],
        lType: c_uint32,  # cGcNGuiElement::PositionType
    ): ...

    @function_hook("4C 8B DC 53 48 81 EC ? ? ? ? 49 89 6B ? 48 8B D9")
    def Render(self, this: "_Pointer[cGcNGuiElement]"): ...


@partial_struct
class cGcNGuiText(cGcNGuiElement):
    # Found in cGcNGuiText::EditElement
    mpTextData: Annotated[
        _Pointer[nmse.cGcNGuiTextData],
        Field(_Pointer[nmse.cGcNGuiTextData], 0x180),
    ]

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 55 41 54 41 55 41 56 41 57 48 81 EC ? ? ? ? 0F 29 70 ? 48 "
        "8D A8 ? ? ? ? 48 83 E5 ? 48 8B 01"
    )
    def EditElement(self, this: "_Pointer[cGcNGuiText]"): ...


@partial_struct
class cGcNGuiLayer(cGcNGuiElement):
    mapElements: Annotated[basic.TkStd.tk_vector[_Pointer[cGcNGuiElement]], 0x58]
    # mapLayerElements: Annotated[basic.TkStd.tk_vector[_Pointer[cGcNGuiLayer]], 0x58]
    mpLayerData: Annotated[_Pointer[nmse.cGcNGuiLayerData], 0x148]

    @function_hook(
        "48 83 EC ? 4C 8B 02 4C 8B C9 0F 10 02 49 8B C0 48 B9 ? ? ? ? ? ? ? ? 48 33 42 ? 48 0F AF C1 0F 11 "
        "44 24 ? 48 8B D0 48 C1 EA ? 48 33 D0 49 33 D0 48 0F AF D1 4C 8B C2 49 C1 E8 ? 4C 33 C2 4C 0F AF C1 "
        "41 0F B7 C8 41 8B D0 81 C1 ? ? ? ? C1 EA ? 8B C1 49 C1 E8 ? 81 E2 ? ? ? ? C1 E0 ? 33 D0 41 0F B7 C0 "
        "33 D1 41 C1 E8 ? 8B CA 41 81 E0 ? ? ? ? C1 E9 ? 03 D0 03 D1 8B C2 C1 E0 ? 44 33 C0 44 33 C2 41 8B "
        "C8 C1 E9 ? 41 03 C8 41 B8 ? ? ? ? 8D 14 CD ? ? ? ? 33 D1 8B CA C1 E9 ? 03 CA 8B D1 C1 E2 ? 33 D1 8B "
        "CA C1 E9 ? 03 CA 8B D1 C1 E2 ? 33 D1 8B C2 C1 E8 ? 03 C2 48 8D 54 24 ? 69 C0 ? ? ? ? C1 C8 ? 69 C8 "
        "? ? ? ? 83 F1 ? C1 C9 ? 8D 0C 89 81 C1 ? ? ? ? 48 89 4C 24 ? 49 8B C9 E8 ? ? ? ? 48 83 C4 ? C3 CC "
        "CC CC CC 0F B6 41"
    )
    def FindTextRecursive(
        self,
        this: "_Pointer[cGcNGuiLayer]",
        lID: c_uint64,
    ) -> c_uint64:  # cGcNGuiElement *
        ...

    @function_hook("40 55 57 41 57 48 83 EC ? 4C 8B 89")
    def FindElementRecursive(
        self,
        this: "_Pointer[cGcNGuiLayer]",
        lID: c_uint64,  # const cTkHashedNGuiElement *
        leType: c_uint32,  # eNGuiGameElementType
    ) -> c_uint64:  # cGcNGuiElement *
        ...

    @function_hook("48 8B C4 53 48 81 EC ? ? ? ? 48 89 78 ? 4C 8B D2")
    def LoadFromMetadata(
        self,
        this: "_Pointer[cGcNGuiLayer]",
        lpacFilename: _Pointer[basic.cTkFixedString[0x80]],
        lbUseCached: Annotated[bool, c_bool],
        a4: Annotated[bool, c_bool],
    ): ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 48 89 54 24 ? 57 48 81 EC ? ? ? ? 44 8B 51")
    def AddElement(
        self,
        this: "_Pointer[cGcNGuiLayer]",
        lpElement: "_Pointer[cGcNGuiLayer]",
        lbOnTheEnd: c_int64,
    ): ...

    @function_hook(
        "48 89 5C 24 ? 57 48 83 EC ? 4C 8B 89 ? ? ? ? 41 0F B6 F8 48 8B 0A 49 BA ? ? ? ? ? ? ? ? 48 8B C1 48 "
        "33 42 ? 49 0F AF C2 48 8B D0 48 C1 EA ? 48 33 D0 48 33 D1 49 0F AF D2 4C 8B C2 49 C1 E8 ? 4C 33 C2 "
        "4D 0F AF C2 41 8B D0 41 0F B7 C8 C1 EA ? 81 C1 ? ? ? ? 81 E2 ? ? ? ? 49 C1 E8 ? 8B C1 C1 E0 ? 33 D0 "
        "41 0F B7 C0 33 D1 41 C1 E8 ? 8B CA 41 81 E0 ? ? ? ? 03 D0 C1 E9 ? 03 D1 8B C2 C1 E0 ? 44 33 C0 44 "
        "33 C2 41 8B C8 C1 E9 ? 41 03 C8 8D 14 CD ? ? ? ? 33 D1 8B CA C1 E9 ? 03 CA 8B D1 C1 E2 ? 33 D1 8B "
        "CA C1 E9 ? 03 CA 8B D1 C1 E2 ? 33 D1 8B C2 C1 E8 ? 03 C2 69 C0 ? ? ? ? C1 C8 ? 69 C0 ? ? ? ? C1 C8"
    )
    def GetGraphic(
        self,
        this: "_Pointer[cGcNGuiLayer]",
        lID: _Pointer[basic.TkID0x10],
        lbUseDefault: Annotated[bool, c_bool],
    ) -> c_uint64:  # cGcNGuiGraphic *
        ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B F9 E8 ? ? ? ? 33 ED")
    def cGcNGuiLayer(self, this: "_Pointer[cGcNGuiLayer]"): ...


@partial_struct
class cGcNGui(Structure):
    mRoot: Annotated[cGcNGuiLayer, 0x0]


@partial_struct
class cTkNGuiElementID(Structure):
    # Assuming the same as 4.13
    miCounter: Annotated[int, Field(c_int64, 0x0)]
    miBase: Annotated[int, Field(c_uint64, 0x8)]
    miFrameRenderTracker: Annotated[int, Field(c_int32, 0x10)]
    miPerFrameUseCount: Annotated[int, Field(c_int32, 0x10)]


# class cTkUiDataMap(Structure, Generic[T]):
#     _template_type: Type[T]

#     maUiData: basic.TkStd.tk_vector[T]
#     maElementIndices: basic.TkStd.tk_vector[cTkNGuiElementID]

#     def __class_getitem__(cls: type["cTkUiDataMap"], key: T):
#         _cls: type["cTkUiDataMap"] = types.new_class(f"cTkUiDataMap<{key}>", (cls,))
#         _cls._template_type = key
#         _cls._fields_ = [
#             ("maUiData", basic.TkStd.tk_vector[key]),
#             ("maElementIndices", basic.TkStd.tk_vector[cTkNGuiElementID]),
#         ]
#         return _cls


class cTkNGuiElementData(Structure):
    pass


@partial_struct
class cTkNGui(Structure):
    # mElementDataMap: Annotated[cTkUiDataMap[cTkNGuiElementData], 0x70]
    # maLayerStack: Annotated[basic.TkStd.tk_vector[cTkNGuiLayer], 0xB8]

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 55 41 54 41 55 41 56 41 57 48 81 EC ? ? ? ? 0F 29 70 ? 0F "
        "29 78 ? 48 8D A8 ? ? ? ? 48 83 E5 ? F3 0F 10 0D"
    )
    def DoElement(
        self,
        this: "_Pointer[cTkNGui]",
        liTextType: Annotated[int, c_int32],
        liGraphicType: Annotated[int, c_int32],
        lpacText: c_char_p64,
        leSize: Annotated[int, c_int32],  # eNGuiSizeType
        lfSizeX: Annotated[float, c_float],
        lfSizeY: Annotated[float, c_float],
        lbBeginLayer: Annotated[bool, c_bool],
        lfMaxSizeX: Annotated[float, c_float],
    ) -> c_uint64: ...


@partial_struct
class cGcNGuiGame(cTkNGui):
    pass


@partial_struct
class cGcShipHUD(Structure):
    # The following offset is found from cGcShipHUD::RenderHeadsUp below the 2nd
    # cGcNGuiLayer::FindElementRecursive call.
    miSelectedPlanet: Annotated[int, Field(c_uint32, 0x23BF0)]
    mbSelectedPlanetPanelVisible: Annotated[bool, Field(c_bool, 0x23C00)]

    # The following offset is found by searching for "UI\\HUD\\SHIP\\MAINSCREEN.MXML"
    # (It's above the below entry.)
    mMainScreenGUI: Annotated[cGcNGui, Field(cGcNGui, offset=0x27630)]
    # The following offset is found by searching for "UI\\HUD\\SHIP\\HEADSUP.MXML"
    mHeadsUpGUI: Annotated[cGcNGui, Field(cGcNGui, offset=0x27BF0)]

    # hud_root: Annotated[int, Field(c_ulonglong, 0x27F70)]  # TODO: Fix

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 0F 29 74 24 ? 48 8B F1 E8"
    )
    def cGcShipHUD(self, this: "_Pointer[cGcShipHUD]"): ...

    @function_hook("48 89 5C 24 ? 57 41 54 41 55 41 56 41 57 48 81 EC")
    def LoadData(self, this: "_Pointer[cGcShipHUD]"): ...

    @function_hook("40 55 56 41 55 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B F1 48 8B 0D")
    def RenderHeadsUp(self, this: "_Pointer[cGcShipHUD]"): ...

    @function_hook(
        "48 89 5C 24 ? 4C 89 44 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? "
        "48 8B 05"
    )
    def ReadPlanetStats(
        self,
        this: "_Pointer[cGcShipHUD]",
        lbCompactDisplay: Annotated[bool, c_bool],
        lName: _Pointer[basic.cTkFixedString0x200],
        lDiscoverer: _Pointer[basic.cTkFixedString0x200],
        lDistance: _Pointer[basic.cTkFixedString0x200],
        lbGPSOnPlanet: Annotated[bool, c_bool],
        lbOwned: _Pointer[c_bool],
        lpfDistance: _Pointer[c_float],
    ): ...


class cTkStopwatch(Structure):
    @function_hook("48 83 EC ? 48 8B 11 0F 29 74 24")
    def GetDurationInSeconds(self, this: "_Pointer[cTkStopwatch]") -> c_float: ...


class cGcNameGenerator(Structure):
    @function_hook(
        "4C 89 4C 24 ? 4C 89 44 24 ? 48 89 4C 24 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? "
        "48 81 EC ? ? ? ? 44 8B D2"
    )
    def GeneratePlanetName(
        self,
        this: "_Pointer[cGcNameGenerator]",
        lu64Seed: Annotated[int, c_uint64],
        lResult: _Pointer[basic.cTkFixedString[0x7F]],
        lLocResult: _Pointer[basic.cTkFixedString[0x7F]],
    ): ...

    @function_hook("48 89 5C 24 ? 55 56 57 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B F9")
    def GenerateGalacticRegionName(
        self,
        this: "_Pointer[cGcNameGenerator]",
        lu64Seed: Annotated[int, c_uint64],
        lResult: _Pointer[basic.cTkFixedString[0x7F]],
        lLocResult: _Pointer[basic.cTkFixedString[0x7F]],
    ): ...


@partial_struct
class cGcRealityManager(Structure):
    mpData: Annotated[_Pointer[nmse.cGcRealityManagerData], 0x0]
    mpSubstanceTable: Annotated[_Pointer[nmse.cGcSubstanceTable], 0x8]
    mpTechnologyTable: Annotated[_Pointer[nmse.cGcTechnologyTable], 0x10]
    mpProductTable: Annotated[_Pointer[nmse.cGcProductTable], 0x18]
    mpBasePartProductTable: Annotated[_Pointer[nmse.cGcProductTable], 0x20]
    mpModularCustomisationProductTable: Annotated[_Pointer[nmse.cGcProductTable], 0x28]
    mpProceduralProductTable: Annotated[_Pointer[nmse.cGcProceduralProductTable], 0x30]
    mpProceduralTechTable: Annotated[_Pointer[nmse.cGcProceduralTechnologyTable], 0x38]
    mpLegacyItemsTable: Annotated[_Pointer[nmse.cGcLegacyItemTable], 0x40]
    mpTechBoxProductTable: Annotated[_Pointer[nmse.cGcTechBoxTable], 0x48]
    mpConsumableItemTable: Annotated[_Pointer[nmse.cGcConsumableItemTable], 0x50]
    mpRecipeTable: Annotated[_Pointer[nmse.cGcRecipeTable], 0x58]
    mpStoriesTable: Annotated[_Pointer[nmse.cGcStoriesTable], 0x60]
    mpLeftHandedVRIconReplacementTable: Annotated[_Pointer[nmse.cTkReplacementResourceTable], 0x68]
    mpItemDescriptionOverrideTable: Annotated[_Pointer[nmse.cGcStoriesTable], 0x70]
    mpMaintenanceOverrideTable: Annotated[_Pointer[nmse.cGcMaintenanceOverrideTable], 0x78]
    mpFishTable: Annotated[_Pointer[nmse.cGcFishTable], 0x80]
    mpBaitTable: Annotated[_Pointer[nmse.cGcBaitTable], 0x88]
    mpGameTableDiceDataTable: Annotated[_Pointer[nmse.cGcGameTableDiceDataTable], 0x90]
    mpRewardTable: Annotated[_Pointer[nmse.cGcRewardTable], 0x98]
    mpDiscoveryRewardLookupTable: Annotated[_Pointer[nmse.cGcDiscoveryRewardLookupTable], 0xA0]
    mpStatRewardsTable: Annotated[_Pointer[nmse.cGcStatRewardsTable], 0xA8]
    mpPetBattlerMovesTable: Annotated[_Pointer[nmse.cGcPetBattlerMovesTable], 0xB0]
    mpPetBattlerMoveSetTable: Annotated[_Pointer[nmse.cGcPetBattlerMoveSetTable], 0xB8]
    mpPetShopItemTable: Annotated[_Pointer[nmse.cGcPetShopItemTable], 0xC0]
    mpMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0xC8]
    mpNPCMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0xD0]
    mpWikiMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0xD8]
    mpCoreMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0xE0]
    mpTutorialMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0xE8]
    mpAtlasPathTable: Annotated[_Pointer[nmse.cGcMissionTable], 0xF0]
    mpRecurringMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0xF8]
    mpCommunityMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x100]
    mpFleetMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x108]
    mpWaterMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x110]
    mpMultiplayerMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x118]
    mpCorvetteMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x120]
    mpBaseComputerMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x128]
    mpPlanetProcMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x130]
    mpDisablingConditionsTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x138]
    mpSpacePOIMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x140]
    mpSeasonalMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x148]
    mpSeasonalBespokeMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x150]
    mpSentinelSettlementMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x158]
    mpStatStoriesMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x160]
    mpPirateMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x168]
    mpStartedOnUseMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x170]
    mpNPCBuildersMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x178]
    mpSwarmMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x180]
    mpDeprecatedMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x188]
    mpModMissionTable: Annotated[_Pointer[nmse.cGcMissionTable], 0x190]
    mpMissionSchedulesTable: Annotated[_Pointer[nmse.cGcMissionSchedulesTable], 0x198]
    mpMissionCommunityData: Annotated[_Pointer[nmse.cGcMissionCommunityData], 0x1A0]
    mpInventoryTable: Annotated[_Pointer[nmse.cGcInventoryTable], 0x1A8]
    mpMaintenanceGroupsTable: Annotated[_Pointer[nmse.cGcMaintenanceGroupsTable], 0x1B0]
    mpUnlockableTrees: Annotated[_Pointer[nmse.cGcUnlockableTrees], 0x1E0]
    mpEmotesList: Annotated[_Pointer[nmse.cGcPlayerEmoteList], 0x1E8]
    mpPlayerDamageTable: Annotated[_Pointer[nmse.cGcPlayerDamageTable], 0x1F0]
    mpPurchaseableBuildingBlueprints: Annotated[_Pointer[nmse.cGcPurchaseableBuildingBlueprints], 0x1F8]
    mpPurchaseableSpecials: Annotated[_Pointer[nmse.cGcPurchaseableSpecials], 0x200]
    mpHistoricalSeasonDataTable: Annotated[_Pointer[nmse.cGcHistoricalSeasonDataTable], 0x208]
    mpUnlockableSeasonRewards: Annotated[_Pointer[nmse.cGcUnlockableSeasonRewards], 0x210]
    mpUnlockableTwitchRewards: Annotated[_Pointer[nmse.cGcUnlockableTwitchRewards], 0x218]
    mpUnlockablePlatformRewards: Annotated[_Pointer[nmse.cGcUnlockablePlatformRewards], 0x220]
    mpSettlementPerksTable: Annotated[_Pointer[nmse.cGcSettlementPerksTable], 0x228]
    mpWiki: Annotated[_Pointer[nmse.cGcWiki], 0x230]
    mpItemCostTable: Annotated[_Pointer[nmse.cGcItemCostTable], 0x268]
    mpTradingClassTable: Annotated[_Pointer[nmse.cGcTradingClassTable], 0x270]
    mpCostTable: Annotated[_Pointer[nmse.cGcCostTable], 0x278]
    mpPlayerWeaponPropertiesTable: Annotated[_Pointer[nmse.cGcPlayerWeaponPropertiesTable], 0x280]
    mpCombatEffectsTable: Annotated[_Pointer[nmse.cGcCombatEffectsTable], 0x288]
    mpPlayerTitleData: Annotated[_Pointer[nmse.cGcPlayerTitleData], 0x290]
    mpGalacticMapIcons: Annotated[_Pointer[nmse.cGcGalaxyInfoIcons], 0xC08]
    mpAlienWords: Annotated[_Pointer[nmse.cGcAlienSpeechTable], 0xC10]
    mNameGenerator: Annotated[cGcNameGenerator, 0xC18]
    mapRepairTechs: Annotated[basic.TkStd.tk_vector[_Pointer[nmse.cGcTechnology]], 0xCE0]
    mapAlienPuzzleTables: Annotated[
        basic.TkStd.tk_vector[std.pair[_Pointer[nmse.cGcAlienPuzzleTable], c_int32]], 0xCF0
    ]
    mpDialogClearanceTable: Annotated[_Pointer[nmse.cGcDialogClearanceTable], 0xD00]
    maDynamicHazardProtectionIcons: Annotated[
        tuple[nmse.cTkTextureResource, ...], Field(nmse.cTkTextureResource * 7, 0xD08)
    ]

    @function_hook(
        "40 55 53 56 57 41 54 41 56 41 57 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 4C 8B F1"
    )
    def Construct(self, this: "_Pointer[cGcRealityManager]"): ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B F9 33 ED 48 89 A9")
    def cGcRealityManager(self, this: "_Pointer[cGcRealityManager]"): ...

    @function_hook("48 89 54 24 ? 48 89 4C 24 ? 55 53 57 48 8D AC 24 ? ? ? ? B8")
    def GenerateProceduralProduct(
        self,
        this: "_Pointer[cGcRealityManager]",
        lProcProdID: _Pointer[basic.TkID[0x10]],
    ) -> c_uint64:  # cGcProductData *
        ...

    @function_hook("4C 89 4C 24 ? 44 88 44 24 ? 48 89 4C 24 ? 55 56")
    def GenerateProceduralTechnology(
        self,
        this: "_Pointer[cGcRealityManager]",
        lProcTechID: _Pointer[basic.TkID[0x10]],
        lbExampleForWiki: Annotated[bool, c_bool],
    ) -> c_uint64:  # cGcProductData *
        ...


@partial_struct
class cGcInventoryStore(Structure):
    _total_size_ = 0x248

    mxValidSlots: Annotated[
        tuple[basic.cTkBitArray[c_uint64, 16], ...],  # type: ignore
        Field(basic.cTkBitArray[c_uint64, 16] * 16, 0x0),
    ]
    miWidth: Annotated[int, Field(c_int16, 0x80)]
    miHeight: Annotated[int, Field(c_int16, 0x82)]
    miCapacity: Annotated[int, Field(c_int16, 0x84)]
    mStore: Annotated[basic.TkStd.tk_vector[nmse.cGcInventoryElement], 0x88]
    mStoreHistory: Annotated[basic.TkStd.tk_vector[nmse.cGcInventoryElement], 0x98]
    meStackSizeGroup: Annotated[c_enum16[enums.cGcInventoryStackSizeGroup], 0xB8]
    maSpecialSlots: Annotated[basic.TkStd.tk_vector[nmse.cGcInventorySpecialSlot], 0xC0]
    maBaseStats: Annotated[basic.TkStd.tk_vector[nmse.cGcInventoryBaseStatEntry], 0xD0]
    mLayoutDescriptor: Annotated[nmse.cGcInventoryLayout, 0xE0]
    mbAutoMaxEnabled: Annotated[bool, Field(c_bool, 0xF8)]
    mClass: Annotated[c_enum32[enums.cGcInventoryClass], 0x100]
    # Name of the inventory. This will often be empty and will be BLD_STORAGE_NAME for building inventories.
    mInventoryName: Annotated[basic.cTkFixedString0x100, 0x104]

    @function_hook(
        "48 89 5C 24 ? 57 48 83 EC ? 33 FF 0F 57 C0 0F 11 01 48 8B D9 0F 11 41 ? 0F 11 41 ? 0F 11 41"
    )
    def cGcInventoryStore(self, this: "_Pointer[cGcInventoryStore]"): ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 55 57 41 56 48 8D 6C 24 ? 48 81 EC ? ? ? ? 41 0F 10 00")
    def Add(
        self,
        this: "_Pointer[cGcInventoryStore]",
        result: _Pointer[nmse.cGcInventoryIndex],
        lItem: _Pointer[nmse.cGcInventoryElement],
    ): ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 54 24 ? 56 57 41 56 48 83 EC ? 48 8B B9")
    def Remove(
        self,
        this: "_Pointer[cGcInventoryStore]",
        lIndex: nmse.cGcInventoryIndex,
        liAmountOverride: Annotated[int, c_int32],
    ): ...

    @function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B 99 ? ? ? ? 48 8B F2 8B 81 ? ? ? ? 48 8D 3C 40 48 C1 "
        "E7 ? 48 03 FB 48 3B DF 74 ? 90 48 8D 53"
    )
    def GetElement(self, this: "_Pointer[cGcInventoryStore]", lIndex: _Pointer[nmse.cGcInventoryIndex]): ...


class cGcUniverseAddressData(nmse.cGcUniverseAddressData):
    @classmethod
    def from_UA(cls, ua: int):
        # TODO: Add
        pass

    def to_UA(self) -> int:
        # Generate the Universe address 64 bit representation of this address.
        iteration = min(self.RealityIndex, 0xFF)
        solar_index = min(self.GalacticAddress.SolarSystemIndex, 0xFFF)
        return (
            (self.GalacticAddress.VoxelX & 0xFFF)
            | ((self.GalacticAddress.VoxelZ & 0xFFF) << 12)
            | ((self.GalacticAddress.VoxelY & 0xFF) << 24)
            | (iteration << 32)
            | (solar_index << 40)
            | (self.GalacticAddress.PlanetIndex) << 52
        )


@partial_struct
class CustomisationData(Structure):
    # All found in cGcResourceCustomisation::CreateGenerationTask
    mResourceSeed: Annotated[basic.cTkSeed, 0x0]
    mDescriptors: Annotated[basic.TkStd.tk_vector[basic.TkID0x20], 0x10]
    mTextureOptions: Annotated[nmse.cTkProceduralTextureChosenOptionList, 0x20]

    mbUseLegacyColourPalettes: Annotated[bool, Field(c_bool, 0x70)]
    mbEditedColours: Annotated[bool, Field(c_bool, 0x71)]
    mEditColours: Annotated[nmse.cGcPlanetColourData, 0x90]
    mFinalColours: Annotated[nmse.cGcPlanetColourData, 0x1C90]
    mfScale: Annotated[float, Field(c_float, 0x3890)]


@partial_struct
class cGcResourceCustomisation(Structure):
    _total_size_ = 0x3920

    mResourceCustomisation: Annotated[CustomisationData, 0x0]
    mForcedTextureName: Annotated[basic.TkID0x20, 0x3900]

    @function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 4C 89 74 24 ? 55 48 8D 6C 24 ? 48 81 EC ? ? ? ? 66 0F 6F "
        "05 ? ? ? ? 45 33 F6"
    )
    def CreateGenerationTask(
        self,
        this: "_Pointer[cGcResourceCustomisation]",
        lpResourceHandle: _Pointer[cTkSmartResHandle],
        lpResourceFilename: c_char_p64,
        lbCopyOptions: Annotated[bool, c_bool],
    ) -> c_uint64: ...


@partial_struct
class cGcPlayerState(Structure):
    # Found at the top of cGcPlayerState::cGcPlayerState
    mNameWithTitle: Annotated[basic.cTkFixedString0x100, 0x0]
    mGameStartLocation1: Annotated[nmse.cGcUniverseAddressData, 0x830]
    mGameStartLocation2: Annotated[nmse.cGcUniverseAddressData, 0x848]
    mLocation: Annotated[nmse.cGcUniverseAddressData, 0x860]
    mPrevLocation: Annotated[nmse.cGcUniverseAddressData, 0x878]

    # Found near the top of cGcPlayerState::SaveToData
    miShield: Annotated[int, Field(c_int32, 0x890)]
    miHealth: Annotated[int, Field(c_int32, 0x894)]
    miShipHealth: Annotated[int, Field(c_int32, 0x898)]
    muUnits: Annotated[int, Field(c_uint32, 0x89C)]
    muNanites: Annotated[int, Field(c_uint32, 0x8A0)]
    muSpecials: Annotated[int, Field(c_uint32, 0x8A4)]
    # Found in cGcPlayerState::cGcPlayerState
    mInventories: Annotated[tuple[cGcInventoryStore, ...], Field(cGcInventoryStore * 0x21, 0x510)]
    mVehicleInventories: Annotated[tuple[cGcInventoryStore, ...], Field(cGcInventoryStore * 0x7, 0x5068)]
    mVehicleTechInventories: Annotated[tuple[cGcInventoryStore, ...], Field(cGcInventoryStore * 0x7, 0x6060)]

    mShipInventories: Annotated[tuple[cGcInventoryStore, ...], Field(cGcInventoryStore * 0xC, 0x7058)]
    mShipInventoriesCargo: Annotated[tuple[cGcInventoryStore, ...], Field(cGcInventoryStore * 0xC, 0x8BC8)]
    mShipInventoriesTechOnly: Annotated[tuple[cGcInventoryStore, ...], Field(cGcInventoryStore * 0xC, 0xA728)]

    # Found in cGcPlayerState::LoadFromData a little bit above the POLICESHIP.SCENE.MBIN, a few lines above
    # the assignment of something to 12LL.
    # The actual value is this one found - 0x10
    mShipResources: Annotated[
        tuple[nmse.cGcResourceElement, ...],
        Field(nmse.cGcResourceElement * 0xC, 0x17A00),
    ]

    # Found in cGcPlayerShipOwnership::SpawnNewShip
    miPrimaryShip: Annotated[int, Field(c_uint32, 0x17DC0)]

    # Found in cGcPlayerState::cGcPlayerState above the loop over something 5 times. Around line 220.
    mPhotoModeSettings: Annotated[nmse.cGcPhotoModeSettings, 0x1A0D0]
    maTeleportEndpoints: Annotated[std.vector[nmse.cGcTeleportEndpoint], 0x1A120]

    mHoloExplorerInteraction: Annotated[cGcInteractionData, 0x1A310]
    mHoloScepticInteraction: Annotated[cGcInteractionData, 0x1A330]
    mHoloNooneInteraction: Annotated[cGcInteractionData, 0x1A350]
    mNetworkPlayerInteraction: Annotated[cGcInteractionData, 0x1A370]
    # Directly below the calls to cGcInteractionData::SetDefaults in cGcPlayerState::cGcPlayerState
    maCustomShipNames: Annotated[
        tuple[basic.cTkFixedString0x20, ...],
        Field(basic.cTkFixedString0x20 * 0xC, 0x1A3A3),
    ]

    # This can be found in cGcPlayerShipOwnership::UpdateMeshRefresh
    mCustomisationData: Annotated[
        tuple[cGcResourceCustomisation, ...],
        Field(cGcResourceCustomisation * 0x1A, 0x1A790),
    ]

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 54 41 55 41 56 41 57 48 83 EC ? 45 33 ED 0F 29 74 24"
    )
    def cGcPlayerState(self, this: "_Pointer[cGcPlayerState]"): ...

    @function_hook(
        "48 89 5C 24 ? 57 48 83 EC ? 44 8B 81 ? ? ? ? 48 8B D9 66 0F 6F 05 ? ? ? ? 41 8B C0 F7 D0 48 C7 44 "
        "24 ? ? ? ? ? 3B D0 8B FA F3 0F 7F 44 24 ? 0F 42 C2 45 33 C9 44 03 C0 48 8D 54 24 ? 44 89 81 ? ? ? ? "
        "48 8B 0D ? ? ? ? 48 81 C1 ? ? ? ? E8 ? ? ? ? 85 FF 7E ? 48 8B 0D"
    )
    def AwardUnits(
        self,
        this: "_Pointer[cGcPlayerState]",
        liChange: Annotated[int, c_int32],
    ) -> c_uint64: ...

    @function_hook(
        "48 89 5C 24 ? 57 48 83 EC ? 44 8B 81 ? ? ? ? 48 8B D9 66 0F 6F 05 ? ? ? ? 41 8B C0 F7 D0 48 C7 44 "
        "24 ? ? ? ? ? 3B D0 8B FA F3 0F 7F 44 24 ? 0F 42 C2 45 33 C9 44 03 C0 48 8D 54 24 ? 44 89 81 ? ? ? ? "
        "48 8B 0D ? ? ? ? 48 81 C1 ? ? ? ? E8 ? ? ? ? 85 FF 7E ? 4C 8B 15"
    )
    def AwardNanites(
        self,
        this: "_Pointer[cGcPlayerState]",
        liChange: Annotated[int, c_int32],
    ) -> c_uint64: ...

    @function_hook("89 54 24 ? 4C 8B DC 48 83 EC")
    def StoreCurrentSystemSpaceStationEndpoint(
        self,
        this: "_Pointer[cGcPlayerState]",
        a2: c_int32,
    ): ...

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 54 41 55 41 56 41 57 48 83 EC ? 4C 8B BC 24 ? ? ? ? "
        "48 8B F9 48 63 EA"
    )
    def GetStatValue(
        self,
        this: "_Pointer[cGcPlayerState]",
        leStat: c_enum32[enums.cGcStatsTypes],
        leLookupType: c_int32,  # ItemLookupType
        leBaseStat: c_enum32[enums.cGcStatsTypes],
        lbIgnoreAdjacencyBonus: Annotated[bool, c_bool],
        lbIgnoreInventoryBonus: Annotated[bool, c_bool],
        lpPrimaryInventory: _Pointer[cGcInventoryStore * 0x21],
        lpTechInventory: _Pointer[cGcInventoryStore],
    ) -> c_float: ...

    @function_hook(
        "48 8B C4 48 89 50 ? 48 89 48 ? 55 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 89 58 ? 48 89 70 ? 48 89 78 "
        "? 4C 89 60"
    )
    def SaveToData(self, this: "_Pointer[cGcPlayerState]", lData: _Pointer[nmse.cGcPlayerStateData]): ...

    @function_hook("44 88 4C 24 ? 4C 89 44 24 ? 48 89 54 24 ? 48 89 4C 24 ? 55 41 55")
    def LoadFromData(
        self,
        this: "_Pointer[cGcPlayerState]",
        lData: _Pointer[nmse.cGcPlayerStateData],
        a3: c_uint64,
        lbNetworkClientLoad: Annotated[bool, c_bool],
        lbIsLoadingForReset: Annotated[bool, c_bool],
        a6: c_uint32,
    ): ...

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 48 8D 99"
    )
    def PackageTechnology(
        self,
        this: "_Pointer[cGcPlayerState]",
        leFromInventory: c_enum8[enums.InventoryChoice],
        lFromIndex: _Pointer[nmse.cGcInventoryIndex],
        leToInventory: c_enum8[enums.InventoryChoice],
        lToIndex: _Pointer[nmse.cGcInventoryIndex],
        leMode: c_enum32[enums.TryStoreMode],
        lErrorMessage: _Pointer[basic.cTkFixedString0x20],
    ) -> c_bool: ...


@partial_struct
class cGcPlayerShipOwnership(Structure):
    @partial_struct
    class sGcShipData(Structure):
        _total_size_ = 0x30

        # Not sure about these...
        # Mapping is found in cGcPlayerShipOwnership::cGcPlayerShipOwnership but they don't seem to line up
        # with old data.
        mPlayerShipNode: Annotated[basic.TkHandle, 0x0]
        mpPlayerShipAttachment: Annotated[c_uint64, 0x8]  # cTkAttachmentPtr
        mPlayerShipSeed: Annotated[basic.cTkSeed, 0x10]  # TODO: Fix - Not sure if the seed is here any more?
        mfUnknown0x20: Annotated[float, Field(c_float, 0x20)]
        mbUnknown0x28: Annotated[bool, Field(c_bool, 0x28)]  # Looks like "is valid/data"

    class eMeshRefreshState(IntEnum):
        ReadyForRefresh = 0x0
        Generating = 0x1
        SwapMesh = 0x2

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 45 33 E4 48 C7 "
        "41"
    )
    def cGcPlayerShipOwnership(self, this: "_Pointer[cGcPlayerShipOwnership]"): ...

    @function_hook("48 89 5C 24 ? 55 56 57 41 54 41 56 48 8D 6C 24 ? 48 81 EC ? ? ? ? 45 33 E4")
    def UpdateMeshRefresh(self, this: "_Pointer[cGcPlayerShipOwnership]"): ...

    @function_hook("48 8B C4 55 53 56 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 80 B9 ? ? ? ? ? 48 8B F1")
    def Update(
        self,
        this: "_Pointer[cGcPlayerShipOwnership]",
        lfTimestep: Annotated[float, c_float],
    ): ...

    @function_hook("44 89 44 24 ? 48 89 54 24 ? 55 53 56 41 54")
    def SpawnNewShip(
        self,
        this: "_Pointer[cGcPlayerShipOwnership]",
        lMatrix: _Pointer[basic.cTkMatrix34],
        leLandingGearState: c_uint32,  # cGcPlayerShipOwnership::ShipSpawnLandingGearState
        liShipIndex: c_int32,
        lbSpawnShipOverride: c_bool,
    ) -> c_bool: ...

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 48 8B 2D ? ? ? ? 8B DA"
    )
    def DestroyShip(
        self,
        this: "_Pointer[cGcPlayerShipOwnership]",
        liShipIndex: c_int32,
    ) -> c_bool: ...

    @function_hook("83 FA ? 75 ? 48 8B 05 ? ? ? ? 8B 90 ? ? ? ? 48 63 C2 48 8D 14 40 48 03 D2")
    def GetShipComponent(
        self,
        this: "_Pointer[cGcPlayerState]",
        liShipIndex: Annotated[int, c_int32],
    ) -> c_uint64:  # cTkComponent *
        ...

    # Found in cGcPlayerShipOwnership::cGcPlayerShipOwnership
    mShips: Annotated[list[sGcShipData], Field(sGcShipData * 12, 0x60)]
    # Both these found at the top of cGcPlayerShipOwnership::UpdateMeshRefresh
    mbShouldRefreshMesh: Annotated[bool, Field(c_bool, 0xA870)]
    mMeshRefreshState: Annotated[c_enum32[eMeshRefreshState], 0xA874]
    mRefreshSwapRes: Annotated[cTkSmartResHandle, 0xA878]


@partial_struct
class cGcPlayerVehicleOwnership(Structure):
    # Found in cGcPlayerVehicleOwnership::cGcPlayerVehicleOwnership
    mbShouldRefreshMesh: Annotated[bool, Field(c_bool, 0x730)]

    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 33 FF 48 C7 41 ? ? ? ? ? 48 89 79 ? 48 B8")
    def cGcPlayerVehicleOwnership(self, this: "_Pointer[cGcPlayerVehicleOwnership]"): ...


class cGcPlayerCreatureOwnership(Structure):
    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 54 41 55 41 56 41 57 48 83 EC ? 48 8B E9 48 8B D9"
    )
    def cGcPlayerCreatureOwnership(self, this: "_Pointer[cGcPlayerCreatureOwnership]"): ...


class cGcPlayerMultitoolOwnership(Structure):
    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 45 33 FF 0F 29 74 24 ? 44 89 39"
    )
    def cGcPlayerMultitoolOwnership(self, this: "_Pointer[cGcPlayerMultitoolOwnership]"): ...


@partial_struct
class cGcPlayerFreighterOwnership(Structure):
    _total_size_ = 0x4C0
    # Found in cGcPlayerBasePersistentBuffer::LoadGalacticAddress
    mFreighterMatrix: Annotated[basic.cTkMatrix34, 0x3A0]

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F 57 C0 48 8D 05")
    def cGcPlayerFreighterOwnership(self, this: "_Pointer[cGcPlayerFreighterOwnership]"): ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 55 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B D9 E8")
    def ResetPlayerFreighterBase(self, this: "_Pointer[cGcPlayerFreighterOwnership]") -> c_bool: ...


@partial_struct
class cGcPlayerFleetManager(Structure):
    _total_size_ = 0x3FB0

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8D 05 ? ? ? ? C7 41 ? ? ? ? ? 48 89 01 "
        "48 8B D9"
    )
    def cGcPlayerFleetManager(self, this: "_Pointer[cGcPlayerFleetManager]"): ...


@partial_struct
class cGcGalacticVoxelCoordinate(Structure):
    mX: Annotated[int, Field(c_int16)]
    mZ: Annotated[int, Field(c_int16)]
    mY: Annotated[int, Field(c_int16)]
    mbValid: Annotated[bool, Field(c_bool)]


@partial_struct
class cGcGalacticSolarSystemAddress(Structure):
    mVoxelCoordinate: Annotated[cGcGalacticVoxelCoordinate, Field(cGcGalacticVoxelCoordinate)]
    mSolarIndex: Annotated[int, Field(c_uint16)]
    mIteration: Annotated[int, Field(c_uint16)]


@partial_struct
class SolarQueryResult(Structure):
    mu64UA: Annotated[int, Field(c_uint64, 0x0)]
    mSolarSystemAddress: Annotated[cGcGalacticSolarSystemAddress, 0x8]
    mLocalPoint: Annotated[basic.cTkVector3, 0x20]
    mGlobalPoint: Annotated[basic.cTkVector3, 0x30]

    @static_function_hook(
        "48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 44 0F B7 41"
    )
    @staticmethod
    def ComputeLightyearDistanceBetweenSolarSystems(
        lFrom: "_Pointer[SolarQueryResult]",
        lTo: "_Pointer[SolarQueryResult]",
    ) -> c_float: ...


@partial_struct
class sVisitedSystem(Structure):
    mVoxel: Annotated[cGcGalacticVoxelCoordinate, 0x0]
    miSystemIndex: Annotated[int, Field(c_int16, 0x8)]
    # This value is actually storing the indexes of the planets.
    # So a value of 0b1101 would mean you have visited planets 0, 2 and 3 (by index).
    miPlanetsVisited: Annotated[int, Field(c_uint16, 0xA)]


@partial_struct
class cGcVisitedSystemsBuffer(Structure):
    mVisitedSystems: Annotated[tuple[sVisitedSystem, ...], Field(sVisitedSystem * 0x200, 0x0)]
    miCurrentPosition: Annotated[int, Field(c_int32, 0x1800)]
    miVisitedSystemsCount: Annotated[int, Field(c_int32, 0x1804)]

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 54 41 55 41 56 41 57 48 83 EC ? 48 8B 2A")
    def VisitNewGalacticAddress(
        self,
        this: "_Pointer[cGcVisitedSystemsBuffer]",
        lu64Address: _Pointer[c_uint64],
    ): ...


@partial_struct
class sHashValue(Structure):
    muHashValue: Annotated[int, Field(c_uint16, 0x0)]
    miTimeStamp: Annotated[int, Field(c_int16, 0x2)]


@partial_struct
class cGcNetworkBufferHash(Structure):
    _total_size_ = 0x30
    # cGcNetworkBufferHash_vtbl *__vftable
    kiChunkSize: Annotated[int, Field(c_int32, 0x8)]
    miChunkHashOffset: Annotated[int, Field(c_int32, 0xC)]
    maChunkHashValues: Annotated[basic.TkStd.tk_vector[sHashValue], 0x10]
    mu64Timestamp: Annotated[int, Field(c_uint64, 0x20)]
    mbInitialised: Annotated[bool, Field(c_bool, 0x28)]


@partial_struct
class cGcNetworkSynchronisedBuffer(Structure):
    pass


@partial_struct
class cGcBaseBuildingBaseLayout(Structure):
    mBaseUA: Annotated[int, Field(c_uint64, 0x0)]
    mBasePosition: Annotated[basic.cTkVector3, 0x10]
    mfBaseRadiusSqr: Annotated[float, Field(c_float, 0x130)]


@partial_struct
class cGcPlayerBasePersistentBuffer(cGcNetworkSynchronisedBuffer):
    @partial_struct
    class PlayerBasePersistentData(Structure):
        _total_size_ = 0xD0
        mData: Annotated[nmse.cGcPersistentBaseEntry, 0x10]
        mpBuildingEntry: Annotated[_Pointer[nmse.cGcBaseBuildingEntry], 0xC0]

    # Found in cGcPlayerBasePersistentBuffer::LoadGalacticAddress
    # Some also just found in memory (offsets seem 0x10 less than 4.13 up to a point.)
    maBaseBuildingObjects: Annotated[basic.TkStd.tk_vector[PlayerBasePersistentData], 0x30]
    muCurrentAddress: Annotated[int, Field(c_uint64, 0x40)]
    muiLastUpdateTimestamp: Annotated[int, Field(c_uint64, 0x48)]
    mBaseMatrix: Annotated[basic.cTkPhysRelMat34, 0x50]
    muBaseUA: Annotated[int, Field(c_uint64, 0x40)]
    mOwner: Annotated[nmse.cGcDiscoveryOwner, 0xF0]
    mName: Annotated[basic.cTkFixedString0x40, 0x1F4]
    meBaseType: Annotated[c_enum32[enums.cGcPersistentBaseTypes], 0x23C]
    mpLayoutHandle: Annotated[_Pointer[cGcBaseBuildingBaseLayout], 0x308]
    # Found in cGcPersistentInteractionsManager::PopulateArrays
    muiValidObjectsCount: Annotated[int, Field(c_uint32, 0x310)]
    mbIsReported: Annotated[bool, Field(c_bool, 0x371)]

    @function_hook("48 8B C4 53 48 81 EC ? ? ? ? 48 89 68 ? 48 8B D9 48 8B 69")
    def LoadGalacticAddress(
        self,
        this: "_Pointer[cGcPlayerBasePersistentBuffer]",
        lu64Address: _Pointer[c_uint64],
        luiThisIndex: _Pointer[c_uint64],
    ): ...


class cGcPersistentInteractionBuffer(cGcNetworkSynchronisedBuffer):
    # _total_size_ = 0x190
    # Found in cGcPersistentInteractionBuffer::SaveInteraction
    miLastBufferIndex: Annotated[int, Field(c_int32, 0x30)]
    muCurrentAddress: Annotated[int, Field(c_uint64, 0x38)]
    meType: Annotated[c_enum32[enums.cGcInteractionBufferType], 0x40]
    maBufferData: Annotated[basic.cTkDynamicArray[nmse.cGcInteractionData], 0x50]

    @function_hook("40 53 56 57 41 56 48 81 EC ? ? ? ? 48 8B F1")
    def LoadGalacticAddressBuffers(
        self,
        this: "_Pointer[cGcPersistentInteractionBuffer]",
        lu64Address: _Pointer[c_uint64],
    ): ...

    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 48 8B FA 48 8B D9 8B 51")
    def PopulateBufferData(
        self,
        this: "_Pointer[cGcPersistentInteractionBuffer]",
        lBufferData: _Pointer[nmse.cGcInteractionBuffer],
    ): ...

    # FIXME: This doesn't seem to exist any more. Need to xref with the mac binary?
    # @function_hook("48 89 5C 24 ? 56 48 83 EC ? 0F 10 22")
    # def SaveInteraction(
    #     self,
    #     this: "_Pointer[cGcPersistentInteractionBuffer]",
    #     lPosition: _Pointer[basic.cTkVector3],
    #     lData: _Pointer[nmse.cGcInteractionData],
    #     lbReplace: Annotated[bool, c_bool],
    #     lfRadius: Annotated[float, c_float],
    # ): ...


@partial_struct
class cGcPersistentInteractionsManager(Structure):
    # Found in cGcPersistentInteractionsManager::LoadGalacticAddressBuffers
    maPersistentBaseBuffers: Annotated[basic.TkStd.tk_vector[_Pointer[cGcPlayerBasePersistentBuffer]], 0x1C08]
    mDistressSignalBuffer: Annotated[cGcPersistentInteractionBuffer, 0x1C20]
    mCrateBuffer: Annotated[cGcPersistentInteractionBuffer, 0x1DB0]
    mDestructableBuffer: Annotated[cGcPersistentInteractionBuffer, 0x1F40]
    mCostBuffer: Annotated[cGcPersistentInteractionBuffer, 0x20D0]
    mBuildingBuffer: Annotated[cGcPersistentInteractionBuffer, 0x2260]
    mCreatureBuffer: Annotated[cGcPersistentInteractionBuffer, 0x23F0]
    mPersonalBuffer: Annotated[cGcPersistentInteractionBuffer, 0x2580]
    mFireteamSyncBuffer: Annotated[cGcPersistentInteractionBuffer, 0x2710]
    mVisitedSystemsBuffer: Annotated[cGcVisitedSystemsBuffer, 0x1A4A70]

    @function_hook("48 89 5C 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 83 EC ? 4C 8B E9 4C 8B FA")
    def LoadGalacticAddressBuffers(
        self,
        this: "_Pointer[cGcPersistentInteractionsManager]",
        lu64Address: _Pointer[c_uint64],
    ): ...

    @function_hook("48 8B C4 4C 89 40 ? 55 53 41 55 41 57")
    def PopulateArrays(
        self,
        this: "_Pointer[cGcPersistentInteractionsManager]",
        lArrayData: _Pointer[nmse.cGcInteractionBuffer * 0xB],
        lPlayerBaseArrayData: _Pointer[basic.cTkDynamicArray[nmse.cGcPersistentBase]],
        lMaintenanceData: _Pointer[basic.cTkDynamicArray[nmse.cGcMaintenanceContainer]],
        lVisitedSystems: _Pointer[basic.cTkDynamicArray[c_uint64]],
    ): ...


@partial_struct
class cGcPlayerSquadronOwnership(Structure):
    mRNG: Annotated[cTkPersonalRNG, 0x4]


@partial_struct
class WarpCapabilityResult(Structure):
    pass


class cGcGalaxyVoxelAttributesData(nmse.cGcGalaxyVoxelAttributesData):
    @function_hook("33 C0 0F 57 C0 0F 11 01 0F 11 41 ? 0F 11 41 ? 48 89 41 ? 48 89 41 ? 48 89 41 ? 48 89 41")
    def SetDefaults(self, this: "_Pointer[cGcGalaxyVoxelAttributesData]"): ...


class cGcGalaxyStarAttributesData(nmse.cGcGalaxyStarAttributesData):
    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 33 ED 48 8D B9 ? ? ? ? 48 89 6C 24"
    )
    def SetDefaults(self, this: "_Pointer[cGcGalaxyStarAttributesData]"): ...


@partial_struct
class cTkParallelRNG(Structure):
    _k: Annotated[tuple[int, ...], Field(c_uint64 * 4, 0x0)]
    _s: Annotated[tuple[int, ...], Field(c_uint64 * 4, 0x20)]
    _o: Annotated[tuple[int, ...], Field(c_uint64 * 4, 0x40)]
    _o_counter: Annotated[int, Field(c_uint16, 0x60)]


class cGcGalaxyVoxelData(Structure): ...


class cGcGalaxyVoxelGenerator(nmse.cGcGalaxyStarAttributesData):
    @static_function_hook("48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 56 57 41 57")
    @staticmethod
    def Populate(
        lu64UniverseAddress: c_uint64,
        lVoxelData: _Pointer[cGcGalaxyVoxelData],
        lRootOffset: _Pointer[basic.Vector3f],
    ): ...


class cGcGalaxyAttributeGenerator(Structure):
    @partial_struct
    class StarSystemKeyAttributes(Structure):
        _total_size_ = 0x30
        # These can all be found in cGcGalaxyAttributeGenerator::ClassifyStarKeyAttributes
        meTradingClass: Annotated[
            c_enum32[enums.cGcTradingClass],
            Field(c_enum32[enums.cGcTradingClass], 0x0),
        ]
        meWealthClass: Annotated[c_enum32[enums.cGcWealthClass], Field(c_enum32[enums.cGcWealthClass], 0x4)]
        meConflictLevel: Annotated[
            c_enum32[enums.cGcPlayerConflictData],
            Field(c_enum32[enums.cGcPlayerConflictData], 0x8),
        ]
        meRace: Annotated[c_enum32[enums.cGcAlienRace], Field(c_enum32[enums.cGcAlienRace], 0xC)]
        meType: Annotated[c_enum32[enums.cGcGalaxyStarTypes], Field(c_enum32[enums.cGcGalaxyStarTypes], 0x10)]
        # cGcGalaxyAttributeGenerator::StarSystemKeyAttributes::Tag
        meTag: Annotated[int, Field(c_int32, 0x14)]
        meAnomaly: Annotated[int, Field(c_uint32, 0x18)]  # Actually _BYTE[4]
        muPlanetCount: Annotated[int, Field(c_uint32, 0x1C)]
        muSafeStartPlanet: Annotated[int, Field(c_uint32, 0x20)]
        mbAbandonedSystem: Annotated[bool, Field(c_bool, 0x24)]
        mbIsPirateSystem: Annotated[bool, Field(c_bool, 0x25)]
        muPrimePlanetCount: Annotated[int, Field(c_uint32, 0x28)]
        mbUnknown0x2C: Annotated[bool, Field(c_bool, 0x2C)]
        mbUnknown0x2D: Annotated[bool, Field(c_bool, 0x2D)]

    @static_function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F BF 41")
    @staticmethod
    def ClassifyVoxel(
        lCoordinate: _Pointer[cGcGalacticVoxelCoordinate],
        lOutput: _Pointer[cGcGalaxyVoxelAttributesData],
    ): ...

    @static_function_hook("48 89 54 24 ? 55 53 56 57 41 54 41 55 41 56 48 8B EC")
    @staticmethod
    def ClassifyStarSystem(lUA: c_uint64, lOutput: _Pointer[cGcGalaxyStarAttributesData]): ...

    @static_function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 55 57 41 54 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 8B F9"
    )
    @staticmethod
    def ClassifyStarKeyAttributes_Prep(lUA: c_uint64, lKeyAttributes: _Pointer[StarSystemKeyAttributes]):
        # Prep function for the below one.
        pass

    @static_function_hook("48 89 5C 24 ? 66 89 54 24")
    @staticmethod
    def ClassifyStarKeyAttributes(
        lIndexPrimedPRNG: _Pointer[cTkParallelRNG],
        liSolarIndexInVoxel: Annotated[int, c_uint16],
        lVoxelAttributes: _Pointer[cGcGalaxyVoxelAttributesData],
        lKeyAttributes: _Pointer[StarSystemKeyAttributes],
        lUA: Annotated[int, c_uint64],
    ):
        pass


@partial_struct
class cGcDiscoveryData(Structure):
    mUniverseAddress: Annotated[c_uint64, 0x0]
    meType: Annotated[c_enum32[enums.cGcDiscoveryType], 0x40]


@partial_struct
class cGcDiscoveryManager(Structure):
    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B 59 ? 49 8B F8 48 8B F2")
    def SubmitDiscoveryData(
        self,
        this: "_Pointer[cGcDiscoveryManager]",
        lDiscoveryData: _Pointer[cGcDiscoveryData],
        lpbLocallyNew: _Pointer[c_bool],
    ): ...


@partial_struct
class cGcGameState(Structure):
    # Found in cGcGameState::cGcGameState
    mPlayerState: Annotated[cGcPlayerState, 0xAAD0]
    mSavedSpawnState: Annotated[nmse.cGcPlayerSpawnStateData, 0xCEAD0]
    mPlayerShipOwnership: Annotated[cGcPlayerShipOwnership, 0xCEBB0]
    mPlayerVehicleOwnership: Annotated[cGcPlayerVehicleOwnership, 0xD9430]
    mPlayerCreatureOwnership: Annotated[cGcPlayerCreatureOwnership, 0xD9B70]
    mPlayerMultitoolOwnership: Annotated[cGcPlayerMultitoolOwnership, 0x29ECF0]
    mPlayerFreighterOwnership: Annotated[
        tuple[cGcPlayerFreighterOwnership, ...],
        Field(cGcPlayerFreighterOwnership * 4, 0x2A4D90),
    ]
    mPlayerFleetManager: Annotated[
        tuple[cGcPlayerFleetManager, ...],
        Field(cGcPlayerFleetManager * 4, 0x2A6090),
    ]
    mPlayerSquadronOwnership: Annotated[cGcPlayerSquadronOwnership, 0x2B5F54]
    mDiscoveryManager: Annotated[cGcDiscoveryManager, 0x2BA3B8]
    # Found passed into cGcPersistentInteractionsManager::LoadGalacticAddressBuffers wherever it is called.
    # Need to subtract the offset of cGcGamestate from the address in the exe which is the pointer to the
    # start of cGcApplication::Data
    mSavedInteractionsManager: Annotated[cGcPersistentInteractionsManager, 0x2FDD80]

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? C7 41")
    def cGcGameState(self, this: "_Pointer[cGcGameState]"): ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 88 54 24")
    def OnSaveProgressCompleted(
        self,
        this: "_Pointer[cGcGameState]",
        a2: c_uint64,
        lbShowMessage: Annotated[bool, c_bool],
        lbFullSave: Annotated[bool, c_bool],
        leSaveReason: c_int32,
    ): ...

    @function_hook("44 89 44 24 ? 89 54 24 ? 48 89 4C 24 ? 55 56")
    def LoadFromPersistentStorage(
        self,
        this: "_Pointer[cGcGameState]",
        leSlot: Annotated[int, c_uint32],
        a3: c_int32,
        lbNetworkClientLoad: Annotated[bool, c_bool],
    ) -> c_uint64: ...

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? F3 0F 10 91"
    )
    def Update(self, this: "_Pointer[cGcGameState]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("40 53 56 41 54 41 55 41 56")
    def ComputeWarpCapability(
        self,
        this: "_Pointer[cGcGameState]",
        result: _Pointer[WarpCapabilityResult],
        lfLightyearDistance: Annotated[float, c_float],
        lbIsCenter: Annotated[bool, c_bool],
        lJumpTargetPackedUA: Annotated[int, c_uint64],
        lStarData: _Pointer[cGcGalaxyAttributeGenerator.StarSystemKeyAttributes],
    ) -> c_uint64:  # WarpCapabilityResult *
        ...


class cTkFSM(Structure):
    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 33 ED 48 89 51")
    def Construct(
        self,
        this: "_Pointer[cTkFSM]",
        lpOffsetTable: c_uint64,
        lInitialState: c_uint64,
    ): ...

    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 48 8B 05 ? ? ? ? 48 8B D9 0F 29 74 24")
    def Update(self, this: "_Pointer[cTkFSM]"):
        """Run every frame. Depsite `this` being of type `cTkFSM`, it's actually a pointer to the
        `cGcApplication` singleton since it has `cTkFSM` as a subclass."""
        ...

    @function_hook("48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 4C 8B 51 ? 49 8B E8")
    def StateChange(
        self,
        this: "_Pointer[cTkFSM]",
        lNewStateID: c_uint64,
        lpUserData: c_uint64,
        lbForceRestart: Annotated[bool, c_bool],
    ): ...


@partial_struct
class cTkHavokCharacterController(Structure):
    mTargetVelocity: Annotated[basic.cTkVector3, 0xE0]


class cGcPlayerController(Structure): ...


@partial_struct
class cGcPlayerCommunicator(Structure):
    # Found in cGcPlayerCommunicator::Update passed into cGcInteractionComponent::FindFirstTypedComponent
    mActiveNode: Annotated[basic.TkHandle, 0x78]

    @function_hook("F3 0F 11 4C 24 ? 4C 8B DC 55 56 49 8D AB")
    def Update(
        self,
        this: "_Pointer[cGcPlayerCommunicator]",
        lfTimeStep: Annotated[float, c_float],
    ): ...


@partial_struct
class cGcPlayer(Structure):
    mRootNode: Annotated[basic.TkHandle, 0xE0]
    mEquipmentNode: Annotated[basic.TkHandle, 0xE0]
    mPhysicsController: Annotated[_Pointer[cTkHavokCharacterController], 0x160]
    # Found in cGcPlayer::Prepare around where the number 0xFA83126E / -92073362 is
    mbSpawned: Annotated[bool, Field(c_bool, 0x3180)]
    mbIsRunning: Annotated[bool, Field(c_bool, 0x3182)]
    mbIsAutoWalking: Annotated[bool, Field(c_bool, 0x3188)]
    mfJetpackTank: Annotated[float, Field(c_float, 0x3534)]
    # Found Above the cGcPlayer::UpdateGraphics call in cGcPlayer::CheckFallenThroughFloor
    mfAirTimer: Annotated[float, Field(c_float, 0x3570)]
    mfStamina: Annotated[float, Field(c_float, 0x5620)]
    mbIsDying: Annotated[bool, Field(c_bool, 0x5700)]
    mCommunicator: Annotated[cGcPlayerCommunicator, 0x58E0]

    @function_hook("40 55 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 4C 8B F9 48 8B 0D ? ? ? ? 83 B9")
    def CheckFallenThroughFloor(self, this: "_Pointer[cGcPlayer]"): ...

    @function_hook("48 8B C4 4C 89 48 ? 44 89 40 ? 55 56")
    def TakeDamage(
        self,
        this: "_Pointer[cGcPlayer]",
        lfDamageAmount: Annotated[float, c_float],
        leDamageType: c_enum32[enums.cGcDamageType],
        lDamageId: _Pointer[basic.TkID[0x10]],
        lDir: _Pointer[basic.Vector3f],
        lpOwner: c_uint64,  # cGcOwnerConcept *
        laEffectsDamageMultipliers: c_uint64,  # std::vector<cGcCombatEffectDamageMultiplier,TkSTLAllocatorShim<cGcCombatEffectDamageMultiplier,4,-1> > *  # noqa
    ): ...

    @function_hook("40 53 48 81 EC E0 00 00 00 48 8B D9 E8 ?? ?? ?? ?? 83 78 10 05")
    def OnEnteredCockpit(self, this: "_Pointer[cGcPlayer]"): ...

    @function_hook("40 53 48 83 EC 20 48 8B 1D ?? ?? ?? ?? E8 ?? ?? ?? ?? 83 78 10 05 75 ?? 48 8B")
    def GetDominantHand(self, this: "_Pointer[cGcPlayer]") -> c_int64: ...

    @function_hook("48 8B C4 55 53 56 41 55 41 57")
    def Update(self, this: "_Pointer[cGcPlayer]", lfStep: Annotated[float, c_float]): ...

    @function_hook("48 8B C4 48 89 58 ? 48 89 70 ? 57 48 81 EC ? ? ? ? 0F 29 70 ? 0F B6 F2")
    def UpdateGraphics(self, this: "_Pointer[cGcPlayer]", lbSetNode: Annotated[bool, c_bool]): ...

    @function_hook("48 8B C4 55 53 56 57 41 54 41 56 41 57 48 8D 6C 24")
    def Prepare(self, this: "_Pointer[cGcPlayer]", lpController: _Pointer[cGcPlayerController]): ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ? 48 8B FA 48 8B D9")
    def SetToPosition(
        self,
        this: "_Pointer[cGcPlayer]",
        lPos: _Pointer[basic.cTkBigPos],
        lDir: _Pointer[basic.cTkVector3],
        lVel: _Pointer[basic.cTkVector3],
    ): ...

    @function_hook("48 89 4C 24 ? 55 41 55 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 45 33 ED")
    def RenderInventoryEditor(self, this: "_Pointer[cGcPlayer]"): ...

    @function_hook("48 8B C4 48 89 48 ? 55 41 55 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 78")
    def RenderNGui(self, this: "_Pointer[cGcPlayer]"): ...


class cGcPlanetGenerationInputData(nmse.cGcPlanetGenerationInputData):
    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 0F 57 C0 33 FF 0F 11 01 48 8B D9 48 89 7C 24")
    def SetDefaults(self, this: "_Pointer[cGcPlanetGenerationInputData]"): ...


@partial_struct
class cGcTerrainRegionMap(Structure):
    mfCachedRadius: Annotated[float, Field(c_float, 0x30)]
    mMatrix: Annotated[basic.cTkMatrix34, 0xD3490]
    mRootNode: Annotated[basic.TkHandle, 0x9E808]

    @function_hook(
        "48 8B C4 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 "
        "? 48 8D B1"
    )
    def Construct(
        self,
        this: "_Pointer[cGcTerrainRegionMap]",
        lRootNode: basic.TkHandle,
        lpGeneratorData: c_uint64,  # cTkVoxelGeneratorData*
        lpBuildingData: c_uint64,  # cGcPlanetBuildingData*
        liRadius: c_int32,
        liBorderRegions: c_int32,
    ): ...


@partial_struct
class cGcPlanet(Structure):
    # This is found in cGcSolarSystem::cGcSolarSystem near the call to cGcPlanet::cGcPlanet
    _total_size_ = 0xD9070
    # Most of these found in cGcPlanet::Construct or cGcPlanet::cGcPlanet
    mPlanetDiscoveryData: Annotated[cGcDiscoveryData, 0x8]
    miPlanetIndex: Annotated[int, Field(c_int32, 0x50)]
    mPlanetData: Annotated[nmse.cGcPlanetData, 0x60]
    mPlanetGenerationInputData: Annotated[cGcPlanetGenerationInputData, 0x3A60]
    mRegionMap: Annotated[cGcTerrainRegionMap, 0x3B80]
    mNode: Annotated[basic.TkHandle, 0xD73D8]
    mAtmosphereNode: Annotated[basic.TkHandle, 0xD73DC]
    mRingNode: Annotated[basic.TkHandle, 0xD73E4]
    mPosition: Annotated[basic.Vector3f, 0xD73F0]

    mpEnvProperties: Annotated[_Pointer[nmse.cGcEnvironmentProperties], 0xD9058]
    mpSkyProperties: Annotated[_Pointer[nmse.cGcPlanetSkyProperties], 0xD9060]

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 45 33 FF 48 C7 41 ? ? ? ? ? 44 "
        "89 79"
    )
    def cGcPlanet(self, this: "_Pointer[cGcPlanet]"): ...

    @function_hook("48 8B C4 48 89 58 ? 4C 89 40 ? 89 50 ? 48 89 48 ? 55 56 57 41 54 41 55")
    def Generate(
        self,
        this: "_Pointer[cGcPlanet]",
        lbLoad: Annotated[bool, c_bool],
        lPosition: _Pointer[basic.Vector3f],
        lSolarSystemDiscoveryData: _Pointer[cGcDiscoveryData],
        lGenerationInputParams: _Pointer[nmse.cGcPlanetGenerationInputData],
    ): ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 33 F6 89 51 ? 89 B1")
    def Construct(self, this: "_Pointer[cGcPlanet]", liIndex: c_int32): ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 56 48 83 EC ? 48 8B D9 8B 89")
    def SetupRegionMap(self, this: "_Pointer[cGcPlanet]"): ...

    @function_hook("48 8B C4 53 57 48 81 EC ? ? ? ? F3 0F 10 15")
    def UpdateClouds(self, this: "_Pointer[cGcPlanet]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("40 53 48 83 EC ? 83 B9 ? ? ? ? ? 48 8B D9 0F 29 74 24 ? 75")
    def UpdateGravity(
        self,
        this: "_Pointer[cGcPlanet]",
        lfNewGravityMultiplier: Annotated[float, c_float],
    ): ...

    @function_hook("40 55 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 80 3D")
    def UpdateWeather(self, this: "_Pointer[cGcPlanet]", lfTimeStep: Annotated[float, c_float]): ...


@partial_struct
class cGcGalaxyAttributesAtAddress(Structure):
    # Looks the same as 4.13
    mVoxel: Annotated[cGcGalaxyVoxelAttributesData, 0x0]
    mVoxelPrimaryColour: Annotated[basic.Colour, 0x90]
    mVoxelSecondaryColour: Annotated[basic.Colour, 0x90]
    mStar: Annotated[cGcGalaxyStarAttributesData, 0xB0]
    mbValid: Annotated[bool, Field(c_bool, 0x258)]

    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 44 8B C2 C6 44 24")
    def Classify(self, this: "_Pointer[cGcGalaxyAttributesAtAddress]", lUA: c_uint64): ...


class cGcSolarSystemGeometry(Structure): ...


@partial_struct
class cGcSolarSystemGenerator(Structure):
    mRNG: Annotated[cTkPersonalRNG, 0x510]

    @partial_struct
    class GenerationData(Structure):
        _mpSolarSystem: Annotated[int, Field(c_uint64, 0x0)]
        mMetaData: Annotated[_Pointer[nmse.cGcSolarSystemData], 0x8]

        @property
        def mpSolarSystem(self):
            return cGcSolarSystem.from_address(self._mpSolarSystem)

    @function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 55 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? B8 ? ? ? ? "
        "E8 ? ? ? ? 48 2B E0 33 F6 0F 29 B4 24"
    )
    def GenerateQueryInfo(
        self,
        this: "_Pointer[cGcSolarSystemGenerator]",
        lSeed: _Pointer[basic.cTkSeed],
        lAttributes: _Pointer[cGcGalaxyAttributesAtAddress],
        lData: "_Pointer[cGcSolarSystemGenerator.GenerationData]",
    ): ...

    @function_hook(
        "48 8B C4 4C 89 48 ? 4C 89 40 ? 48 89 50 ? 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? "
        "? ? ? 48 81 EC ? ? ? ? 44 0F 29 B8"
    )
    def GeneratePlanetPositions(
        self,
        this: "_Pointer[cGcSolarSystemGenerator]",
        lAttributes: _Pointer[cGcGalaxyAttributesAtAddress],
        lData: "_Pointer[cGcSolarSystemGenerator.GenerationData]",
        lpGeometry: _Pointer[cGcSolarSystemGeometry],
    ): ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B FA 49 8B D9")
    def GenerateBasics(
        self,
        this: "_Pointer[cGcSolarSystemGenerator]",
        lSeed: _Pointer[basic.cTkSeed],
        lAttributes: _Pointer[cGcGalaxyAttributesAtAddress],
        lStarKeyAttributes: _Pointer[cGcGalaxyAttributeGenerator.StarSystemKeyAttributes],
        lData: "_Pointer[cGcSolarSystemGenerator.GenerationData]",
    ): ...

    @function_hook(
        "48 8B C4 4C 89 48 ? 4C 89 40 ? 48 89 50 ? 48 89 48 ? 53 55 56 57 41 54 41 55 41 56 41 57 48 81 EC ? "
        "? ? ? 4C 63 9A"
    )
    def GeneratePlanetBiomes(
        self,
        this: "_Pointer[cGcSolarSystemGenerator]",
        lAttributes: _Pointer[cGcGalaxyAttributesAtAddress],
        lData: "_Pointer[cGcSolarSystemGenerator.GenerationData]",
        lStarKeyAttributes: _Pointer[cGcGalaxyAttributeGenerator.StarSystemKeyAttributes],
    ): ...


@partial_struct
class cGcSolarSystem(Structure):
    _total_size_ = 0x51C920
    # These can be found in cGcSolarSystem::cGcSolarSystem
    mSolarSystemData: Annotated[nmse.cGcSolarSystemData, 0x0]
    mGalaxyAttributes: Annotated[cGcGalaxyAttributesAtAddress, 0x23D0]
    maPlanets: Annotated[tuple[cGcPlanet, ...], Field(cGcPlanet * 6, 0x2630)]
    miPrimaryPlanet: Annotated[int, Field(c_int32, 0x5188D0)]
    mSolarSystemGenerator: Annotated[cGcSolarSystemGenerator, 0x51B9A0]
    # Found in cGcPlayerState::StoreCurrentSystemSpaceStationEndpoint
    mSpaceStationNode: Annotated[basic.TkHandle, 0x51C088]

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F 29 74 24 ? 48 8B F9 48 8B D9")
    def cGcSolarSystem(self, this: "_Pointer[cGcSolarSystem]"): ...

    @function_hook("48 8B C4 55 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 83 3D")
    def Construct(self, this: "_Pointer[cGcSolarSystem]"): ...

    @function_hook("40 55 53 56 57 41 56 48 8B EC 48 83 EC ? 83 3D")
    def OnLeavePlanetOrbit(self, this: "_Pointer[cGcSolarSystem]", lbAnnounceOSD: Annotated[bool, c_bool]):
        """lbAnnounceOSD not used."""
        ...

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 45 33 F6"
    )
    def OnEnterPlanetOrbit(
        self, this: "_Pointer[cGcSolarSystem]", lbAnnounceOSD: Annotated[bool, c_bool]
    ): ...

    @function_hook(
        "48 8B C4 55 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 89 58 ? 48 89 70 ? 48 8B F1 48 89 78 ? 49 8B F8"
    )
    def Generate(
        self,
        this: "_Pointer[cGcSolarSystem]",
        lbUseSettingsFile: Annotated[bool, c_bool],
        lSeed: _Pointer[basic.GcSeed],
    ): ...

    @function_hook("48 8B C4 55 53 56 41 55 41 56")
    def Update(self, this: "_Pointer[cGcSolarSystem]", lfTimeStep: Annotated[float, c_float]): ...


@partial_struct
class cGcPlayerEnvironment(Structure):
    mPlayerTM: Annotated[basic.cTkMatrix34, Field(basic.cTkMatrix34, 0x0)]
    mUp: Annotated[basic.Vector3f, Field(basic.Vector3f, 0x40)]

    # Found below the call to cTkDynamicGravityControl::GetGravity in cGcPlayerEnvironment::Update
    miNearestPlanetIndex: Annotated[int, Field(c_uint32, 0x2D8)]
    mfDistanceFromPlanet: Annotated[float, Field(c_float, 0x2DC)]
    mfNearestPlanetSealevel: Annotated[float, Field(c_float, 0x2E0)]
    mNearestPlanetPos: Annotated[basic.Vector3f, Field(basic.Vector3f, 0x2EC)]
    mbInsidePlanetAtmosphere: Annotated[bool, Field(c_bool, 0x308)]
    meLocation: Annotated[
        enums.EnvironmentLocation.Enum,
        Field(c_enum32[enums.EnvironmentLocation.Enum], 0x474),
    ]
    meLocationStable: Annotated[
        enums.EnvironmentLocation.Enum,
        Field(c_enum32[enums.EnvironmentLocation.Enum], 0x480),
    ]

    @function_hook("48 83 EC ? 80 B9 ? ? ? ? ? C6 04 24")
    def IsOnboardOwnFreighter(self, this: "_Pointer[cGcPlayerEnvironment]") -> c_bool: ...

    @function_hook(
        "8B 81 ? ? ? ? 83 F8 ? 74 ? 83 C0 ? 83 F8 ? 76 ? 32 C0 C3 B0 ? C3 CC CC CC CC CC CC CC 48 8B 02"
    )
    def IsOnPlanet(self, this: "_Pointer[cGcPlayerEnvironment]") -> c_bool: ...

    @function_hook("48 8B C4 F3 0F 11 48 ? 48 89 48 ? 55 53 41 54")
    def Update(
        self,
        this: "_Pointer[cGcPlayerEnvironment]",
        lfTimeStep: Annotated[float, c_float],
    ): ...


@partial_struct
class cGcSky(Structure):
    eStormState = enums.eStormState

    # Found in cGcSky::SetSunAngle
    mSunDirection: Annotated[basic.Vector3f, Field(basic.Vector3f, 0x500)]

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 54 41 56 41 57 48 83 EC ? 4C 8B 15")
    def SetStormState(self, this: "_Pointer[cGcSky]", leNewState: c_enum32[eStormState]): ...

    @function_hook("40 53 48 83 EC ? 0F 28 C1 0F 29 7C 24 ? F3 0F 5E 05")
    def SetSunAngle(self, this: "_Pointer[cGcSky]", lfAngle: Annotated[float, c_float]): ...

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 ? "
        "48 8B D9 0F 29 78 ? 44 0F 29 40"
    )
    def Update(self, this: "_Pointer[cGcSky]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("48 8B C4 53 48 81 EC ? ? ? ? 4C 8B 05 ? ? ? ? 48 8B D9")
    def UpdateSunPosition(self, this: "_Pointer[cGcSky]", lfAngle: Annotated[float, c_float]): ...


@partial_struct
class cGcEnvironment(Structure):
    # Passed into cGcSky::Update but offset includes the offset of cGcEnvironment.
    mSky: Annotated[cGcSky, 0x10]
    # Passed into cGcPlayerEnvironment::Update
    mPlayerEnvironment: Annotated[cGcPlayerEnvironment, 0x8B0]

    @function_hook(
        "48 8B C4 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 "
        "? 4C 8B F9"
    )
    def UpdateRender(self, this: "_Pointer[cGcEnvironment]"):
        # TODO: There could be a few good functions to get which are called in here...
        ...

    @function_hook("40 56 48 81 EC ? ? ? ? 66 0F 6F 05")
    def Update(self, this: "_Pointer[cGcEnvironment]", lfTimeStep: Annotated[float, c_float]): ...


class cGcPlayerExperienceDirector(Structure):
    @function_hook(
        "48 8B C4 48 89 58 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 99 ? ? "
        "? ? 48 8B F1 0F 29 70 ? 0F 29 78 ? 66 0F 6F 3D"
    )
    def Update(
        self,
        this: "_Pointer[cGcPlayerExperienceDirector]",
        lfTimeStep: Annotated[float, c_float],
    ): ...


class cGcEcosystem(Structure):
    @function_hook("48 8B C4 48 89 48 ? 55 41 56 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 89 58 ? 48 8B 1D")
    def Update(self, this: "_Pointer[cGcEcosystem]", lfTimeStep: Annotated[float, c_float]): ...


@partial_struct
class cGcFishingData(Structure):
    @function_hook("48 8B C4 44 89 48 ? 4C 89 40 ? 48 89 50 ? 48 89 48 ? 55 53 48 8D A8")
    def GetRandomFish(
        self,
        this: "_Pointer[cGcFishingData]",
        lpPos: _Pointer[basic.cTkVector3],
        lpID: _Pointer[basic.TkID0x10],
        leQuality: c_enum32[enums.cGcItemQuality],
        lpMass: _Pointer[c_float],
        lUnknown: c_int32,
    ) -> c_uint64:  # presumably nmse.cGcFishData
        """Get a random fish.
        This is called when the bobber hits the water.
        lpMass is set within the function and the value is determined by cGcFishingData::GetRandomFishMass."""
        ...


@partial_struct
class cGcFishLaser(Structure):
    class eMode(IntEnum):
        Inactive = 0x0
        Error = 0x2
        Chase = 0x5
        Escaped = 0x7

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 55 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 8D 42")
    def OnModeChanged(
        self,
        this: "_Pointer[cGcFishLaser]",
        mePrevMode: c_enum32[eMode],
        meNewMode: c_enum32[eMode],
    ): ...

    @function_hook("40 53 48 83 EC ? 8B 41 ? 48 8B D9 3B D0")
    def SetMode(self, this: "_Pointer[cGcFishLaser]", meMode: c_enum32[eMode]): ...


@partial_struct
class cGcFishManager(Structure):
    # Assigned from cGcFishingData.GetRandomFish
    mCurrentFish: Annotated[_Pointer[nmse.cGcFishData], 0x1C8]

    @function_hook("F3 0F 11 4C 24 ? 55 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 44 0F 29 8C 24")
    def Update(self, this: "_Pointer[cGcFishManager]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("48 89 5C 24 ? 48 89 7C 24 ? 55 48 8B EC 48 81 EC ? ? ? ? 80 79")
    def SetFishing(self, this: "_Pointer[cGcFishManager]", lpFishLaser: _Pointer[cGcFishLaser]): ...


@partial_struct
class cGcMarkerPoint(Structure):
    # Size found in the vector allocator in cGcMarkerList::TryAddMarker
    _total_size_ = 0x270
    # Found in cGcMarkerPoint::Reset
    # Note: These first 2 I'm not sure about...
    mPosition: Annotated[basic.cTkPhysRelVec3, 0x20]
    mCenterOffset: Annotated[basic.Vector3f, 0x40]
    mCustomName: Annotated[basic.cTkFixedString0x40, 0x58]
    mCustomSubtitle: Annotated[basic.cTkFixedString0x80, 0x98]
    maCustomIcons: Annotated[tuple[int, int, int], Field(c_int32 * 3, 0x118)]
    mNode: Annotated[basic.TkHandle, 0x124]
    mModelNode: Annotated[basic.TkHandle, 0x128]
    mEntranceNode: Annotated[basic.TkHandle, 0x12C]
    meBuildingClass: Annotated[
        c_enum32[enums.cGcBuildingClassification],
        Field(c_enum32[enums.cGcBuildingClassification], 0x138),
    ]
    meType: Annotated[c_enum8[enums.cGcMarkerType], 0x25B]
    # The following is a bitfield. Previously there were individual bytes, but now HG checks individual bits.
    # mUnknown & 4 -> mbFollowNode
    mUnknown: Annotated[c_ubyte, 0x267]

    @static_function_hook("40 53 48 83 EC ? 33 C0 0F 57 C0 0F 11 01 48 8B D9")
    @staticmethod
    def cGcMarkerPoint(address: c_uint64):
        """Construct an instance of the cGcMarkerPoint at the provided address"""
        ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F 28 05 ? ? ? ? 48 8D 79")
    def Reset(self, this: "_Pointer[cGcMarkerPoint]"): ...

    @function_hook("40 55 53 56 57 41 56 48 8D 6C 24 ? 48 81 EC ? ? ? ? 0F B6 99")
    def Update(self, this: "_Pointer[cGcMarkerPoint]"): ...

    @function_hook("48 89 74 24 ? 57 48 83 EC ? 48 8B F9 48 8B F2 48 8B 89")
    def IsEqual(
        self,
        this: "_Pointer[cGcMarkerPoint]",
        lOther: "_Pointer[cGcMarkerPoint]",
        a3: c_uint64,
    ) -> c_bool:
        """Check to see if two markers are equal. This will check a number of properties, including their
        position."""
        ...


@partial_struct
class cGcMarkerList(Structure):
    maMarkerObjects: Annotated[basic.TkStd.tk_vector[cGcMarkerPoint], 0x0]

    @function_hook("48 89 5C 24 ? 55 57 41 56 48 83 EC ? 40 32 ED")
    def RemoveMarker(
        self,
        this: "_Pointer[cGcMarkerList]",
        lExampleMarker: _Pointer[cGcMarkerPoint],
    ) -> c_uint64: ...

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? F6 82"
    )
    def TryAddMarker(
        self,
        this: "_Pointer[cGcMarkerList]",
        lPoint: _Pointer[cGcMarkerPoint],
        lbUpdateTime: Annotated[bool, c_bool],
    ) -> c_char: ...


@partial_struct
class cGcScanManager(Structure):
    # Passed in to cGcScanManager::UpdateConstantMarkers
    mMarkerList: Annotated[cGcMarkerList, 0x2240]

    @function_hook(
        "48 89 4C 24 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 2B "
        "E0 0F 29 B4 24 ? ? ? ? 4C 8B F9"
    )
    def UpdateConstantMarkers(self, this: "_Pointer[cGcScanManager]"): ...

    @function_hook("48 89 4C 24 ? 55 53 57 41 54 41 57 48 8D AC 24 ? ? ? ? B8")
    def UpdateScannableMarkers(self, this: "_Pointer[cGcScanManager]"): ...


@partial_struct
class cGcSimulation(Structure):
    # Passed in to cGcScanManager::UpdateConstantMarkers
    mScanManager: Annotated[cGcScanManager, 0xF1B0]
    # Found in cGcSimulation::Update. Passed into cGcEnvironment::Update.
    mEnvironment: Annotated[cGcEnvironment, 0xAC8B0]
    mEcosystem: Annotated[cGcEcosystem, 0xB3C20]
    mFishManager: Annotated[cGcFishManager, 0x24D520]
    # Found in cGcSimulation::Update. Passed into cGcSolarSystem::Update.
    mpSolarSystem: Annotated[_Pointer[cGcSolarSystem], 0x24DFD0]
    mPlayerExperienceDirector: Annotated[cGcPlayerExperienceDirector, 0x24E720]
    # Found in cGcSimulation::Update. Passed into cGcPlayer::Update
    mPlayer: Annotated[cGcPlayer, 0x24F6D0]
    # In cGcSimulation::Update
    mCurrentUA: Annotated[int, Field(c_uint64, 0x255300)]
    # Found in cGcSimulation::Construct
    mSimulationRootNode: Annotated[basic.TkHandle, 0x256CA0]

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 33 C0 0F 29 74 24"
    )
    def cGcSimulation(self, this: "_Pointer[cGcSimulation]"): ...

    @function_hook("48 89 5C 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 45 33 FF")
    def Construct(self, this: "_Pointer[cGcSimulation]"): ...

    @function_hook("48 8B C4 89 50 ? 55 48 8D 6C 24")
    def Update(
        self,
        this: "_Pointer[cGcSimulation]",
        leMode: c_uint32,  # SimulationUpdateMode
        lfTimeStep: Annotated[float, c_float],
    ): ...


@partial_struct
class cGcHUDLayer(Structure):
    # This is unchanged from 4.13
    _total_size_ = 0xB0

    mpData: Annotated[_Pointer[nmse.cGcHUDLayerData], 0xA0]


@partial_struct
class cGcHUDImage(Structure):
    # This is unchanged from 4.13
    _total_size_ = 0xD0

    mpData: Annotated[_Pointer[nmse.cGcHUDImageData], 0x90]
    mColourStart: Annotated[basic.Colour, 0xA0]
    mColourEnd: Annotated[basic.Colour, 0xB0]


@partial_struct
class cGcHUDText(Structure):
    # This is unchanged from 4.13
    _total_size_ = 0x280

    mBuffer: Annotated[basic.cTkFixedWString0x100, 0x0]
    mpData: Annotated[_Pointer[nmse.cGcHUDTextData], 0x270]


@partial_struct
class cGcHUD(Structure):
    # This is unchanged from 4.13
    _total_size_ = 0x20040
    maLayers: Annotated[tuple[cGcHUDLayer, ...], Field(cGcHUDLayer * 0x80, 0x10)]
    miNumLayers: Annotated[int, Field(c_int32, 0x5810)]
    maImages: Annotated[tuple[cGcHUDImage, ...], Field(cGcHUDImage * 0x80, 0x5820)]
    miNumImages: Annotated[int, Field(c_int32, 0xC020)]
    maTexts: Annotated[tuple[cGcHUDText, ...], Field(cGcHUDText * 0x80, 0xC030)]
    miNumTexts: Annotated[int, Field(c_int32, 0x20030)]

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 33 ED 4C 8B F1 89 29")
    def cGcHUD(self, this: "_Pointer[cGcHUD]"): ...


@partial_struct
class cGcHUDMarker(Structure):
    _total_size_ = 0x1610

    mColour: Annotated[basic.Colour, 0x0]
    mData: Annotated[cGcMarkerPoint, 0x10]

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 48 8B F1 48 83 C1"
    )
    def cGcHUDMarker(self, this: "_Pointer[cGcHUDMarker]"): ...


@partial_struct
class cGcPlayerHUD(cGcHUD):
    mHelmetGUI: Annotated[cGcNGui, 0x20040]
    mCrosshairGui: Annotated[cGcNGui, 0x204B8]
    mHelmetLines: Annotated[cGcNGui, 0x20930]
    mQuickMenu: Annotated[cGcNGuiLayer, 0x20DB0]  # Maybe
    maMarkers: Annotated[tuple[cGcHUDMarker, ...], Field(cGcHUDMarker * 0x80, 0x20FD0)]
    # Found in cGcPlayerHUD::LoadData
    mpHUDShieldLayer: Annotated[_Pointer[cGcNGuiLayer], 0xE9DF8]

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 0F 29 74 24 ? 48 8B F9 E8 "
        "? ? ? ? 48 8D 9F"
    )
    def cGcPlayerHUD(self, this: "_Pointer[cGcPlayerHUD]"): ...

    @function_hook("48 8B C4 55 57 48 8D 68 ? 48 81 EC ? ? ? ? 48 8B 91")
    def RenderIndicatorPanel(self, this: "_Pointer[cGcPlayerHUD]"): ...

    @function_hook("48 8B C4 48 89 48 ? 55 41 56 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 83 B9")
    def RenderWeaponPanel(self, this: "_Pointer[cGcPlayerHUD]"): ...

    @function_hook("48 8B C4 55 53 56 41 54 41 55 41 56")
    def RenderCrosshair(self, this: "_Pointer[cGcPlayerHUD]"): ...

    @function_hook("F3 0F 11 4C 24 ? 48 89 4C 24 ? 55 41 57")
    def Update(self, this: "_Pointer[cGcPlayerHUD]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 55 57 41 54 41 56 41 57 48 8B EC 48 83 EC ? 48 8D B1")
    def LoadData(self, this: "_Pointer[cGcPlayerHUD]"): ...


class cGcQuickMenu(Structure):
    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B F1 48 8D 59 ? BF ? ? ? ? 33 ED 40 88 "
        "2B"
    )
    def cGcQuickMenu(self, this: "_Pointer[cGcQuickMenu]"): ...


@partial_struct
class cGcHUDManager(Structure):
    # Found in cGcHUDManager::cGcHUDManager
    mPlayerHUD: Annotated[cGcPlayerHUD, 0xA0]
    mShipHUD: Annotated[cGcShipHUD, 0xE9550]
    mQuickMenu: Annotated[cGcQuickMenu, 0x111EF0]
    mChargingInventory: Annotated[cGcInventoryStore, 0x120A00]

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 33 F6 48 8B F9 48 89 71 ? 48 89 71")
    def cGcHUDManager(self, this: "_Pointer[cGcHUDManager]", a2: c_bool): ...

    @function_hook("48 89 5C 24 ? 55 56 57 48 81 EC ? ? ? ? 4C 8B 89")
    def RemoveOSDMessage(self, this: "_Pointer[cGcHUDManager]", message: c_char_p64) -> c_bool: ...


@partial_struct
class cGcPlayerWeapon(Structure):
    # Found in cGcPlayerWeapon::GetChargeTime
    meWeaponMode: Annotated[int, Field(c_uint32, 0xF6C)]
    # Found in cGcPlayerWeapon::Update below the call to cGcPlayerState::GetStatValue with leStat = 6
    mfHeatTime: Annotated[float, Field(c_float, 0x2310)]
    mfCoolSpeed: Annotated[float, Field(c_float, 0x2318)]
    mbOverheat: Annotated[bool, Field(c_bool, 0x231C)]
    # The number here has probably changed...
    maiAmmo: Annotated[list[int], Field(c_int32 * 19, 0x23F0)]
    mbCharging: Annotated[bool, Field(c_bool, 0x24F6)]
    mfChargeTime: Annotated[float, Field(c_float, 0x24F8)]
    # Found above the call to cGcPlayerWeapon::GetChargeTime in cGcPlayerWeapon::Update

    @function_hook("48 83 EC ? 48 63 81 ? ? ? ? 83 F8")
    def GetChargeFactor(self, this: "_Pointer[cGcPlayerWeapon]") -> c_float: ...

    @function_hook("48 83 EC ? 48 63 91 ? ? ? ? 8B CA")
    def GetChargeTime(self, this: "_Pointer[cGcPlayerWeapon]") -> c_float: ...

    @function_hook("F3 0F 11 4C 24 ? 55 56 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 80 79")
    def Update(self, this: "_Pointer[cGcPlayerWeapon]", lfTimeStep: Annotated[float, c_float]): ...


@partial_struct
class cGcAlienPuzzleOption(Structure):
    _total_size_ = 0xF8
    Name: Annotated[basic.cTkFixedString[0x20], Field(basic.cTkFixedString[0x20], 0x20)]
    Rewards: Annotated[
        list[basic.cTkFixedString[0x10]],
        Field(basic.cTkDynamicArray[basic.cTkFixedString[0x10]], 0xC0),
    ]


@partial_struct
class cGcInteractionComponent(Structure):
    mpData: Annotated[_Pointer[nmse.cGcInteractionComponentData], 0x30]

    @function_hook("44 88 4C 24 ? 44 88 44 24 ? 48 89 54 24 ? 53")
    def GiveReward(
        self,
        this: "_Pointer[cGcInteractionComponent]",
        lOption: _Pointer[cGcAlienPuzzleOption],
        lbPeek: Annotated[bool, c_bool],
        lbForceShowMessage: Annotated[bool, c_bool],
        lbForceSilent: Annotated[bool, c_bool],
    ) -> c_uint64: ...

    @function_hook("48 8B 81 ? ? ? ? 48 85 C0 74 ? 48 83 B9 ? ? ? ? ? 75 ? 48 83 B9")
    def GetPuzzle(
        self,
        this: "_Pointer[cGcInteractionComponent]",
    ) -> c_uint64:  # cGcAlienPuzzleEntry *
        ...

    @static_function_hook(
        "4C 8B DC 48 83 EC ? 49 C7 43 ? ? ? ? ? 41 C7 43 ? ? ? ? ? 83 FA ? 75 ? 48 8D 05 ? ? ? ? 45 33 C0 49 "
        "89 43 ? 4D 8D 4B ? 49 8D 43 ? 49 89 43 ? 48 8D 15 ? ? ? ? 49 8D 43 ? 49 89 43 ? E8 ? ? ? ? 48 8B 84 "
        "24 ? ? ? ? 48 83 C4 ? C3 48 8D 84 24 ? ? ? ? 48 89 44 24 ? 48 8D 54 24 ? 48 8D 84 24 ? ? ? ? 48 89 "
        "44 24 ? 0F 28 44 24 ? 66 0F 7F 44 24 ? E8 ? ? ? ? 48 8B 84 24 ? ? ? ? 48 83 C4 ? C3 CC CC CC CC CC "
        "CC CC CC CC CC CC CC CC 48 89 5C 24 ? 57 48 83 EC ? 33 FF"
    )
    @staticmethod
    def FindFirstTypedComponent(
        lNodeHandle: basic.TkHandle,
        lbSameModelOnly: Annotated[bool, c_bool],
    ) -> c_uint64:  # cGcInteractionComponent *
        ...

    @function_hook("40 55 41 55 41 56 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 4C 8B F1")
    def DoInteractionEvent(
        self,
        this: "_Pointer[cGcInteractionComponent]",
        leEvent: c_enum32[enums.cGcInteractionType],
    ): ...

    @function_hook("40 53 48 83 EC ? 48 8B D9 48 8B 0D ? ? ? ? 8B 93")
    def GetInteractionData(
        self,
        this: "_Pointer[cGcInteractionComponent]",
    ) -> c_uint64:  # cGcInteractionData *
        ...


@partial_struct
class cGcFrontendManager(Structure):
    # Found in cGcFrontendManager::cGcFrontendManager
    mFrontendRoot: Annotated[cGcNGuiLayer, 0x2468]

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 48 8D 05"
    )
    def cGcFrontendManager(self, this: "_Pointer[cGcFrontendManager]"): ...

    @function_hook("48 63 81 ? ? ? ? 48 03 C0 83 BC C1 ? ? ? ? ? 75 ? 89 94 C1")
    def QueueFrontendPage(
        self,
        this: "_Pointer[cGcFrontendManager]",
        lPageToQueue: Annotated[int, c_uint32],
        lfStartDelay: Annotated[float, c_float],
        lpInteraction: _Pointer[cGcInteractionComponent],
    ): ...


@partial_struct
class cGcNGuiManager(Structure):
    pass


@partial_struct
class cGcVibrationManager(Structure):
    @function_hook(
        "48 89 5C 24 ? 57 48 83 EC ? 48 8B F9 48 83 C1 ? E8 ? ? ? ? 48 8D 14 40 48 8B 47 ? 48 8D 04 D0 48 3B "
        "47 ? 75"
    )
    def SendValue(
        self,
        this: "_Pointer[cGcVibrationManager]",
        lID: _Pointer[basic.TkID0x10],
        lfValue: Annotated[float, c_float],
    ) -> c_bool: ...


@partial_struct
class cGcApplication(cTkFSM):
    @partial_struct
    class Data(Structure):
        _total_size_ = 0x94E850
        # These are found in cGcApplication::Data::Data
        mRealityManager: Annotated[cGcRealityManager, 0x60]
        mGameState: Annotated[cGcGameState, 0xE70]
        mSimulation: Annotated[cGcSimulation, 0x4CCF90]
        mHUDManager: Annotated[cGcHUDManager, 0x7228E0]
        mFrontendManager: Annotated[cGcFrontendManager, 0x849050]
        mVibrationManager: Annotated[cGcVibrationManager, 0x901FA8]
        mNGuiManager: Annotated[cGcNGuiManager, 0x902AD0]

        @function_hook(
            "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 33 ED 48 C7 41 ? ? ? ? "
            "? 48 89 29"
        )
        def Data(self, this: "_Pointer[cGcApplication.Data]"): ...

    @function_hook("40 53 48 83 EC 20 E8 ? ? ? ? 48 89")
    def Update(self, this: "_Pointer[cGcApplication]"): ...

    @function_hook("48 89 5C 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 45 33 F6 83 3D")
    def Construct(self, this: "_Pointer[cGcApplication]"): ...

    # There are tricky to get...
    # The game mostly sets a lot of the fields of the cGcApplication struct in some kind of "baked" way, we
    # don't see the offsets as with other structs, and instead we need to find the object, and then infer the
    # offset from the offset of the cGcApplication object. We can get this by seeing the value passed in to
    # cTkFSM::Construct in cGcApplication::Construct.
    # These properties can be found in cGcApplication::Construct
    mpData: Annotated[_Pointer[Data], 0x38]
    muPlayerSaveSlot: Annotated[int, Field(c_uint32, 0x40)]
    meGameMode: Annotated[int, Field(c_uint32, 0x44)]  # ePresetGameMode
    mbSavingEnabled: Annotated[bool, Field(c_bool, 0x4C)]
    mbPaused: Annotated[bool, Field(c_bool, 0xB4A5)]
    mbMultiplayerActive: Annotated[bool, Field(c_bool, 0xB4A8)]


class cGcBeamEffect(Structure):
    @function_hook("40 53 48 83 EC ? 8B 41 ? 48 8B D9 A9 ? ? ? ? 76 ? 25 ? ? ? ? 3D ? ? ? ? 0F 85")
    def Prepare(self, this: "_Pointer[cGcBeamEffect]"): ...


class cGcLaserBeam(Structure):
    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 48 83 B9 ? ? ? ? ? 0F B6 FA 48 8B D9 77")
    def Fire(self, this: "_Pointer[cGcLaserBeam]", lbHitOnFirstFrame: Annotated[bool, c_bool]): ...


# TODO: Need to add the offset of this struct to the globals.
@partial_struct
class cGcBaseBuildingManager(Structure):
    # Found by subtracting the offset of the field in cGcFrontendPageClaimBase::DoClaimBaseInteraction (which
    # references cGcFrontendPageClaimBase::DoBaseClaimOptions) compared to the offset of
    # cGcBaseBuildingManager::mBaseBuildingManager
    mPlanetPositions: Annotated[tuple[basic.cTkVector3, ...], Field(basic.cTkVector3 * 8, 0x2E0)]
    # Found in cGcBaseBuildingManager::GetBaseRootNode
    mBaseRootNodes: Annotated[basic.TkStd.tk_vector[basic.TkHandle], 0x360]
    mBaseBuildingNode: Annotated[basic.TkHandle, 0x370]

    @function_hook("40 55 56 57 41 56 41 57 48 81 EC ? ? ? ? 49 8B F8")
    def GetBaseRootNode(
        self,
        this: "_Pointer[cGcBaseBuildingManager]",
        result: _Pointer[basic.TkHandle],
        luBaseIndex: c_uint64,  # _WORD *
        lbForceUpdateMatrix: c_bool,
    ) -> c_uint64:  # TkHandle *
        ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ? 48 8B E9 49 63 F1")
    def AddHUDMarker(
        self,
        this: "_Pointer[cGcBaseBuildingManager]",
        leType: c_enum32[enums.cGcMarkerType],
        lWorldMatrix: _Pointer[basic.cTkBigPos],
        liColourIndex: c_int32,
        lpacName: _Pointer[basic.cTkFixedString0x40],
    ): ...

    @function_hook(
        "48 8B C4 F3 0F 11 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 80 79"
    )
    def Update(self, this: "_Pointer[cGcBaseBuildingManager]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("40 53 48 83 EC ? 66 0F 6F 25")
    def GetBaseBuildingRootMatrix(
        self,
        this: "_Pointer[cGcBaseBuildingManager]",
        result: _Pointer[basic.cTkPhysRelVec3],
        luBaseIndex: _Pointer[c_uint16],
        lUA: c_uint64,
    ) -> c_uint64:  # cTkPhysRelMat34 *
        ...

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 78 ? 55 41 54 41 55 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70"
    )
    def AddObjectMarker(
        self,
        this: "_Pointer[cGcBaseBuildingManager]",
        lID: _Pointer[basic.TkID0x10],
        lObjectHandle: c_uint64,  # Current exe shows this as a pointer, 4.13 shows it as sBaseObjectHandle
        # which is an 8 byte struct.
    ): ...


class cGcBaseSearch(Structure):
    @static_function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 4C 89 60 ? 55 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 66 "
        "0F 6F 05"
    )
    @staticmethod
    def FindNearestBaseInCurrentSystem(
        result: c_uint64,  # BaseIndex *
        lWorldPosition: _Pointer[basic.Vector3f],  # cTkVector3 *
        leBaseType: c_int32,  # ePersistentBaseTypes
    ) -> c_uint64:  # BaseIndex *
        ...


@partial_struct
class cGcBuilding(Structure):
    mpPlanet: Annotated[_Pointer[cGcPlanet], 0x70]
    mpData: Annotated[_Pointer[nmse.cGcBuildingSpawnData], 0x78]
    meScanState: Annotated[int, Field(c_int32, 0xB4)]  # cGcBuilding::eScanState (enum has changed since 4.13)

    @function_hook("4C 8B DC 55 49 8D AB ? ? ? ? 48 81 EC ? ? ? ? 48 8B D1")
    def DestroyIntersectingVolcanoes(self, this: "_Pointer[cGcBuilding]"): ...

    @function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 83 B9 ? ? ? ? ? 48 8B F9 0F 8D ? ? ? ? C7 81 ? ? ? ? ? ? "
        "? ? 84 D2 0F 85 ? ? ? ? E8"
    )
    def Visited(self, this: "_Pointer[cGcBuilding]", lbLoad: Annotated[bool, c_bool]): ...


@partial_struct
class cGcScanEvent(Structure):
    class eState(IntEnum):
        Adding = 0x0
        Preparing = 0x1
        Complete = 0x2

    mMarker: Annotated[cGcMarkerPoint, Field(cGcMarkerPoint, 0x10)]
    mpEvent: Annotated[
        _Pointer[nmse.cGcScanEventData],
        Field(_Pointer[nmse.cGcScanEventData], 0x280),
    ]
    mpBuilding: Annotated[_Pointer[cGcBuilding], 0x288]
    meEventState: Annotated[c_enum32[eState], 0x298]

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 55 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? "
        "? ? 33 F6"
    )
    def Construct(
        self,
        this: "_Pointer[cGcScanEvent]",
        leTable: c_int32,  # eScanTable
        lpEvent: _Pointer[nmse.cGcScanEventData],
        lpBuilding: _Pointer[cGcBuilding],
        lfStartTime: Annotated[float, c_float],
        lbMostImportant: Annotated[bool, c_bool],
        lpMission: c_uint64,  # std::pair<TkID<128>,cTkSeed> *
    ): ...

    @function_hook(
        "48 8B C4 55 53 56 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 ? 33 F6 0F 29 78 ? 48 8B F9"
    )
    def CalculateMarkerPosition(self, this: "_Pointer[cGcScanEvent]"): ...

    @function_hook("4C 8B DC 55 57 49 8D AB ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 8B F9 45 0F 29 43")
    def Update(slef, this: "_Pointer[cGcScanEvent]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("48 8B C4 55 53 57 41 54 41 56 41 57")
    def UpdateInteraction(self, this: "_Pointer[cGcScanEvent]"): ...

    @function_hook("4C 8B DC 55 56 49 8D 6B ? 48 81 EC ? ? ? ? 48 8B 81")
    def UpdateSpaceStationLocation(self, this: "_Pointer[cGcScanEvent]"): ...


class cGcApplicationLocalLoadState(Structure):
    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 80 B9 ? ? ? ? ? 48 8B F9 BB")
    def GetRespawnReason(self, this: "_Pointer[cGcApplicationLocalLoadState]") -> c_int64: ...


class cTkDynamicGravityControl(Structure):
    @partial_struct
    class cTkGravityPoint(Structure):
        _total_size_ = 0x20
        mCenter: Annotated[basic.Vector3f, 0x0]
        mfStrength: Annotated[float, Field(c_float, 0x10)]
        mfFalloffRadiusSqr: Annotated[float, Field(c_float, 0x14)]
        mfMaxStrength: Annotated[float, Field(c_float, 0x18)]

    @partial_struct
    class cTkGravityOBB(Structure):
        _total_size_ = 0xA0
        mUp: Annotated[basic.Vector3f, 0x0]
        mfConstantStrength: Annotated[float, Field(c_float, 0x10)]
        mfFalloffStrength: Annotated[float, Field(c_float, 0x14)]
        mTransformInverse: Annotated[basic.cTkMatrix34, 0x20]
        mUntransformedCentre: Annotated[basic.Vector3f, 0x60]
        mOBB: Annotated[basic.cTkAABB, 0x70]
        mfFalloffRadiusSqr: Annotated[float, Field(c_float, 0x90)]

    maGravityPoints: list["cTkDynamicGravityControl.cTkGravityPoint"]
    miNumGravityPoints: int
    maGravityOBBs: bytes

    @function_hook("33 C0 4C 8D 89 ? ? ? ? 89 81")
    def Construct(self, this: "_Pointer[cTkDynamicGravityControl]"): ...

    @function_hook("66 0F 6F 05 ? ? ? ? 4C 8B C9")
    def cTkDynamicGravityControl(self, this: "_Pointer[cTkDynamicGravityControl]"): ...

    @function_hook("48 8B C4 53 55 56 41 54")
    def GetGravity(
        self,
        this: "_Pointer[cTkDynamicGravityControl]",
        result: c_uint64,
        lPos: _Pointer[basic.Vector3f],
    ) -> c_uint64: ...

    @function_hook("40 57 48 83 EC ? 48 63 81")
    def UpdateGravityPoint(
        self,
        this: "_Pointer[cTkDynamicGravityControl]",
        lCentre: _Pointer[basic.Vector3f],
        lfRadius: Annotated[float, c_float],
        lfNewStrength: Annotated[float, c_float],
    ): ...


# TODO: Check this in memory.
cTkDynamicGravityControl._fields_ = [
    ("maGravityPoints", cTkDynamicGravityControl.cTkGravityPoint * 0x10),
    ("_padding0x200", 0x40 * c_ubyte),
    # Guessed name. Seems to be number of gravity points for planets as we see in
    # cTkDynamicGravityControl::UpdateGravityPoint that
    ("miNumPlanetGravityPoints", c_int32),  # 0x240
    ("_padding0x244", 0x3C * c_ubyte),
    ("miNumGravityPoints", c_int32),  # 0x280
    # TODO: Figure out where this is in memory.
    ("maGravityOBBs", basic.cTkClassPool[cTkDynamicGravityControl.cTkGravityOBB, 0x40]),
]


@partial_struct
class cTkTextureBase(Structure):
    meType: Annotated[int, Field(c_uint8, 0x0)]  # eTkTextureType - 8bit enum
    # This has a somewhat complex mapping to the dds header format.
    # It will be partially described here:
    # 42 -> DXGI_FORMAT_BC7_UNORM (98)
    # 43 -> DXT1
    meFormat: Annotated[int, Field(c_ubyte, 0x1)]
    miWidth: Annotated[int, Field(c_int32, 0x10)]
    miHeight: Annotated[int, Field(c_int32, 0x14)]
    miDepth: Annotated[int, Field(c_int32, 0x14)]
    miNumMips: Annotated[int, Field(c_uint16, 0x1C)]
    miAnisotropy: Annotated[int, Field(c_uint16, 0x1E)]
    miDataSize: Annotated[int, Field(c_int32, 0x20)]
    miMemorySize: Annotated[int, Field(c_int32, 0x24)]

    @static_function_hook("0F B6 C1 45 8B D0")
    @staticmethod
    def CalculateTextureSize(
        leFormat: Annotated[int, c_uint8],
        liWidth: Annotated[int, c_int32],
        liHeight: Annotated[int, c_int32],
        liDepth: Annotated[int, c_int32],
    ) -> c_uint64: ...


@partial_struct
class cTkTexture(cTkTextureBase):
    miUltraMips: Annotated[int, Field(c_uint16, 0x20)]

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B FA 48 8B F1 33 D2 48 8D 0D")
    def CopyPixelDataToBuffer(
        self,
        this: "_Pointer[cTkTexture]",
        lpBuffer: c_void_p,
        lbCompressed: Annotated[bool, c_bool],
        liMipLevel: Annotated[int, c_uint32],
        liCubeFace: Annotated[int, c_uint32],
    ): ...

    @function_hook("48 8B C4 44 89 48 ? 44 89 40 ? 88 50 ? 48 89 48")
    def CreateEmptyTexture(
        self,
        this: "_Pointer[cTkTexture]",
        leType: Annotated[int, c_uint8],  # eTkTextureType
        liWidth: Annotated[int, c_uint32],
        liHeight: Annotated[int, c_uint32],
        liDepth: Annotated[int, c_uint32],
        liFormat: Annotated[int, c_char],
        liNumMipLevels: Annotated[int, c_uint32],
        leTextureAddressMode: c_enum32[nmse.cTkMaterialSampler.eTextureAddressModeEnum],
        leTextureFilterMode: c_enum32[nmse.cTkMaterialSampler.eTextureFilterModeEnum],
        liAnisotropy: Annotated[int, c_uint32],
        lbIsSrgb: Annotated[bool, c_bool],
        lbCommit: Annotated[bool, c_bool],
        lbIsPartiallyResident: Annotated[bool, c_bool],
        lbEvictAllEvictable: Annotated[bool, c_bool],
        lbAllowUnorderedAccess: Annotated[bool, c_bool],
    ): ...


class Engine:
    @static_function_hook("40 53 44 8B D1")
    @staticmethod
    def ShiftAllTransformsForNode(node: basic.TkHandle, lShift: _Pointer[basic.Vector3f]): ...

    @static_function_hook("40 56 48 83 EC ? 44 8B C9 49 8B F0 41 C1 E9 ? 45 85 C9 0F 84")
    @staticmethod
    def GetNodePositions(
        node: c_uint32,
        localPos: _Pointer[basic.Vector3f],
        absolutePos: _Pointer[basic.Vector3f],
    ): ...

    @static_function_hook(
        "44 8B C9 4C 8B D2 41 C1 E9 ? 45 85 C9 74 ? 44 8B C1 "
        "41 81 E0 ? ? ? ? 41 81 F8 ? ? ? ? 74 ? 48 8B 15 ? ? ? ? "
        "81 E1 ? ? ? ? 48 8B 82 ? ? ? ? 48 63 0C 88 48 8B 82 ? ? ? ? "
        "48 8B 0C C8 48 85 C9 74 ? 8B 51 ? 8B C2 25 ? ? ? ? 41 3B C0 "
        "75 ? C1 EA ? 41 3B D1 75 ? 49 8B D2 E9"
    )
    @staticmethod
    def GetNodeAbsoluteTransMatrix(
        node: basic.TkHandle,
        absMat: _Pointer[basic.cTkMatrix34],
    ): ...

    @static_function_hook("4C 89 4C 24 ? 48 89 4C 24 ? 56 41 56")
    @staticmethod
    def SetUniformArrayDefaultMultipleShaders(
        laShaderRes: c_uint64,
        liNumShaders: c_int32,
        name: c_char_p64,
        lpafData: c_uint64,  # float *
        liNumVectors: c_int32,
    ) -> c_int64: ...

    @static_function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 4D 63 F1 49 8B F8"
    )
    @staticmethod
    def SetMaterialUniformArray(
        materialRes: c_uint64,  # TkStrongType<int,TkStrongTypeIDs::TkResHandleID>
        name: c_char_p64,
        lpafData: c_uint64,  # float *
        liNumVectors: c_int32,
    ): ...

    @static_function_hook("48 83 EC ? FF CA 83 FA ? 0F 87")
    @staticmethod
    def SetOption(leParam: c_int32, lfValue: Annotated[float, c_float]) -> c_char: ...

    @static_function_hook(
        "4C 8B DC 49 89 5B ? 49 89 6B ? 49 89 73 ? 57 41 56 41 57 48 81 EC ? ? ? ? 48 8B BC 24"
    )
    @staticmethod
    def AddResource(
        result: _Pointer[cTkSmartResHandle],
        liType: c_int32,
        lpcName: c_char_p64,
        liFlags: c_uint32,
        lAlternateMaterialId: _Pointer[cTkResourceDescriptor],
        unknown: c_uint64,
    ) -> c_uint64:  # cTkSmartResHandle *
        ...

    @static_function_hook(
        "48 89 5C 24 ? 57 48 81 EC ? ? ? ? 44 8B D2 48 8B D9 41 C1 EA ? 45 85 D2 0F 84 ? ? ? ? 44 8B CA 41 "
        "81 E1 ? ? ? ? 41 81 F9 ? ? ? ? 0F 84 ? ? ? ? 8B CA 48 8B 15 ? ? ? ? 81 E1 ? ? ? ? 48 8B 82 ? ? ? ? "
        "48 63 0C 88 48 8B 82 ? ? ? ? 48 8B 3C C8 48 85 FF 74 ? 8B 4F ? 8B C1 25 ? ? ? ? 41 3B C1 75 ? C1 E9 "
        "? 41 3B CA 75 ? 4C 8B CF 48 8D 4C 24 ? BA ? ? ? ? E8 ? ? ? ? 48 8B 0D ? ? ? ? 48 8D 05 ? ? ? ? 4C "
        "8D 4C 24 ? 48 89 44 24 ? 41 B8 ? ? ? ? 48 89 7C 24 ? 48 8B D3 E8 ? ? ? ? 48 8D 4C 24 ? E8 ? ? ? ? "
        "EB ? C7 03 ? ? ? ? 48 8B C3 48 8B 9C 24 ? ? ? ? 48 81 C4 ? ? ? ? 5F C3 CC CC CC CC CC 48 89 5C 24 ? "
        "57"
    )
    @staticmethod
    def AddGroupNode(
        result: _Pointer[basic.TkHandle], parent: basic.TkHandle, name: c_char_p64
    ) -> c_uint64: ...

    @static_function_hook("40 55 48 8D 6C 24 ? 48 81 EC ? ? ? ? 80 3D ? ? ? ? ? 74")
    def Initialise() -> c_char: ...

    @static_function_hook("44 8B CA 4C 8B D9")
    @staticmethod
    def GetModelNode(
        result: _Pointer[basic.TkHandle],
        node: basic.TkHandle,
    ) -> c_uint64:  # TkHandle *
        ...

    @static_function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 44 8B CA 49 63 D8 41 C1 E9 ? 48 8B F1 45 85 "
        "C9 0F 84 ? ? ? ? 44 8B C2 41 81 E0 ? ? ? ? 41 81 F8 ? ? ? ? 0F 84 ? ? ? ? 8B CA 48 8B 15 ? ? ? ? 81 "
        "E1 ? ? ? ? 48 8B 82 ? ? ? ? 48 63 0C 88 48 8B 82 ? ? ? ? 48 8B 2C C8 48 85 ED 0F 84 ? ? ? ? 8B 4D ? "
        "8B C1 25 ? ? ? ? 41 3B C0 75"
    )
    @staticmethod
    def AddNodes(
        result: _Pointer[basic.TkHandle],
        parent: basic.TkHandle,
        sceneGraphRes: Annotated[int, c_int32],  # TkStrongType<int,TkStrongTypeIDs::TkResHandleID>
    ) -> c_uint64:  # TkHandle *
        ...

    @static_function_hook("44 8B D2 4C 8B C1")
    @staticmethod
    def GetResourceHandleForNode(
        result: _Pointer[c_int32],  # TkStrongType<int,TkStrongTypeIDs::TkResHandleID> *
        lNode: basic.TkHandle,
    ) -> c_uint64:  # TkStrongType<int,TkStrongTypeIDs::TkResHandleID> *
        ...

    @static_function_hook("40 53 48 83 EC ? 4C 8B 0D ? ? ? ? 33 DB")
    @staticmethod
    def GetTexture(
        targetRes: Annotated[int, c_int32],  # TkStrongType<int,TkStrongTypeIDs::TkResHandleID>
    ) -> c_uint64:  # typed as "char *", but is actually cTkTexture *
        ...

    @static_function_hook(
        "44 8B C1 41 C1 E8 ? 45 85 C0 74 ? 44 8B C9 41 81 E1 ? ? ? ? 41 81 F9 ? ? ? ? 74 ? 4C 8B 15 ? ? ? ? "
        "81 E1 ? ? ? ? 4D 8B 9A ? ? ? ? 49 8B 82 ? ? ? ? 49 63 14 8B 48 8B 0C D0 48 85 C9 74 ? 8B 49 ? 8B C1 "
        "25 ? ? ? ? 8B D1 41 3B C1 75 ? C1 E9 ? 41 3B C8 75 ? 49 8B 82"
    )
    @staticmethod
    def GetNodeType(node: basic.TkHandle) -> c_int64: ...

    @static_function_hook(
        "44 8B C1 41 C1 E8 ? 45 85 C0 74 ? 44 8B C9 41 81 E1 ? ? ? ? 41 81 F9 ? ? ? ? 74 ? 4C 8B 15 ? ? ? ? "
        "81 E1 ? ? ? ? 4D 8B 9A ? ? ? ? 49 8B 82 ? ? ? ? 49 63 14 8B 48 8B 0C D0 48 85 C9 74 ? 8B 49 ? 8B C1 "
        "25 ? ? ? ? 8B D1 41 3B C1 75 ? C1 E9 ? 41 3B C8 75 ? 81 E2"
    )
    @staticmethod
    def GetNodeNumChildren(node: basic.TkHandle) -> c_int32: ...

    @static_function_hook(
        "44 8B C1 41 C1 E8 ? 45 85 C0 74 ? 44 8B C9 41 81 E1 ? ? ? ? 41 81 F9 ? ? ? ? 74 ? 48 8B 15 ? ? ? ? "
        "81 E1 ? ? ? ? 48 8B 82 ? ? ? ? 48 63 0C 88 48 8B 82 ? ? ? ? 48 8B 14 C8 48 85 D2 74 ? 8B 4A ? 8B C1 "
        "25 ? ? ? ? 41 3B C1 75 ? C1 E9 ? 41 3B C8 75 ? 48 8B 42 ? 48 85 C0"
    )
    @staticmethod
    def GetNodeName(node: basic.TkHandle) -> c_char_p64: ...

    @static_function_hook(
        "40 53 48 83 EC ? 8B DA 85 C9 74 ? 4C 8B 0D ? ? ? ? 8D 41 ? 41 3B 41 ? 73 ? 49 8B 41 ? 4C 63 C1 4A "
        "8B 44 C0 ? 48 85 C0 74 ? 80 B8 ? ? ? ? ? 74 ? 4C 8B 80 ? ? ? ? 49 8B C9 8B 50 ? E8 ? ? ? ? EB ? 33 "
        "C0 48 85 C0 74 ? 83 78 ? ? 75 ? 8B 90"
    )
    @staticmethod
    def GetRenderBufferTexture(
        targetRes: Annotated[int, c_int32],
        liIndex: c_uint32,
    ) -> c_uint64:  # cTkTexture *
        ...

    @static_function_hook("48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 44 8B D2")
    @staticmethod
    def GetNodeParent(result: _Pointer[basic.TkHandle], node: basic.TkHandle) -> c_uint64:  # TkHandle *
        ...

    @static_function_hook("48 89 5C 24 ? 55 56 57 48 83 EC ? 4C 8B 0D")
    @staticmethod
    def SetMaterialSampler(
        materialRes: Annotated[int, c_int32], name: c_char_p64, texRes: Annotated[int, c_int32]
    ) -> c_bool: ...


class cEgResource(cTkResource):
    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 56 48 83 EC ? 48 8B 01 41 8B F0")
    def Load(
        self,
        this: "_Pointer[cEgResource]",
        lpacData: c_char_p64,
        liSize: Annotated[int, c_int32],
    ) -> c_char: ...


@partial_struct
class cEgTextureResource(cEgResource):
    meTextureType: Annotated[int, Field(c_ubyte, 0x1E4)]  # eTkTextureType - 8bit enum
    meTextureFormat: Annotated[int, Field(c_ubyte, 0x1E5)]  # Technically an array of 2 bytes...
    mbIsSRGB: Annotated[bool, Field(c_bool, 0x1F8)]
    mbHasMipMaps: Annotated[bool, Field(c_bool, 0x1F9)]
    mTexture: Annotated[cTkTexture, 0x200]

    @function_hook("40 53 57 41 56 48 81 EC ? ? ? ? 45 8B F0")
    def Load(
        self,
        this: "_Pointer[cEgTextureResource]",
        lpcData: c_char_p64,
        liSize: Annotated[int, c_int32],
    ) -> c_char: ...

    @function_hook("44 89 4C 24 ? 48 89 54 24 ? 55 53 56 41 54 41 55")
    def LoadFromDds(
        self,
        this: "_Pointer[cEgTextureResource]",
        lpcHeader: c_uint64,  # Pointer to the 0x80 byte dds header.
        lpPixelData: c_uint64,  # Pointer to the rest of the dds data.
        liStartMip: Annotated[int, c_int32],
        liSkippedSize: Annotated[int, c_int32],
        liPixelDataSize: Annotated[int, c_uint32],
        lpPackedAverageColor: _Pointer[c_uint32],
        liSelectMip: Annotated[int, c_int32],
        liSelectMipCount: Annotated[int, c_int32],
    ) -> c_bool: ...


class cEgCodeResource(cEgResource):
    @function_hook(
        "48 89 5C 24 ? 48 89 4C 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? "
        "49 63 F8"
    )
    def Load(
        self,
        this: "_Pointer[cEgCodeResource]",
        lpcData: c_char_p64,
        liSize: Annotated[int, c_int32],
    ) -> c_bool: ...


class cTkAsyncIOManager:
    @static_function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B 3D ? ? ? ? 0F B6 F2")
    @staticmethod
    def GetOpDataSize(
        lOpHandle: Annotated[int, c_int32], lbTakeLock: Annotated[bool, c_bool]
    ) -> c_uint64: ...

    @static_function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B 3D ? ? ? ? 0F B6 EA")
    @staticmethod
    def GetOpData(lOpHandle: Annotated[int, c_int32], lbTakeLock: Annotated[bool, c_bool]) -> c_void_p: ...


class GeometryStreaming:
    @partial_struct
    class cEgGeometryStreamer(Structure):
        _mpGeometry: Annotated[int, Field(c_uint64, 0x10)]  # cEgGeometryResource*
        miNumMeshes: Annotated[int, Field(c_int32, 0x18)]
        maMeshNames: Annotated[basic.TkStd.tk_vector[basic.cTkFixedString0x80], 0x28]
        maMeshNameHashes: Annotated[basic.TkStd.tk_vector[c_uint64], 0x40]
        mabIsMeshProcedural: Annotated[basic.TkStd.tk_vector[c_bool], 0xA0]

        @property
        def mpGeometry(self):
            if self._mpGeometry:
                return cEgGeometryResource.from_address(self._mpGeometry)

        @partial_struct
        class cBufferData(Structure):
            _total_size_ = 0x28

            mu64NameHash: Annotated[int, Field(c_uint64, 0x0)]
            # For the following 2 tuples, the element 0 is for non-double buffered meshes, and element 1 is
            # for double buffered meshes.
            mauVertexBufferHandle: Annotated[tuple[int, int], Field(c_uint32 * 2, 0x8)]
            mauIndexBufferHandle: Annotated[tuple[int, int], Field(c_uint32 * 2, 0x10)]
            meState: Annotated[int, Field(c_uint8, 0x24)]
            mb16bitIndices: Annotated[bool, Field(c_bool, 0x25)]

        @function_hook("48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 83 79 ? ? 41 0F B6 E8")
        def GetVertexBufferByIndex(
            self,
            this: "_Pointer[GeometryStreaming.cEgGeometryStreamer]",
            liIndex: Annotated[int, c_int32],
            a3: Annotated[bool, c_bool],
        ) -> c_int64: ...

        @function_hook("48 83 EC ? 8B 41 ? 4C 8B DA 48 85 C0")
        def FindVertexBufferIndexByHash(
            self,
            this: "_Pointer[GeometryStreaming.cEgGeometryStreamer]",
            liHash: Annotated[int, c_int64],
        ) -> c_int64: ...

        @function_hook("40 55 53 56 57 41 54 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 4C 8B FA")
        def RequestStream(
            self,
            this: "_Pointer[GeometryStreaming.cEgGeometryStreamer]",
            lpDescriptor: _Pointer[cTkResourceDescriptor],
        ): ...

        @static_function_hook("4C 8B DC 49 89 4B ? 55 57 41 57 48 81 EC ? ? ? ? 48 8B 29")
        @staticmethod
        def OnBufferLoadFinish(lpData: c_void_p): ...

        # Found in GeometryStreaming::cEgGeometryStreamer::Prepare
        mauIndexBufferOffsets: Annotated[basic.TkStd.tk_vector[c_int32], 0x100]
        mauVertexBufferOffsets: Annotated[basic.TkStd.tk_vector[c_int32], 0x110]
        mauIndexBufferSizes: Annotated[basic.TkStd.tk_vector[c_int32], 0x120]
        mauVertexBufferSizes: Annotated[basic.TkStd.tk_vector[c_int32], 0x130]
        mauVertexPositionBufferOffsets: Annotated[basic.TkStd.tk_vector[c_int32], 0x140]
        mauVertexPositionBufferSizes: Annotated[basic.TkStd.tk_vector[c_int32], 0x150]
        mBufferLookup: Annotated[basic.TkStd.tk_vector[cBufferData], 0x160]

    class cEgStreamRequests(Structure):
        @function_hook("40 56 48 83 EC ? 83 79 ? ? 48 8B F1 0F 29 74 24")
        def ProcessOnlyStreamRequests(
            self,
            this: "_Pointer[GeometryStreaming.cEgStreamRequests]",
            lfTimeout: Annotated[float, c_double],
        ): ...


@partial_struct
class cTkBuffer(Structure):
    _total_size_ = 0x30
    muSize: Annotated[int, Field(c_uint32, 0x0)]
    mpD3D12Resource: Annotated[_Pointer[vulkan.VkBuffer_T], 0x8]
    # 00000010     TkDeviceMemory mpDeviceMemory;
    mpBufferData: Annotated[c_void_p, 0x28]


class cTkGraphicsAPI(Structure):
    @static_function_hook("48 89 5C 24 ? 57 48 83 EC ? 48 8B FA 48 8B D9 4D 85 C0")
    @staticmethod
    def GetVertexBufferData(
        lpVertexBuffer: _Pointer[cTkBuffer],
        lpVertexData: c_void_p,
        lpiVertexBufferSize: _Pointer[c_uint32],
    ): ...

    # The following 2 functions can be found above the string "ImposterGenIndirectionData"

    @static_function_hook("48 8B C4 4C 89 48 ? 4C 89 40 ? 48 89 50 ? 48 89 48 ? 55 53 48 8D 68")
    @staticmethod
    def createVertexBuffer(
        lpVertexBuffer: c_uint64,  # _Pointer[_Pointer[VkBuffer_T]],
    ):
        """TODO: Finish mapping out the arguments to this function..."""
        ...

    @static_function_hook("48 89 5C 24 ? 55 56 41 54 41 56 41 57 48 83 EC ? 33 DB")
    @staticmethod
    def CreateIndexBuffer(
        lpIndexBuffer: c_uint64,  # _Pointer[_Pointer[VkBuffer_T]],
        lMemory: c_uint64,  # TkDeviceMemory *
        lpInitialData: c_void_p,
        liSizeBytes: Annotated[int, c_int32],
        lbMappable: Annotated[bool, c_bool],
        lbPersistent: Annotated[bool, c_bool],
    ) -> c_uint64: ...


@partial_struct
class cTkVertexLayoutRT(Structure):
    _total_size_ = 0xA0
    miElementCount: Annotated[int, Field(c_int32, 0x0)]
    miStride: Annotated[int, Field(c_int32, 0x4)]
    miHash: Annotated[int, Field(c_int64, 0x8)]
    maElementsBuffer: Annotated[tuple[nmse.cTkVertexElement, ...], Field(nmse.cTkVertexElement * 0xC, 0x10)]


@partial_struct
class cEgJoint(Structure):
    mInverseBindMatrix: Annotated[basic.cTkMatrix34, 0x0]


@partial_struct
class AnimTransform(Structure):
    _total_size_ = 0x40
    mNodeScale: Annotated[basic.cTkVector3, 0x0]
    mNodeRotationQuat: Annotated[basic.Vector4f, 0x10]  # Actually a quaternion but this is the same.
    mNodeTranslation: Annotated[basic.cTkVector3, 0x20]


@partial_struct
class cEgGeometryResource(cEgResource):
    _total_size_ = 0x770

    # Lots of this found in cEgGeometryResource::CloneOriginalVertDataToIndex and other methods
    muIndexCount: Annotated[int, Field(c_uint32, 0x200)]
    muVertexCount: Annotated[int, Field(c_uint32, 0x204)]
    muBvVertexCount: Annotated[int, Field(c_uint32, 0x208)]
    mb16BitIndices: Annotated[bool, Field(c_bool, 0x20C)]
    mbUnknown0x20D: Annotated[bool, Field(c_bool, 0x20D)]  # Looks related to cTkGeometryData.ProcGenNodeNames
    # Looks like if the above is False (the default), then maybe cTkGeometryData.ProcGenNodeNames is written
    # to this + 0x350?
    mpIndexData: Annotated[c_void_p, 0x210]
    mpaVertPositionData: Annotated[basic.TkStd.tk_vector[_Pointer[basic.cTkVector3]], 0x228]
    mpaVertStreams: Annotated[
        basic.TkStd.tk_vector[c_void_p], 0x2A0
    ]  # This is actually in a cTkStackVector maybe....
    mMeshVertRStart: Annotated[basic.TkStd.tk_vector[c_int32], 0x2F8]  # maybe?
    mJoints: Annotated[basic.TkStd.tk_vector[cEgJoint], 0x350]
    mBindPose: Annotated[basic.TkStd.tk_vector[AnimTransform], 0x360]
    mSkinMatOrder: Annotated[basic.TkStd.tk_vector[c_int32], 0x410]
    mMeshBaseSkinMat: Annotated[basic.TkStd.tk_vector[c_int32], 0x420]
    mVertexLayout: Annotated[cTkVertexLayoutRT, 0x488]
    mPositionVertexLayout: Annotated[cTkVertexLayoutRT, 0x528]
    mStreamManager: Annotated[GeometryStreaming.cEgGeometryStreamer, 0x5D8]

    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 68 ? 48 89 70 ? 48 89 78 ? 41 54 41 56 41 57 48 81 EC ? ? ? ? 49 8B E9"
    )
    def cEgGeometryResource(
        self,
        this: "_Pointer[cEgGeometryResource]",
        lsName: _Pointer[basic.cTkFixedString0x100],
        liFlags: Annotated[int, c_int32],
        lpResourceDescriptor: _Pointer[cTkResourceDescriptor],
    ): ...

    @function_hook(
        "40 53 56 48 83 EC ? 65 48 8B 04 25 ? ? ? ? 48 8B DA 48 89 6C 24 ? 48 8B F1 4C 89 64 24 ? 4C 89 74 "
        "24 ? 45 8B F0 48 8B 28 4C 89 7C 24 ? 41 BF ? ? ? ? 41 80 3C 2F ? 75 ? E8 ? ? ? ? 83 3D ? ? ? ? ? 41 "
        "BC ? ? ? ? 48 89 7C 24 ? 41 8B 04 2C 89 44 24 ? 7E ? 48 8B 05 ? ? ? ? 48 63 48 ? 48 8B 05 ? ? ? ? "
        "48 8D 3C CD ? ? ? ? 48 83 3C 07 ? 74 ? 41 80 3C 2F ? 75 ? E8 ? ? ? ? 48 8B 05 ? ? ? ? 41 C7 04 2C ? "
        "? ? ? 48 8B 04 07 48 89 05 ? ? ? ? EB ? 48 C7 05 ? ? ? ? ? ? ? ? 45 8B C6 48 8B D3 48 8B CE E8 ? ? "
        "? ? 4C 8B 7C 24 ? 4C 8B 74 24 ? 4C 8B 64 24 ? 48 8B 7C 24 ? 48 8B 6C 24 ? 84 C0 74 ? 48 B8 ? ? ? ? "
        "? ? ? ? 48 39 03 75 ? B8 ? ? ? ? 66 39 43 ? 75 ? 48 8D 56 ? 45 33 C0 48 8D 4B ? E8 ? ? ? ? 48 8D 53"
    )
    def Load(
        self,
        this: "_Pointer[cEgGeometryResource]",
        lpcData: c_char_p64,
        liSize: Annotated[int, c_int32],
    ) -> c_char: ...

    @function_hook("48 89 54 24 ? 55 57 41 57 48 8D AC 24 ? ? ? ? 48 81 EC")
    def CreateVertexInfoForHash(
        self,
        this: "_Pointer[cEgGeometryResource]",
        luHash: _Pointer[basic.cTkVector3],  # Not *technically* the type, I think because the hash is long.
    ): ...

    @function_hook("40 57 48 83 EC ? 83 B9 ? ? ? ? ? 48 8B F9 0F 8F")
    def CloneOriginalVertDataToIndex(
        self,
        this: "_Pointer[cEgGeometryResource]",
        liIndex: Annotated[int, c_int32],
    ): ...

    @function_hook("48 89 5C 24 ? 55 56 57 41 54 41 56 48 81 EC ? ? ? ? 48 8B DA")
    def CloneInternal(self, this: "_Pointer[cEgGeometryResource]", lpRhsRes: _Pointer[cTkResource]): ...

    @function_hook("40 55 56 57 41 56 48 8D 6C 24 ? 48 81 EC ? ? ? ? 44 8B 82")
    def ParseData(
        self,
        this: "_Pointer[cEgGeometryResource]",
        lData: _Pointer[nmse.cTkGeometryData],
    ) -> c_bool: ...


@partial_struct
class cTkResourceManager(Structure):
    _total_size_ = 0x210
    mResources: Annotated[basic.TkStd.tk_vector[_Pointer[cTkResource]], 0x58]

    @function_hook("44 89 44 24 ? 55 53 57 41 54")
    def AddResource(
        self,
        this: "_Pointer[cTkResourceManager]",
        result: _Pointer[cTkSmartResHandle],
        liType: c_enum32[enums.ResourceTypes],
        lsName: c_char_p64,
        lxFlags: c_uint32,
        lbUserCall: Annotated[bool, c_bool],
        lpResourceDescriptor: _Pointer[cTkResourceDescriptor],
        unknown: c_uint64,
    ) -> c_uint64:  # cTkSmartResHandle *
        ...

    @function_hook("4C 89 4C 24 ? 89 54 24 ? 53 55 48 81 EC")
    def FindResourceA(
        self,
        this: "_Pointer[cTkResourceManager]",
        liType: c_enum32[enums.ResourceTypes],
        lsName: c_char_p64,
        lpResourceDescriptor: _Pointer[cTkResourceDescriptor],
        a5: c_uint32,
        lbIgnoreDefaultFallback: Annotated[bool, c_bool],
        lbIgnoreKilled: Annotated[bool, c_bool],
        a8: Annotated[bool, c_bool],
    ) -> c_uint64:  # cTkSmartResHandle *
        ...

    @function_hook("4C 89 44 24 ? 89 54 24 ? 53 55 56 57")
    def GetDefaultResource(
        self,
        this: "_Pointer[cTkResourceManager]",
        liType: Annotated[int, c_int32],
        liFlags: Annotated[int, c_int32],
    ) -> _Pointer[cTkResource]: ...


class cGcRewardManager(Structure):
    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 48 8B 3D ? ? ? ? 48 8B F1"
    )
    def GiveGenericReward(
        self,
        this: "_Pointer[cGcRewardManager]",
        lRewardID: _Pointer[basic.cTkFixedString[0x10]],
        lMissionID: _Pointer[basic.cTkFixedString[0x10]],
        lSeed: _Pointer[basic.cTkSeed],
        lbPeek: Annotated[bool, c_bool],
        lbForceShowMessage: Annotated[bool, c_bool],
        liOutMultiProductCount: c_uint64,
        lbForceSilent: Annotated[bool, c_bool],
        lInventoryChoiceOverride: c_int32,
        lbUseMiningModifier: Annotated[bool, c_bool],
    ) -> c_uint64: ...


@partial_struct
class cGcAlienPuzzleEntry(Structure):
    Id: Annotated[str, Field(basic.cTkFixedString[0x20], 0x0)]
    Options: Annotated[
        list[cGcAlienPuzzleOption],
        Field(basic.cTkDynamicArray[cGcAlienPuzzleOption], 0xD0),
    ]


@partial_struct
class cGcDestructableComponent(Structure):
    # Found at bottom of cGcDestructableComponent::Destroy
    mbDestroyed: Annotated[bool, Field(c_bool, 0x154)]
    mpBuilding: Annotated[_Pointer[cGcBuilding], 0x1B8]

    @function_hook("4C 89 44 24 ? 48 89 4C 24 ? 55 53 57 41 55")
    def Destroy(
        self,
        this: "_Pointer[cGcDestructableComponent]",
        leDestroyedBy: c_uint32,  # eDestroyedBy
        lDestroyedByPlayerId: c_uint64,  # const cTkUserIdBase<cTkFixedString<64,char> > *
    ): ...


@partial_struct
class cTkInputPort(Structure):
    mButtons: Annotated[
        basic.cTkBitArray[c_uint64, 512],
        Field(basic.cTkBitArray[c_uint64, 512], 0x108),
    ]
    mButtonsPrev: Annotated[
        basic.cTkBitArray[c_uint64, 512],
        Field(basic.cTkBitArray[c_uint64, 512], 0x148),
    ]

    @function_hook("40 57 48 83 EC ? 48 83 79 ? ? 44 8B CA")
    def SetButton(
        self,
        this: "_Pointer[cTkInputPort]",
        leIndex: c_int32,
    ): ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 41 8B D8 8B FA 48 8B F1 45 84 C9")
    def GetButton(
        self,
        this: "_Pointer[cTkInputPort]",
        leIndex: c_int32,
        leValidation: c_int32,
        lbDebugOnly: Annotated[bool, c_bool],
    ) -> c_uint8: ...


@partial_struct
class cGcBinoculars(Structure):
    # This and mpBinocularInfoGui found in cGcBinoculars::UpdateScanBarProgress
    mfScanProgress: Annotated[float, Field(c_float, 0x24)]
    # Found in cGcBinoculars::SetMarker at the top
    mMarkerModel: Annotated[basic.TkHandle, 0x7B0]
    mpBinocularInfoGui: Annotated[_Pointer[cGcNGui], 0x800]

    @function_hook("48 8B C4 55 41 56 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 80 3D ? ? ? ? ? 4C 8B F1 0F 84")
    def SetMarker(self, this: "_Pointer[cGcBinoculars]"): ...

    @function_hook("40 53 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 8D 54 24")
    def GetRange(self, this: "_Pointer[cGcBinoculars]") -> c_float: ...

    @function_hook("48 8B C4 55 57 41 54 41 56 48 8D A8")
    def UpdateTarget(self, this: "_Pointer[cGcBinoculars]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook("40 53 48 83 EC ? 48 8B 91 ? ? ? ? 48 8B D9 F3 0F 11 49")
    def UpdateScanBarProgress(
        self, this: "_Pointer[cGcBinoculars]", lfScanProgress: Annotated[float, c_float]
    ):
        """Called each frame while scanning to set the cGcBinoculars.mfScanProgress from the lfScanProgress
        argument of this function."""
        ...

    @function_hook(
        "48 8B C4 55 53 56 57 41 56 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 ? 4C 8B F1 48 8B 0D"
    )
    def UpdateRayCasts(
        self,
        this: "_Pointer[cGcBinoculars]",
        lTargetInfo: c_uint64,  # cTkContactPoint *
    ): ...

    @function_hook("48 8B C4 4C 89 48 ? 44 89 40 ? 48 89 48")
    def PopulateDiscoveryInfo(
        self,
        this: "_Pointer[cGcBinoculars]",
        lDiscoveryInfo: c_uint64,  # DiscoveryResolver::DiscoveryInfo *
        lpTargetNode: basic.TkHandle,
        lpTargetAttachment: c_uint64,  # cTkAttachmentPtr
        lbSubmitDiscovery: Annotated[bool, c_bool],
        lbSilent: Annotated[bool, c_bool],
    ): ...


class cTkFSMState(Structure):
    @function_hook(signature="4C 8B 51 ? 4D 8B D8")
    def StateChange(
        self,
        this: "_Pointer[cTkFSMState]",
        lNewStateID: _Pointer[basic.cTkFixedString[0x10]],
        lpUserData: c_void_p,
        lbForceRestart: Annotated[bool, c_bool],
    ): ...


class cGcPositionMarker(Structure):
    @function_hook("48 8B C4 55 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 83 39")
    def Render(self, this: "_Pointer[cGcPositionMarker]", a2: c_uint64, a3: c_bool):
        """a2 and a3 seem unused."""
        ...


class cGcPlayerNotifications(Structure):
    @function_hook("48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 55 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 44 8B 81")
    def AddTimedMessage(
        self,
        this: "_Pointer[cGcPlayerNotifications]",
        lsMessage: _Pointer[basic.cTkFixedString[512]],
        lfDisplayTime: Annotated[float, c_float],
        lColour: _Pointer[basic.Colour],
        liAudioID: c_uint32,
        lIcon: _Pointer[cTkSmartResHandle],
        # Note: The following fields have changed since 4.13... Might need to confirm...
        unknown: c_uint64,
        unknown2: c_uint32,
        lbShowMessageBackground: Annotated[bool, c_bool],
        lbShowIconGlow: Annotated[bool, c_bool],
    ): ...


class sTerrainEditData(Structure):
    mVoxelType: int
    mShape: int
    mCustom1: int
    mCustom2: int

    _fields_ = [
        ("mVoxelType", c_uint8, 3),
        ("mShape", c_uint8, 1),
        ("mCustom1", c_uint8, 3),
        ("mCustom2", c_uint8, 1),
    ]


class cTkRigidBody(Structure):
    @function_hook(
        "48 89 5C 24 ? 57 48 83 EC ? 41 0F B6 F8 48 8B D9 4C 8B 81 ? ? ? ? 49 83 B8 ? ? ? ? ? 75 ? 48 8B 81 "
        "? ? ? ? 48 85 C0 0F 84 ? ? ? ? 80 08"
    )
    def SetLinearVelocity(
        self,
        this: "_Pointer[cTkRigidBody]",
        lVelocity: _Pointer[basic.cTkVector3],
        a3: Annotated[bool, c_bool],
    ): ...

    @function_hook(
        "48 89 5C 24 ? 57 48 83 EC ? 41 0F B6 F8 48 8B D9 4C 8B 81 ? ? ? ? 49 83 B8 ? ? ? ? ? 75 ? 48 8B 81 "
        "? ? ? ? 48 85 C0 0F 84 ? ? ? ? 0F 28 02"
    )
    def SetAngularVelocity(
        self,
        this: "_Pointer[cTkRigidBody]",
        lAngularVelocity: _Pointer[basic.cTkVector3],
        a3: Annotated[bool, c_bool],
    ): ...


@partial_struct
class cTkPhysicsComponent(Structure):
    # Found in cGcSpaceshipComponent::Update near
    mRigidBody: Annotated[cTkRigidBody, 0x50]


class cGcTerrainEditorBeam(Structure):
    @function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 55 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? "
        "? ? 48 8B F2"
    )
    def Fire(
        self,
        this: "_Pointer[cGcTerrainEditorBeam]",
        lvTargetPos: _Pointer[basic.cTkPhysRelVec3],
        lpTargetBody: _Pointer[cTkRigidBody],
        lpOwnerConcept: c_uint64,  # cGcOwnerConcept *
        leStatType: c_enum32[enums.cGcStatsTypes],
        lbVehicle: Annotated[bool, c_bool],
    ) -> c_char: ...

    @function_hook("48 89 5C 24 ? 48 89 7C 24 ? 55 48 8D 6C 24 ? 48 81 EC ? ? ? ? 0F 28 05 ? ? ? ? 48 8B D9")
    def StartEffect(self, this: "_Pointer[cGcTerrainEditorBeam]"): ...

    @function_hook("4C 89 44 24 ? 55 53 56 57 41 54 41 55 41 56 48 8D AC 24 ? ? ? ? 48 81 EC")
    def ApplyTerrainEditStroke(
        self,
        this: "_Pointer[cGcTerrainEditorBeam]",
        lEditData: sTerrainEditData,
        lImpact: c_uint64,  # cGcProjectileImpact *
    ) -> c_int64: ...

    @function_hook("48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8")
    def ApplyTerrainEditFlatten(
        self,
        this: "_Pointer[cGcTerrainEditorBeam]",
        lEditData: sTerrainEditData,
        lImpact: c_uint64,  # cGcProjectileImpact *
    ) -> c_uint64: ...


class cGcLocalPlayerCharacterInterface(Structure):
    @function_hook("40 53 48 83 EC 20 48 8B 1D ?? ?? ?? ?? 48 8D 8B ?? ?? ?? 00 E8 ?? ?? ?? 00")
    def IsJetpacking(self, this: "_Pointer[cGcLocalPlayerCharacterInterface]") -> c_bool: ...


@partial_struct
class cGcSpaceshipComponent(Structure):
    mpController: Annotated[_Pointer[cGcPlayerController], 0x5F20]
    mbControllerActive: Annotated[bool, Field(c_bool, 0x5F28)]
    mpPhysics: Annotated[_Pointer[cTkPhysicsComponent], 0x60A8]
    # Found near the top of cGcSpaceshipComponent::Update
    mfHeight: Annotated[float, Field(c_float, 0x656C)]
    meLandState: Annotated[int, Field(c_uint32, 0x7040)]  # cGcSpaceshipComponent::eLanding

    @function_hook("48 89 5C 24 18 48 89 54 24 10 57 48 83 EC 70 41 0F B6 F8")
    def Eject(
        self,
        this: "_Pointer[cGcSpaceshipComponent]",
        lpPlayer: _Pointer[cGcPlayer],
        lbAnimate: Annotated[bool, c_bool],
        lbForceDuringCommunicator: Annotated[bool, c_bool],
    ): ...

    @function_hook("F3 0F 11 4C 24 ? 55 53 56 41 54 41 55 48 8D AC 24")
    def Update(self, this: "_Pointer[cGcSpaceshipComponent]", lfTimeStep: Annotated[float, c_float]): ...

    @function_hook(
        "F3 0F 11 4C 24 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 "
        "2B E0 4C 8B A9"
    )
    def UpdateControlled(
        self,
        this: "_Pointer[cGcSpaceshipComponent]",
        lfTimeStep: Annotated[float, c_float],
    ): ...

    @function_hook("40 53 48 83 EC ? 48 8B 89 ? ? ? ? 48 8B DA 48 83 C1")
    def GetVelocity(
        self,
        this: "_Pointer[cGcSpaceshipComponent]",
        result: _Pointer[basic.cTkVector3],
    ) -> c_uint64:  # cTkVector3 *
        ...


@partial_struct
class cGcSpaceshipWarp(Structure):
    mePulseDriveState: Annotated[c_enum32[enums.EPulseDriveState], 0xA4]
    mfPulseDriveTimer: Annotated[float, Field(c_float, 0xB4)]
    mfPulseDriveFuelTimer: Annotated[float, Field(c_float, 0xB8)]
    mfPulseDriveTimer: Annotated[float, Field(c_float, 0x1A8)]
    mfPulseDriveFuelTimer: Annotated[float, Field(c_float, 0x1AC)]

    @function_hook("F3 0F 11 4C 24 ? 55 57 41 56 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 80 3D")
    def UpdatePulseDrive(
        self,
        this: "_Pointer[cGcSpaceshipWarp]",
    ): ...

    @function_hook(
        "48 83 EC ? 48 8B 0D ? ? ? ? BA ? ? ? ? 48 81 C1 ? ? ? ? C7 44 24 ? ? ? ? ? 41 B9 ? ? ? ? 41 B8 ? ? "
        "? ? E8 ? ? ? ? 48 85 C0 74 ? 66 0F 6E 40"
    )
    def GetPulseDriveFuelFactor(self, this: "_Pointer[cGcSpaceshipWarp]") -> c_float: ...


@partial_struct
class cGcSpaceshipWeapons(Structure):
    # These can be found in cGcSpaceshipWeapons::GetHeatFactor and cGcSpaceshipWeapons::GetOverheatProgress
    # This enum corresponds to the element in the following 3 arrays by index.
    meWeaponMode: Annotated[c_enum32[enums.cGcShipWeapons], 0xA4]
    mafWeaponHeat: Annotated[list[float], Field(c_float * 7, 0x5FA4)]
    mafWeaponOverheatTimer: Annotated[list[float], Field(c_float * 7, 0x5FC0)]
    mabWeaponOverheated: Annotated[list[bool], Field(c_bool * 7, 0x5FDC)]

    @function_hook("48 63 81 ?? ?? 00 00 80 BC 08 ?? ?? 00 00 00 74 12")
    def GetOverheatProgress(self, this: "_Pointer[cGcSpaceshipWeapons]") -> c_float: ...

    @function_hook("48 8B C4 48 89 70 ? 57 48 81 EC ? ? ? ? 83 79")
    def GetAverageBarrelPos(
        self,
        this: "_Pointer[cGcSpaceshipWeapons]",
        result: _Pointer[basic.cTkPhysRelVec3],
    ) -> c_uint64:  # cTkPhysRelVec3 *
        ...

    @function_hook(
        "40 53 48 83 EC ? 48 8B 51 ? 48 8B D9 0F BF 0D ? ? ? ? 48 8B 52 ? E8 ? ? ? ? 48 85 C0 0F 84"
    )
    def GetCurrentShootPoints(
        self,
        this: "_Pointer[cGcSpaceshipWeapons]",
    ) -> c_uint64:  # cGcShootPoint *
        ...

    @function_hook("48 63 81 ? ? ? ? F3 0F 10 84 81")
    def GetHeatFactor(self, this: "_Pointer[cGcSpaceshipWeapons]") -> c_float: ...


@partial_struct
class cGcPlayerCharacterComponent(Structure):
    # Found right at the top of cGcPlayerCharacterComponent::Update
    mbClonedJetpackMaterials: Annotated[bool, Field(c_bool, 0xCF0)]

    @function_hook("48 8B C4 48 89 58 ? 55 56 57 48 8D 68 ? 48 81 EC ? ? ? ? 4C 89 70")
    def SetDeathState(self, this: c_uint64): ...

    @function_hook("40 55 53 56 57 41 54 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 45 33 FF")
    def Update(
        self,
        this: "_Pointer[cGcPlayerCharacterComponent]",
        lfTimeStep: Annotated[float, c_float],
    ): ...


class cGcTextChatInput(Structure):
    @function_hook("40 55 53 57 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 80 3A")
    def ParseTextForCommands(
        self,
        this: "_Pointer[cGcTextChatInput]",
        lMessageText: _Pointer[basic.cTkFixedString[0x3FF]],
    ): ...


class cGcTextChatManager(Structure):
    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 48 8D 91 ? ? ? ? 33 FF")
    def Construct(self, this: "_Pointer[cGcTextChatManager]"): ...

    @function_hook("40 53 48 81 EC ? ? ? ? F3 0F 10 05")
    def Say(
        self,
        this: "_Pointer[cGcTextChatManager]",
        lsMessageBody: _Pointer[basic.cTkFixedString[0x3FF]],
        lbSystemMessage: Annotated[bool, c_bool],
    ): ...


class cGcNotificationSequenceStartEvent(Structure):
    @function_hook("48 89 5C 24 ? 57 48 83 EC ? 48 8B 81 ? ? ? ? 48 8D 91 ? ? ? ? 44 8B 81")
    def DeepInterstellarSearch(self, this: "_Pointer[cGcNotificationSequenceStartEvent]") -> c_char: ...


class PlanetGenerationQuery(Structure): ...


class cGcScanEventSolarSystemLookup(Structure): ...


class cGcScanEventManager(Structure):
    @static_function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 8B B1")
    @staticmethod
    def PassesPlanetInfoChecks(
        lPlanet: _Pointer[PlanetGenerationQuery],
        lSolarSystemLookup: _Pointer[cGcScanEventSolarSystemLookup],
        lbAbandonedSystemInteraction: Annotated[bool, c_bool],
        leBuildingClass: c_uint32,  # eBuildingClass
        lbIsAbandonedOrEmptySystem: Annotated[bool, c_bool],
    ) -> c_bool: ...


class cGcPlanetGenerator(Structure):
    @function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 55 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? "
        "? ? ? 4D 8B F8 C6 85"
    )
    def Generate(
        self,
        this: "_Pointer[cGcPlanetGenerator]",
        lPlanetData: _Pointer[nmse.cGcPlanetData],
        lGenerationData: _Pointer[nmse.cGcPlanetGenerationInputData],
        lpPlanet: _Pointer[cGcPlanet],
    ): ...

    @function_hook(
        "48 8B C4 48 89 50 ? 48 89 48 ? 55 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 89 58 ? 48 89 70 ? 49 8B F0"
    )
    def GenerateCreatureRoles(
        self,
        this: "_Pointer[cGcPlanetGenerator]",
        lPlanetData: _Pointer[nmse.cGcPlanetData],
        lUA: c_uint64,
    ): ...

    @function_hook(
        "48 8B C4 48 89 50 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 "
        "? 33 F6"
    )
    def GenerateCreatureInfo(
        self,
        this: "_Pointer[cGcPlanetGenerator]",
        lPlanetData: _Pointer[nmse.cGcPlanetData],
        lRole: _Pointer[nmse.cGcCreatureRoleData],
    ): ...

    @function_hook(
        "4C 89 4C 24 ? 48 89 54 24 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? "
        "? ? ? 48 2B E0 49 8B F0"
    )
    def GenerateQueryInfo(
        self,
        this: "_Pointer[cGcPlanetGenerator]",
        lQueryData: _Pointer[PlanetGenerationQuery],
        lGenerationData: _Pointer[nmse.cGcPlanetGenerationInputData],
        lUA: c_uint64,
    ): ...

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 4C 8B F9 0F 29 "
        "74 24"
    )
    def FillCreatureSpawnDataFromDescription(
        self,
        this: "_Pointer[cGcPlanetGenerator]",
        lRole: _Pointer[nmse.cGcCreatureRoleData],
        lSpawnData: _Pointer[nmse.cGcCreatureSpawnData],
        lPlanetData: _Pointer[nmse.cGcPlanetData],
    ): ...

    @function_hook("48 89 4C 24 ? 53 57 41 55 41 56")
    def GenerateCreatureSpawnData(
        self,
        this: "_Pointer[cGcPlanetGenerator]",
        lPlanetData: _Pointer[nmse.cGcPlanetData],
    ): ...


class cGcSolarSystemQuery(Structure):
    @function_hook("44 88 4C 24 ? 53 56 57")
    def Run(
        self,
        this: "_Pointer[cGcSolarSystemQuery]",
        lUA: c_uint64,
        leType: c_int32,  # cGcSolarSystemQuery::Type
        lbGenerateObjectLists: c_bool,  # in 4.13 but not current but probably because not used...
    ): ...


class cGcDiscoveryPageData(Structure): ...


class cGcFrontendTextInput(Structure): ...


class cGcFrontendModelRenderer(Structure): ...


class cGcFrontendPageDiscovery(Structure):
    @function_hook(
        "4C 89 4C 24 ? 4C 89 44 24 ? 48 89 54 24 ? 48 89 4C 24 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D "
        "AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 48 8B 99"
    )
    def DoDiscoveryView(
        self,
        this: "_Pointer[cGcFrontendPageDiscovery]",
        lPageData: _Pointer[cGcDiscoveryPageData],
        lFrontEndTextInput: _Pointer[cGcFrontendTextInput],
        lFronteEndModelRenderer: _Pointer[cGcFrontendModelRenderer],
    ): ...

    @static_function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8D 05 ? "
        "? ? ? 41 8B F9"
    )
    @staticmethod
    def GetDiscoveryHintString(
        result: _Pointer[basic.cTkFixedString[0x40]],
        leTileType: c_uint32,  # eTileType
        leCreatureType: c_enum32[enums.cGcCreatureTypes],
        leRarity: c_enum32[enums.cGcRarity],
        leActiveTime: c_enum32[enums.cGcCreatureActiveTime],
        leHemisphere: c_enum32[enums.cGcCreatureHemiSphere],
    ): ...


class cGcFrontendPage(Structure): ...


class cGcFrontendPagePortalRunes(Structure):
    @static_function_hook("48 8B C4 44 88 48 20 44 88 40 18 48 89 50 10 55 53 56 57 41 54")
    @staticmethod
    def CheckUAIsValid(
        lTargetUA: c_uint64,
        lModifiedUA: "_Pointer[cGcGalacticVoxelCoordinate]",
        lbDeterministicRandom: Annotated[bool, c_bool],
        a4: Annotated[bool, c_bool],
    ) -> c_bool: ...

    @function_hook("48 89 54 24 ? 48 89 4C 24 ? 55 57 41 55 41 56 48 8D 6C 24")
    def DoInteraction(
        self,
        this: "_Pointer[cGcFrontendPagePortalRunes]",
        lpPage: _Pointer[cGcFrontendPage],
    ): ...


class cTkLanguageManager(Structure):
    @static_function_hook(
        "48 83 EC ? 65 48 8B 04 25 ? ? ? ? B9 ? ? ? ? 48 8B 00 8B 04 01 39 05 ? ? ? ? 0F 8F ? ? ? ? 48 8D 05 "
        "? ? ? ? 48 83 C4 ? C3 4C 89 00"
    )
    @staticmethod
    def GetInstance() -> c_uint64: ...


@partial_struct
class cTkLanguageManagerBase(Structure):
    meRegion: Annotated[c_enum32[enums.eLanguageRegion], Field(c_enum32[enums.eLanguageRegion], 0x8)]

    @function_hook("48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F 57 C0 49 8B E8")
    def Translate(
        self,
        this: "_Pointer[cTkLanguageManagerBase]",
        lpacText: c_char_p64,
        lpacDefaultReturnValue: _Pointer[basic.TkID[0x20]],
    ) -> c_uint64: ...

    @function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ? 33 DB C6 44 24")
    def Load(
        self,
        this: "_Pointer[cTkLanguageManagerBase]",
        a2: c_char_p64,
        a3: Annotated[bool, c_bool],
    ): ...


@partial_struct
class cGcCreatureComponent(Structure):
    mMarkerPoint: Annotated[cGcMarkerPoint, 0x170]

    @function_hook("48 8B C4 55 56 41 56 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 51")
    def Prepare(self, this: "_Pointer[cGcCreatureComponent]"): ...


class cEgSceneGraphResource(Structure):
    @function_hook("4C 89 44 24 ? 55 53 56 57 41 55 41 56 48 8D AC 24")
    def ParseData(
        self,
        this: "_Pointer[cEgSceneGraphResource]",
        lData: c_uint64,  # std::string *
        lpParent: c_uint64,  # cEgSceneNodeTemplate *
    ) -> c_char:
        """Note: This function pattern is incorrect. Do not use it."""
        ...


class cGcApplicationBootState(Structure):
    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 54 41 56 41 57 48 81 EC ? ? ? ? 45 33 FF")
    def Update(
        self,
        this: "_Pointer[cGcApplicationBootState]",
        lfTimeStep: Annotated[float, c_float],
    ) -> c_uint64: ...


class cGcPlayerDiscoveryHelper(Structure):
    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 4C 24 ? 57 48 81 EC ? ? ? ? 48 8B 1D")
    def GetDiscoveryWorth(
        self,
        this: "_Pointer[cGcPlayerDiscoveryHelper]",
        lDiscoveryData: _Pointer[cGcDiscoveryData],
    ) -> c_uint64: ...


@partial_struct
class MenuAction(Structure): ...


class cGcQuickActionMenu(Structure):
    @function_hook("44 88 44 24 ? 48 89 4C 24 ? 55 56 57 41 54 41 56")
    def TriggerAction(
        self,
        this: "_Pointer[cGcQuickActionMenu]",
        lAction: _Pointer[MenuAction],
        lbCalledAsMenu: Annotated[bool, c_bool],
    ): ...


@partial_struct
class cGcPurchaseableItem(Structure):
    # Found in cGcPurchaseableItem::Update
    mePurchaseState: Annotated[int, Field(c_int32, 0x0)]  # cGcPurchaseableItem::ePurchaseState
    mItemType: Annotated[int, Field(c_int32, 0x4)]  # cGcPurchaseableItem::ePurchaseableItem
    mItemResource: Annotated[cTkSmartResHandle, 0x8]
    mItemNode: Annotated[basic.TkHandle, 0xC]
    mbIsFree: Annotated[bool, Field(c_bool, 0x20)]
    mbIsGift: Annotated[bool, Field(c_bool, 0x21)]
    mbIsReward: Annotated[bool, Field(c_bool, 0x22)]
    mbAddAdditionalItem: Annotated[bool, Field(c_bool, 0x31)]
    mbCleanResource: Annotated[bool, Field(c_bool, 0x1061)]
    mLinkedEntitlementId: Annotated[basic.TkID0x10, 0x1068]
    mLinkedEntitlementRewardId: Annotated[basic.TkID0x10, 0x1078]

    @function_hook("F3 0F 11 4C 24 ? 55 53 56 57 41 54 41 56 41 57 48 8D AC 24 ? ? ? ? B8")
    def Update(
        self,
        this: "_Pointer[cGcPurchaseableItem]",
        lfTimeStep: Annotated[float, c_float],
        a3: c_int64,
        a4: c_uint64,
    ): ...


@partial_struct
class cGcApplicationGameModeSelectorState(Structure):
    mPhase: Annotated[int, Field(c_uint32, 0xA60)]  # ModeSelectorPhase::Enum

    @function_hook(
        "48 8B C4 55 53 56 57 41 54 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 ? 48 8B F9"
    )
    def Update(
        self,
        this: "_Pointer[cGcApplicationGameModeSelectorState]",
        lfTimeStep: Annotated[float, c_float],
        # NOTE: This may have more arguments... 4 total in 4.13 exe, quite a few in mac binary.
    ): ...


@static_function_hook(
    "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 54 41 55 41 56 41 57 48 83 EC ? 33 FF 48 8D 59"
)
def GenerateModdedFilepath(
    Src: c_char_p64,
    Result: c_char_p64,
    lpacResultDirectory: c_char_p64,
    lpacBaseFilename: c_char_p64,
    lpacDirectory: c_char_p64,
    lbIsGlobal: Annotated[bool, c_bool],
) -> c_uint64:  # Length of generated filename.
    """Generate the filepath for the modded file to be written.

    Parameters
    ----------
    Result
        The full path to the file to be written.
    lpacResultDirectory
        The full directory path the file will be written in.
    lpacBaseFilename
        The filename to be written.
    lpacDirectory
        The directory the file is to be written to relative to the archive root.
    lbIsGlobal
        Indicates whether the file is a global. This is different to a "globals" file. This refers to files
        which are outside of mods (generally the TkGraphicsSettings.mxml and TkGameSettings.mxml).
    """
    ...


@partial_struct
class cTkFileSystem(Structure):
    @partial_struct
    class Data(Structure):
        mbMountBanks: Annotated[bool, Field(c_bool, 0x4658)]
        mbBanksTransparent: Annotated[bool, Field(c_bool, 0x4659)]
        mbIsModded: Annotated[bool, Field(c_bool, 0x465A)]
        mbIsTampered: Annotated[bool, Field(c_bool, 0x465B)]
        mArchiveRoot: Annotated[basic.cTkFixedString0x100, 0x465C]
        mModArchiveRoot: Annotated[basic.cTkFixedString0x100, 0x475C]
        mWorkingRoot: Annotated[basic.cTkFixedString0x100, 0x485C]
        mArchiveMountPoint: Annotated[basic.cTkFixedString0x100, 0x495C]

        @function_hook(
            "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 54 41 55 41 56 41 57 48 81 EC ? ? ? ? 48 8D 2D"
        )
        def Data(
            self,
            this: _Pointer["cTkFileSystem.Data"],
            lbMountBanks: Annotated[bool, c_bool],
            lbBanksTransparent: Annotated[bool, c_bool],
        ) -> c_uint64:  # _Pointer[cTkFileSystem.Data]
            ...

        @function_hook("4C 8B DC 45 88 43 ? 41 57")
        def MountAllArchives(
            self,
            this: _Pointer["cTkFileSystem.Data"],
            result: c_uint64,  # This is a vector of cTkBankInfo's
            lbCheckTampered: c_bool,
        ): ...

    # NOTE: This pattern is bad. It contains bytes from the proceeding function.
    @function_hook(
        "48 8B 01 48 85 C0 74 ? 0F B6 80 ? ? ? ? C3 C3 CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC 48 8B 01"
    )
    def IsModded(self, this: "_Pointer[cTkFileSystem]") -> c_bool: ...

    @static_function_hook(
        "48 83 EC ? 65 48 8B 04 25 ? ? ? ? B9 ? ? ? ? 48 8B 00 8B 04 01 39 05 ? ? ? ? 7F ? 48 8D 05 ? ? ? ? "
        "48 83 C4 ? C3 48 8D 0D ? ? ? ? E8 ? ? ? ? 83 3D ? ? ? ? ? 75 ? 48 8D 0D ? ? ? ? 48 C7 05"
    )
    @staticmethod
    def GetInstance() -> c_uint64: ...

    @function_hook("40 55 53 56 57 41 55 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8D 45")
    def EnumerateDirectory(
        self,
        this: "_Pointer[cTkFileSystem]",
        lpacPath: c_char_p64,
        lpaacDirectoryNamesOut: _Pointer[c_char_p64],
        liNumEntries: c_int32,
        liMaxStringSize: c_int32,
    ) -> c_uint64: ...

    @function_hook("48 8B C4 53 48 81 EC ? ? ? ? 80 3A")
    def DoesFileExist(
        self,
        this: "_Pointer[cTkFileSystem]",
        lpacPath: c_char_p64,
        a3: c_char_p64,
        lbSearchWorkingRoot: Annotated[bool, c_bool],
    ) -> c_uint64:
        # If lbSearchWorkingRoot is True, then it will check the path relative to `this.mWorkingRoot` which is
        # the GAMEDATA folder. Otherwise it will search `this.mArchiveMountPoint`
        # Note: This doesn't actually really check if the file exists or not, but it's used a lot so it's a
        # good way to know if the game is trying to find a file or directory to do something with.
        ...

    @function_hook(
        "48 89 5C 24 ? 4C 89 44 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 33 F6"
    )
    def LoadModDirectory(
        self,
        this: "_Pointer[cTkFileSystem]",
        lpacPath: c_char_p64,
        a3: c_char_p64,
        liMaxDirectories: Annotated[int, c_int32],
        a5: Annotated[int, c_int32],
        a6: c_uint64,
    ) -> c_uint64: ...

    @function_hook(
        "48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 4C 89 74 24 ? 55 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 "
        "8B FA 48 8B F1"
    )
    def LoadModSubDirectory(
        self,
        this: "_Pointer[cTkFileSystem]",
        lpacPath: c_char_p64,
        a3: c_char_p64,
        a4: Annotated[bool, c_bool],
        a5: Annotated[bool, c_bool],
        a6: c_uint64,
        a7: Annotated[bool, c_bool],
    ) -> c_bool: ...

    @function_hook("48 81 EC ? ? ? ? 41 B1")
    def CreatePath(self, this: "_Pointer[cTkFileSystem]", lpacPath: c_char_p64): ...

    @function_hook("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B 7C 24 ? 49 8B F0")
    def Write(
        self,
        this: "_Pointer[cTkFileSystem]",
        lpData: c_void_p,
        liSize: c_uint64,
        liNumElements: c_uint64,
        lFile: c_uint64,  # FIOS2HANDLE *
    ) -> c_uint64: ...

    @function_hook("40 53 56 57 48 81 EC ? ? ? ? 45 85 C0")
    def Open(
        self,
        this: "_Pointer[cTkFileSystem]",
        lpacFileName: c_char_p64,
        leMode: c_enum32[enums.eFileOpenMode],
    ) -> c_uint64:  # FIOS2HANDLE *
        ...

    mpData: Annotated[_Pointer[Data], 0x0]


# Note: There is no corresponding class in the 4.13 binary, nor in the mac binary unfortunately.
# All method names are guessed.
@partial_struct
class cGcModManager(Structure):
    liModCount: Annotated[int, Field(c_int32, 0x4)]

    @partial_struct
    class ModInfo(Structure):
        # This Struct and it's info is mostly determined from
        _total_size_ = 0x640
        liIndex: Annotated[int, Field(c_uint16, 0x28)]
        # Looks like there might be another cTkFixedString0x80 here too based on the constructor.
        mModName: Annotated[basic.cTkFixedString0x80, 0xAA]
        lbUnknown0x12A: Annotated[bool, Field(c_bool, 0x12A)]
        lbUnknown0x12B: Annotated[bool, Field(c_bool, 0x12B)]
        # Looks like this might be 8 * 0x80's from 0x130
        lpacPath: Annotated[c_char_p, 0x530]
        liUnknown0x630: Annotated[int, Field(c_int32, 0x630)]
        lbUnknown0x634: Annotated[bool, Field(c_bool, 0x634)]
        lbHasGlobals: Annotated[bool, Field(c_bool, 0x635)]
        lbHasBaseBuildingParts: Annotated[bool, Field(c_bool, 0x636)]
        lbHasLocTable: Annotated[bool, Field(c_bool, 0x637)]
        lbAlsoHasBaseBuildingPartsButDifferent: Annotated[bool, Field(c_bool, 0x638)]  # ???

    @static_function_hook(
        "48 83 EC ? 65 48 8B 04 25 ? ? ? ? B9 ? ? ? ? 48 8B 00 8B 04 01 39 05 ? ? ? ? 0F 8F ? ? ? ? 48 8D 05 "
        "? ? ? ? 48 83 C4 ? C3 48 8D 0D"
    )
    @staticmethod
    def GetInstance() -> c_uint64: ...

    @function_hook("40 55 53 56 57 41 55 41 56 48 8D AC 24 ? ? ? ? B8")
    def LoadModdedData(
        self,
        this: "_Pointer[cGcModManager]",
        lbVREnabled: Annotated[bool, c_bool],
    ) -> c_bool: ...


class cTkMemoryManager(Structure):
    @function_hook("44 89 4C 24 ? 4C 89 44 24 ? 53")
    def Malloc(
        self,
        this: "_Pointer[cTkMemoryManager]",
        liSize: Annotated[int, c_int32],
        lpacFile: Annotated[int, c_uint64],  # const char *
        liLine: Annotated[int, c_int32],
        lpacFunction: Annotated[int, c_uint64],  # const char *
        liAlign: Annotated[int, c_int32],
        liPool: Annotated[int, c_int32],
    ) -> c_void_p:
        """Hello Games' internal memory allocation function. This is used extensively.
        Hook with extreme caution! Doing so may easily crash the game or cause it to run VERY slow."""
        ...

    @function_hook("48 85 D2 0F 84 ? ? ? ? 53 41 56")
    def Free(self, this: "_Pointer[cTkMemoryManager]", lpPointer: c_void_p, liPool: Annotated[int, c_int32]):
        """Hello Games' internal memory freeing function. Never call this function with an lpPointer value
        that was not generated by a Malloc call previously from NMS.py, and never try and clear memory
        allocated by the game itself otherwise you will almost certainly crash the game."""
        ...

    @contextmanager
    def TemporaryMemory(self, size: int) -> Generator[Optional[memoryview], None, None]:
        """Create a temporary block of memory of the specified size.
        This will return a memoryview which can then be modified"""
        addr = None
        try:
            if (addr := self.Malloc(size, 0, 0, 0, 16, -1)) is not None:
                yield _get_memview_with_size(int(addr), size)
        finally:
            if addr is not None:
                self.Free(addr, -1)


class cGcOptionsPageUI(Structure):
    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 33 DB 48 8D 79 ? 89 59"
    )
    def BeginList(
        self,
        this: "_Pointer[cGcOptionsPageUI]",
        lpacMainText: c_char_p64,
        lpacDescriptionText: c_char_p64,
        liCurrentValue: Annotated[int, c_int32],
        liDefaultValue: Annotated[int, c_int32],
        a6: _Pointer[c_int32],
    ): ...

    @function_hook("4C 8B DC 4D 89 43 ? 49 89 53 ? 49 89 4B ? 53 56")
    def QualityOption(
        self,
        this: "_Pointer[cGcOptionsPageUI]",
        lpacOptionName: c_char_p64,
        lpacDescriptionLocKey: c_char_p64,
        leValue: c_enum32[enums.eGraphicsDetail],
        leDefaultValue: c_enum32[enums.eGraphicsDetail],
    ) -> c_uint64: ...

    @function_hook("40 53 48 83 EC ? 48 63 41 ? 48 8D 59")
    def ListOption(
        self,
        this: "_Pointer[cGcOptionsPageUI]",
        lpacOptionText: c_char_p64,
        liValue: Annotated[int, c_int32],
    ): ...


class cGcFrontendPageFunctions(Structure):
    @static_function_hook(
        "4C 89 4C 24 ? 4C 89 44 24 ? 48 89 54 24 ? 48 89 4C 24 ? 55 53 56 57 41 55 41 56 41 57 48 8D AC 24"
    )
    @staticmethod
    def DoEmptySlotPopup(
        lpPage: _Pointer[cGcFrontendPage],
        lpSlot: _Pointer[cGcNGuiLayer],
        lEmptySlotActions: c_uint64,  # std::vector<enum ePopupAction,TkSTLAllocatorShim<enum ePopupAction,4,-1> >  # noqa
        lIndex: _Pointer[nmse.cGcInventoryIndex],
        lpCurrentInventory: _Pointer[cGcInventoryStore],
    ): ...

    @static_function_hook("48 89 74 24 ? 48 89 7C 24 ? 55 48 8B EC 48 83 EC ? 0F B6 0D")
    @staticmethod
    def SetEmptySlotBackground(
        lpPage: _Pointer[cGcFrontendPage],
        lpSlot: _Pointer[cGcNGuiLayer],
        leChoice: Annotated[int, c_uint32],
        lbUseSpecialTechSlot: Annotated[bool, c_bool],
    ): ...

    @static_function_hook(
        "48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 4C 89 40 ? 55 41 54 41 55 41 56 41 57 48 8D 68 ? 48 81 EC "
        "? ? ? ? 0F 29 78"
    )
    @staticmethod
    def SetPopupBasics(
        lpParentLayer: _Pointer[cGcFrontendPage],
        lpacTitle: c_char_p64,
        lColour: _Pointer[basic.Colour],
        lpacDescription: _Pointer[basic.cTkFixedString0x200],
        lpacSubtitle: _Pointer[basic.cTkFixedString0x200],
        lpacType: c_char_p64,
        lpacTechTreeCost: c_char_p64,
        lpacTechTreeCostAlt: c_char_p64,
        lbSpecialSubtitle: Annotated[bool, c_bool],
        liAmountToShow: Annotated[int, c_int32],
        lLayerIDOverride: c_uint64,  # __m128i *
    ) -> c_uint64:  # cGcNGuiLayer *
        ...

    @static_function_hook("48 85 D2 0F 84 ? ? ? ? 48 8B C4 4C 89 48 ? 4C 89 40")
    @staticmethod
    def DoInventorySlots(
        lpPage: _Pointer[cGcFrontendPage],
        lpInventoryGuiLayer: _Pointer[cGcNGuiLayer],
        lpInventory: _Pointer[cGcInventoryStore],
        lEmptySlotActions: c_uint64,  # std::vector<enum ePopupAction,TkSTLAllocatorShim<enum ePopupAction,4,-1> > *  # noqa
        liInventoryRenderSlotsWide: Annotated[int, c_int32],
        lPopupActions: Annotated[int, c_int32],
        lbDisabled: Annotated[bool, c_bool],
        lMinIndex: _Pointer[nmse.cGcInventoryIndex],
        liSlotWidth: Annotated[int, c_int32],
        liSlotHeight: Annotated[int, c_int32],
        lbCanHideSlots: Annotated[bool, c_bool],
        liRenderWidth: Annotated[int, c_int32],
        liRenderHeight: Annotated[int, c_int32],
        lbDoCompareScreenSpecialCase: Annotated[bool, c_bool],
        lfScrollOffset: Annotated[float, c_float],
    ): ...


class cTkSystem(Structure):
    @function_hook("80 B9 ? ? ? ? ? 75 ? 83 3D")
    def IntegratedGPUActive(self, this: "_Pointer[cTkSystem]") -> c_bool: ...

    @static_function_hook(
        "40 53 48 83 EC ? 65 48 8B 04 25 ? ? ? ? B9 ? ? ? ? 48 8B 00 8B 04 01 39 05 ? ? ? ? 7F ? 48 8D 05 ? "
        "? ? ? 48 83 C4 ? 5B C3 90"
    )
    @staticmethod
    def GetInstance() -> c_uint64: ...


class cTkEngineSettings(Structure):
    @function_hook("48 83 EC ? 83 EA ? 74 ? 83 FA")
    def GetSettingSupport(
        self,
        this: "_Pointer[cTkEngineSettings]",
        leEngineSetting: c_uint32,  # eEngineSetting
    ) -> c_bool: ...


class cTkEngineUtils(Structure):
    @static_function_hook("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 41 8B F0 48 8B F9")
    @staticmethod
    def GetMasterModelNode(
        result: _Pointer[basic.TkHandle],
        lNode: basic.TkHandle,
        lDistance: c_int32,
    ) -> c_uint64:  # TkHandle *
        ...

    @static_function_hook("48 83 EC ? 49 8B C0 48 85 D2")
    @staticmethod
    def GetMatricesFromNode(
        lHandle: basic.TkHandle,
        lAbsoluteMatrix: _Pointer[basic.cTkMatrix34],
        lRelativeMatrix: _Pointer[basic.cTkMatrix34],
    ) -> c_char: ...

    @static_function_hook("89 4C 24 ? 53 56 41 54 41 55")
    @staticmethod
    def LoadResourcesFromDisk(lBalancing: Annotated[int, c_int32]) -> c_uint64: ...

    @static_function_hook("40 53 48 81 EC ? ? ? ? 66 0F 6F 05 ? ? ? ? 8B D9")
    @staticmethod
    def RepositionGroupNode(lGroupNode: basic.TkHandle, lDesiredPosition: _Pointer[basic.cTkVector3]): ...


class cTkMetaDataXML(Structure):
    @static_function_hook("4C 89 4C 24 ? 4C 89 44 24 ? 48 89 54 24 ? 48 89 4C 24 ? 53 48 83 EC")
    @staticmethod
    def Register(
        lpacName: c_char_p64,
        lWriteFunction: c_uint64,
        lReadFunction: c_uint64,
        lSaveFunction: c_uint64,
    ): ...

    @static_function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 48 8B 05 ? ? ? ? 48 8B E9"
    )
    @staticmethod
    def GetLookup(lpacName: c_char_p64) -> c_uint64: ...


@partial_struct
class cGcNGuiNodeInfo(Structure):
    # Found in cGcNGuiNodeInfo::Get. It's the same as 4.13 other than the maChildren type...
    mNode: Annotated[basic.TkHandle, 0x8]
    mString: Annotated[basic.cTkFixedString0x100, 0xC]
    mTypeName: Annotated[basic.cTkFixedString0x80, 0x10C]
    maChildren: Annotated["basic.TkStd.tk_vector[_Pointer[cGcNGuiNodeInfo]]", 0x190]

    @function_hook("48 89 5C 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 81 EC ? ? ? ? 4C 8B F9")
    def Get(self, this: "_Pointer[cGcNGuiNodeInfo]", lNode: basic.TkHandle): ...


@partial_struct
class cEgSceneNode(Structure):
    _total_size_ = 0x38
    mLookupHandle: Annotated[basic.TkHandle, 0x8]
    muNameHash: Annotated[int, Field(c_uint32, 0xC)]
    mResHandle: Annotated[cTkSmartResHandle, 0x10]
    muNetworkId: Annotated[int, Field(c_uint32, 0x14)]
    msName: Annotated[cTkSharedPtr[c_char_p64], 0x18]  # TODO: This should maybe be a basic.TkStd.tk_string?
    mpAltId: Annotated[cTkSharedPtr[cTkResourceDescriptor], 0x20]


@partial_struct
class cEgShaderResource(cEgResource):
    pass


# The following 2 structs are essentially the same as the exported versions, however there seems to be a hash
# at the start. Theoretically the uniform data itself is probably inlined, but we'll map it as a field so that
# if the structure of the exported versions changes then this will too automatically.


@partial_struct
class cTkMaterialUniform_Float(Structure):
    mu64Hash: Annotated[int, Field(c_uint64, 0x0)]
    mMaterialUniform: Annotated[nmse.cTkMaterialUniform_Float, 0x10]


@partial_struct
class cTkMaterialUniform_UInt(Structure):
    mu64Hash: Annotated[int, Field(c_uint64, 0x0)]
    mMaterialUniform: Annotated[nmse.cTkMaterialUniform_UInt, 0x8]


@partial_struct
class cEgMaterialSampler(Structure):
    _total_size_ = 0x68
    msName: Annotated[basic.TkStd.tk_string, 0x0]
    mpTextureResource: Annotated[cTkTypedSmartResHandle[cEgTextureResource], 0x40]


@partial_struct
class cEgMaterialResource(cEgResource):
    _total_size_ = 0x2C8
    # Found in cEgMaterialResource::ParseNode
    mShaderFlags: Annotated[int, Field(c_int16, 0x1CC)]
    mMaterialClass: Annotated[int, Field(c_uint8, 0x1CF)]  # Technically enums.cTkMaterialClass
    mpShaderResource: Annotated[cTkTypedSmartResHandle[cEgShaderResource], 0x1D8]
    # NOTE: The following types are actually ankerl::unordered_dense::table
    # The data is stored in a std::vector but it looks like there is extra data afterwards for this type.
    # DO NOT modify this vector as it will certainly break this data type.
    maUniforms_float: Annotated[std.vector[cTkMaterialUniform_Float], 0x1F8]
    maUniforms_uint: Annotated[std.vector[cTkMaterialUniform_UInt], 0x230]
    mSamplers: Annotated[std.vector[cEgMaterialSampler], 0x268]

    @function_hook("48 89 54 24 ? 48 89 4C 24 ? 55 53 57 41 54 41 55 41 56 48 8D AC 24")
    def ParseNode(self, this: "_Pointer[cEgMaterialResource]", lData: nmse.cTkMaterialData) -> c_bool: ...


# @partial_struct
# class cEgRenderableSceneNode(cEgSceneNode):
#     mpMaterialResource: Annotated[cTkTypedSmartResHandle[cEgMaterialResource], 0x38]
#     _mpParentModel: Annotated[int, Field(c_uint64, 0x48)]

#     @property
#     def mpParentModel(self) -> "_Pointer[cEgModelNode]":
#         return map_struct(get_addressof(self._mpParentModel), _Pointer[cEgModelNode])


@partial_struct
class cEgJointNode(cEgSceneNode):
    _total_size = 0xA0

    _mpParentModel: Annotated[int, Field(c_uint64, 0x48)]
    mBaseMatrix: Annotated[basic.cTkMatrix34, 0x50]
    muJointIndex: Annotated[int, Field(c_uint32, 0x90)]

    @property
    def mParentModel(self) -> "cEgModelNode":
        return cEgModelNode.from_address(self._mpParentModel)


@partial_struct
class cEgBoundingBox(Structure):
    mMin: Annotated[basic.Vector3f, 0x0]
    mMax: Annotated[basic.Vector3f, 0x0]


@partial_struct
class cEgAnimationController(Structure):
    # Padded into cEgAnimationController::EvalCommandListInternal in cEgModelNode::Animate
    mAdditivePose: Annotated[basic.TkStd.tk_vector[AnimTransform], 0xB0]
    maNodeToJoint: Annotated[basic.TkStd.tk_vector[c_int32], 0xC0]
    maJointToNode: Annotated[basic.TkStd.tk_vector[c_int32], 0xD0]
    mabIgnoreAnimation: Annotated[basic.TkStd.tk_vector[c_bool], 0xE0]
    mbDirty: Annotated[bool, Field(c_bool, 0x184)]


@partial_struct
class cEgModelNode(cEgSceneNode):
    @partial_struct
    class AnimationWorkBuffer(Structure):
        maPose: Annotated[_Pointer[basic.cTkMatrix34], 0x0]
        maRelativeModelMatrix: Annotated[_Pointer[basic.cTkMatrix34], 0x8]
        mLocalAabb: Annotated[cEgBoundingBox, 0x10]

    mpGeometryResource: Annotated[cTkTypedSmartResHandle[cEgGeometryResource], 0x38]
    muVertBufferIndex: Annotated[int, Field(c_uint32, 0x60)]
    # mRenderableList: Annotated[basic.TkStd.tk_vector[_Pointer[cEgRenderableSceneNode]], 0x70]
    # Found at the top of cEgModelNode::UpdateGeometry and cEgModelNode::PrepAnimate
    mSkinMatrixInds: Annotated[basic.TkStd.tk_vector[c_uint16], 0x80]
    mAnimationController: Annotated[cEgAnimationController, 0xA0]
    mSkinMatrixRows: Annotated[basic.TkStd.tk_vector[basic.Vector4f], 0x258]
    mJointList: Annotated[basic.TkStd.tk_vector[_Pointer[cEgJointNode]], 0x280]
    maJointIndex: Annotated[basic.TkStd.tk_vector[c_int32], 0x290]
    maJointParentIndex: Annotated[basic.TkStd.tk_vector[c_int32], 0x2A0]
    miMaxJointIndex: Annotated[int, Field(c_int32, 0x2B0)]
    # Found at the top of cEgModelNode::Animate
    mAnimWorkBuf: Annotated[AnimationWorkBuffer, 0x370]

    @function_hook("4C 8B DC 55 53 49 8D AB ? ? ? ? 48 81 EC ? ? ? ? 48 8D 81")
    def UpdateGeometry(self, this: "_Pointer[cEgModelNode]") -> c_char: ...

    @function_hook("40 53 48 81 EC ? ? ? ? 48 83 B9 ? ? ? ? ? 48 8B D9 0F 84 ? ? ? ? 48 83 B9")
    def Animate(self, this: "_Pointer[cEgModelNode]"): ...


@partial_struct
class cEgMeshNode(cEgSceneNode):
    _total_size_ = 0xE0

    # These top two are found in cEgRenderableSceneNode::cEgRenderableSceneNode.
    # Most of the remaining fields are found in cEgMeshNode::cEgMeshNode.
    mpMaterialResource: Annotated[cTkTypedSmartResHandle[cEgMaterialResource], 0x38]
    mpParentModel: Annotated[_Pointer[cEgModelNode], 0x48]
    miNodeIndex: Annotated[int, Field(c_int32, 0x58)]
    miNodeLOD: Annotated[int, Field(c_int32, 0x5C)]

    mAABBMinBox: Annotated[basic.Vector4f, 0x60]
    mAABBMaxBox: Annotated[basic.Vector4f, 0x70]
    unknownVector: Annotated[basic.Vector4f, 0x80]
    # mUserData: Annotated[basic.Vector4f, 0xA0]  # Where does this go?

    muBatchStart: Annotated[int, Field(c_uint32, 0x98)]
    muBatchCount: Annotated[int, Field(c_uint32, 0x9C)]
    muBatchStartPhysics: Annotated[int, Field(c_uint32, 0xA0)]
    muVertRStart: Annotated[int, Field(c_uint32, 0xA4)]
    muVertREnd: Annotated[int, Field(c_uint32, 0xA8)]
    muVertRStartPhysics: Annotated[int, Field(c_uint32, 0xAC)]
    muVertREndPhysics: Annotated[int, Field(c_uint32, 0xB0)]
    muBvVertStart: Annotated[int, Field(c_uint32, 0xB4)]
    muBvVertEnd: Annotated[int, Field(c_uint32, 0xB8)]
    # Note: This first and last skin mat refer to the index in the cEgModelNode.mSkinMatrixInds field.
    muFirstSkinMat: Annotated[int, Field(c_uint32, 0xBC)]
    muLastSkinMat: Annotated[int, Field(c_uint32, 0xC0)]
    mfLodFade: Annotated[float, Field(c_float, 0xC4)]
    muLodLevel: Annotated[int, Field(c_uint32, 0xCC)]
    miGeometryBufferIndex: Annotated[int, Field(c_int32, 0xD0)]

    @static_function_hook("48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 4C 8B F9 49 8B E8")
    @staticmethod
    def ParsingFunc(
        lAttributes: _Pointer[basic.cTkDynamicArray[nmse.cTkSceneNodeAttributeData]],
        lpResourceDescriptor: _Pointer[cTkResourceDescriptor],
        lxResourceFlags: Annotated[int, c_int32],
    ) -> c_uint64:  # cEgMeshNodeTemplate*
        ...


@partial_struct
class cEgRenderQueue(Structure):
    pass


@partial_struct
class cTkVertexBufferSlot(Structure):
    # Assuming this hasn't changed since 4.13 other than the last 2 fields which can be seen in
    # cEgRenderer::cEgRenderer
    _total_size_ = 0x20
    muVertexBufferObject: Annotated[int, Field(c_uint32, 0x0)]
    muOffset: Annotated[int, Field(c_uint32, 0x4)]
    muStride: Annotated[int, Field(c_uint32, 0x8)]
    miLayoutElementCount: Annotated[int, Field(c_int32, 0xC)]
    mbIsDirty: Annotated[bool, Field(c_bool, 0x10)]
    miHash: Annotated[int, Field(c_uint64, 0x18)]


@partial_struct
class cEgRBObjects_cTkBuffer(Structure):
    _total_size_ = 0x90
    mObjects: Annotated[basic.TkStd.tk_vector[cTkBuffer], 0x0]
    mFreeList: Annotated[basic.TkStd.tk_vector[c_uint32], 0x10]
    mUsedBits: Annotated[basic.TkStd.tk_vector[c_uint64], 0x20]
    # _RTL_CRITICAL_SECTION mAllocCriticalSection
    mDebugName: Annotated[basic.cTkFixedString0x40, 0x58]


@partial_struct
class cEgRendererBase(Structure):
    mVertexBufferSlots: Annotated[tuple[cTkVertexBufferSlot, ...], Field(cTkVertexBufferSlot * 0x10, 0x8)]
    mBuffers: Annotated[cEgRBObjects_cTkBuffer, 0x208]

    @function_hook(
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 48 8B F9 49 8B E9 48 81 C1"
    )
    def CreateVertexBuffer(
        self,
        this: "_Pointer[cEgRendererBase]",
        luSize: Annotated[int, c_int32],
        lpData: c_void_p,
        lVertexDecl: _Pointer[cTkVertexLayoutRT],
        luVertexCount: Annotated[int, c_uint32],
        a6: Annotated[bool, c_bool],
        lbMappable: Annotated[bool, c_bool],
        lbPersistent: Annotated[bool, c_bool],
    ) -> c_uint64: ...

    @function_hook("44 89 44 24 ? 48 89 54 24 ? 48 89 4C 24 ? 53 55 56 57 41 55")
    def ApplyVertexLayout(
        self,
        this: "_Pointer[cEgRendererBase]",
        lVertexLayout: _Pointer[cTkVertexLayoutRT],
        lShader: c_uint64,  # cTkShader *
        lpRenderData: _Pointer[cEgThreadableRenderCall],
        liSlot: Annotated[int, c_int32],
    ) -> c_char: ...


class cEgPipelineCommand(Structure):
    pass


@partial_struct
class cEgRenderer(cEgRendererBase):
    _total_size_ = 0x145A0

    @static_function_hook("48 8B C4 44 89 40 ? 48 89 48 ? 55 53 41 54")
    @staticmethod
    def DrawMeshes(
        lRenderQueue: _Pointer[cEgRenderQueueBuffer],
        lsShaderContext: _Pointer[basic.TkID0x10],
        liShaderContextVariant: Annotated[int, c_uint32],
        a4: c_uint64,  # Not used?
        leOrder: Annotated[int, c_int32],  # Not used
        lbSinglePassStereo: Annotated[bool, c_bool],
        lFrustum: c_uint64,  # cEgFrustum *
        lpThreadRenderData: _Pointer[cEgThreadableRenderCall],
    ): ...

    @static_function_hook("44 88 4C 24 ? 4C 89 44 24 ? 48 89 54 24 ? 48 89 4C 24 ? 55 53 56 57 41 54 41 57")
    @staticmethod
    def DrawRenderables(
        lRenderQueue: _Pointer[cEgRenderQueue],
        lFrustum: c_uint64,  # cEgFrustum *
        lNodeType: _Pointer[basic.TkID0x10],
        lsMaterialClass: c_char_p64,
        lsShaderContext: _Pointer[basic.TkID0x10],
        liShaderContextVariant: Annotated[int, c_uint32],
        a7: c_uint64,
        leOrder: Annotated[int, c_int32],
        liRenderFromIndex: Annotated[int, c_uint32],
        liRenderToIndex: Annotated[int, c_uint32],
        lpThreadData: _Pointer[cEgThreadableRenderCall],
        lbRenderStereo: Annotated[bool, c_bool],
        lbRenderStereoSinglePass: Annotated[bool, c_bool],
    ): ...

    @static_function_hook("48 8B C4 48 89 58 ? 48 89 78 ? 4C 89 70 ? 55 48 8D 68 ? 48 81 EC ? ? ? ? 48 8B 9D")
    @staticmethod
    def SetupMeshMaterial(
        lpMaterialResource: _Pointer[cEgMaterialResource],
        lShaderContext: c_void_p,  # const TkIDHashed<128> *
        liShaderContextVariant: Annotated[int, c_int32],  # GPU::eContextVariant
        lMeshRSTransform: _Pointer[basic.cTkMatrix34],
        lMeshPrevRSTransform: _Pointer[basic.cTkMatrix34],
        lViewMat: _Pointer[basic.cTkMatrix44],
        lProjMat: _Pointer[basic.cTkMatrix44],
        lViewProjMat: _Pointer[basic.cTkMatrix44],
        mUserData: basic.Vector4f,  # TODO: See if this actually needs to be a pointer?
        lfFade: Annotated[float, c_float],
        a11: Annotated[int, c_int32],
        liLodIndex: Annotated[int, c_int32],
        a13: Annotated[int, c_int32],
        lpSkinMatrixRows: _Pointer[basic.Vector4f],
        lpPrevSkinMatrixRows: _Pointer[basic.Vector4f],
        liNumSkinMatrixRows: Annotated[int, c_int32],
        a17: c_void_p,  # unknown
        a18: Annotated[int, c_uint8],
        lbIsStereo: Annotated[bool, c_bool],
        lpThreadRenderData: _Pointer[cEgThreadableRenderCall],
        lpShaderBinding: c_void_p,  # cEgShaderUniformBufferBinding *
    ) -> c_char: ...

    @static_function_hook("48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 54 41 56 41 57 48 83 EC ? 49 8B F9")
    @staticmethod
    def SetupMeshGeometry(
        lu64Hash: c_uint64,
        lpMeshNode: _Pointer[cEgMeshNode],
        lpGeometryResource: _Pointer[cEgGeometryResource],
        lpRenderStateCache: _Pointer[cTkRenderStateCache],
    ) -> c_bool: ...

    @function_hook("4C 89 4C 24 ? 4C 89 44 24 ? 48 89 54 24 ? 48 89 4C 24 ? 55 56 41 54 41 55")
    def ExecutePipelineCommand(
        self,
        this: "_Pointer[cEgRenderer]",
        lPipelineCommand: _Pointer[cEgPipelineCommand],
        lpThreadRenderCall: _Pointer[cEgThreadableRenderCall],
        lpcPipelineName: c_char_p64,
        lpcPipelineStageName: c_char_p64,
        lpFlowRunStack: c_void_p,  # cEgFlowRunStack *
        lpOutCommandIdx: _Pointer[c_uint32],
        lpOutRenderStateCache: _Pointer[cTkRenderStateCache],
    ) -> c_uint64: ...


class cEgStructureIndex(Structure):
    miNumChildren: int
    mbIsFirstChild: bool
    mParentHandle: basic.TkHandle
    miFirstChildIdx: int
    miPrevSiblingIdx: int
    miNextSiblingIdx: int

    _fields_ = [
        ("miNumChildren", c_uint32, 31),
        ("mbIsFirstChild", c_uint32, 1),
        ("mParentHandle", basic.TkHandle),
        ("miFirstChildIdx", c_int32),
        ("miPrevSiblingIdx", c_int32),
        ("miNextSiblingIdx", c_int32),
    ]


class cEgSceneNodeFlags(Structure):
    mbActive: bool
    mbRenderable: bool
    mbRenderableDescendents: bool
    mbShadowOnly: bool
    muShadowCascade: bool
    mbRemoved: bool
    mbShouldCull: bool
    mbInstance: bool
    mbSelfOrAncestorTransformDirty: bool
    mbSelfOrDescendentAABBDirty: bool
    mbUpdates: bool
    mbAsyncUpdateRequested: bool
    mbUpdatesAsync: bool
    # mbLodUpdatesRequested: bool

    # NOTE: This is the 4.13 representation and is no longer valid.
    _fields_ = [
        # bit      mask
        ("mbActive", c_uint8, 1),  # 0.0 -> & 0x1
        ("mbRenderable", c_uint8, 1),  # 0.1 -> & 0x2
        ("mbRenderableDescendents", c_uint8, 1),  # 0.2 -> & 0x4
        ("mbShadowOnly", c_uint8, 1),  # 0.3 -> & 0x8
        ("muShadowCascade", c_uint8, 1),  # 0.4 -> & 0x10
        ("mbRemoved", c_uint8, 1),  # 0.5 -> & 0x20
        ("mbShouldCull", c_uint8, 1),  # 0.6 -> & 0x40
        ("mbInstance", c_uint8, 1),  # 0.7 -> & 0x80
        ("unknown1_0", c_uint8, 1),  # 1.0 -> & 0x1
        ("unknown1_1", c_uint8, 1),  # 1.1 -> & 0x2
        ("unknown1_2", c_uint8, 1),  # 1.2 -> & 0x4
        # Found in cGcPlayerFreighterOwnership::ResetPlayerFreighterBase
        ("mbSelfOrAncestorTransformDirty", c_uint8, 1),  # 1.3 -> & 0x8
        # Found in cEgSceneNodeData::MarkSelfOrDescendentsAABBDirty
        ("mbSelfOrDescendentAABBDirty", c_uint8, 1),  # 1.4 -> & 0x10
        ("mbUpdates", c_uint8, 1),  # 1.5 -> & 0x20
        ("mbAsyncUpdateRequested", c_uint8, 1),  # 1.6 -> & 0x40
        ("mbUpdatesAsync", c_uint8, 1),  # 1.7 -> & 0x80
        # ("mbLodUpdatesRequested", c_uint8, 1),           # 1.8 -> & 0x20
    ]


@partial_struct
class cEgSceneNodeData(Structure):
    # These are found in a few Engine:: functions.
    mpRelativeTransformBuffer: Annotated[_Pointer[basic.cTkMatrix34], 0x48]
    mpPrevRelativeTransformBuffer: Annotated[_Pointer[basic.cTkMatrix34], 0x48]
    mpLocalBoundingBoxBuffer: Annotated[_Pointer[cEgBoundingBox], 0x58]
    mpAbsoluteTransformBuffer: Annotated[_Pointer[basic.cTkMatrix34], 0x60]
    mpStructureBuffer: Annotated[_Pointer[cEgStructureIndex], 0x70]
    # Found in cGcNGuiNodeInfo::Get just above the string " - Hidden"
    mpFlagsBuffer: Annotated[_Pointer[cEgSceneNodeFlags], 0x78]
    mpSceneNodeBuffer: Annotated[_Pointer[_Pointer[cEgSceneNode]], 0x88]
    mpTypeBuffer: Annotated[_Pointer[c_uint8], 0x98]
    mpMaterialPtrBuffer: Annotated[_Pointer[c_void_p], 0xC8]
    mpHandleToIndexBuffer: Annotated[_Pointer[c_int32], 0xD8]
    miCurFrame: Annotated[int, Field(c_int32, 0x210)]

    @function_hook("48 8B 81 ? ? ? ? 81 E2 ? ? ? ? 4C 8B C9")
    def SetRelativeTransform(
        self,
        this: "_Pointer[cEgSceneNodeData]",
        lHandle: basic.TkHandle,
        lValue: _Pointer[basic.cTkMatrix34],
    ): ...


@partial_struct
class cEgSceneManager(Structure):
    _total_size_ = 0x14460
    mData: Annotated[cEgSceneNodeData, 0x0]


class EgInstancedModelExtension:
    class cEgInstancedMeshNode(Structure):
        @static_function_hook("48 8B C4 44 89 40 ? 48 89 50 ? 48 89 48 ? 55 56 48 8D A8")
        @staticmethod
        def RenderAsync(
            lRenderQueue: c_void_p,  # cEgRenderQueueBuffer *
            lsShaderContext: _Pointer[basic.TkID0x10],
            liShaderContextVariant: Annotated[int, c_int32],
            leOrder: Annotated[int, c_uint8],
            lbUseLightweightGeometry: Annotated[bool, c_bool],
            lbRenderStereo: Annotated[bool, c_bool],
            lpFrustum: c_void_p,  # const cEgFrustum *
            lpThreadRenderData: _Pointer[cEgThreadableRenderCall],
        ): ...


@partial_struct
class cTkModelResourceRenderer(Structure):
    meSyncStage: Annotated[int, Field(c_int32, 0x498)]  # EModelResourceRendererSyncStage

    @function_hook("40 55 53 57 41 54 41 55 41 56 48 8D AC 24 ? ? ? ? 48 81 EC")
    def Update(
        self,
        this: "_Pointer[cTkModelResourceRenderer]",
        lfTimeStep: Annotated[float, c_float],
        lbForceAnimUpdate: Annotated[bool, c_bool],
        a4: c_uint64,  # unknown
    ): ...


class cGcPhotoModeUI(Structure):
    @static_function_hook("48 89 4C 24 ? 55 53 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 8B 49")
    @staticmethod
    def OnRenderScreenshotFinished(lpData: c_void_p):  # Unknown data type...
        ...


@partial_struct
class cTkClock(Structure):
    # This is unchanged since 4.13
    mu64StartTime: Annotated[int, Field(c_uint64, 0x0)]
    mu64CurrentTime: Annotated[int, Field(c_uint64, 0x8)]
    muLastWaitTicksFinish: Annotated[int, Field(c_uint64, 0x10)]
    mfTimeStep: Annotated[float, Field(c_float, 0x18)]
    mfTotalTime: Annotated[float, Field(c_float, 0x1C)]
    mfPrevTotalTime: Annotated[float, Field(c_float, 0x20)]
    mfSlowMotionFactor: Annotated[float, Field(c_float, 0x24)]
    muFrameCount: Annotated[int, Field(c_uint64, 0x28)]
    mbMinFrameTimeSynced: Annotated[bool, Field(c_bool, 0x30)]
    mbPaused: Annotated[bool, Field(c_bool, 0x31)]
    mbRealtime: Annotated[bool, Field(c_bool, 0x32)]


class cTkTimeManager(ContainerStruct):
    mLocalClock: Annotated[cTkClock, Pattern("48 8D 0D ? ? ? ? 44 88 35 ? ? ? ? C7 05")]
    mGlobalClock: Annotated[
        cTkClock,
        Pattern("48 8D 0D ? ? ? ? E8 ? ? ? ? B2 ? 48 8D 0D ? ? ? ? E8 ? ? ? ? 48 8D 0D ? ? ? ? 44 88 35"),
    ]
    mRealtimeClock: Annotated[
        cTkClock,
        Pattern("48 8D 0D ? ? ? ? E8 ? ? ? ? 48 8D 0D ? ? ? ? 44 88 35 ? ? ? ? 44 89 35"),
    ]


time_manager = cTkTimeManager()


class cEgModules(ContainerStruct):
    # Found in cEgModules::Initialise
    mgpSceneManager: Annotated[
        _Pointer[cEgSceneManager],
        Pattern(
            "48 89 05 ? ? ? ? E8 ? ? ? ? 48 39 3D ? ? ? ? 75 ? B9 ? ? ? ? E8 ? ? ? ? 48 85 C0 74 ? 48 89 78 "
            "? 40 88 78 ? 48 89 78 ? 40 88 78"
        ),
    ]
    mgpResourceManager: Annotated[
        _Pointer[cTkResourceManager],
        Pattern(
            "48 89 05 ? ? ? ? 48 39 3D ? ? ? ? 75 ? B9 ? ? ? ? E8 ? ? ? ? 48 85 C0 74 ? 48 8B C8 E8 ? ? ? ? "
            "48 8B F8"
        ),
    ]
    mgpRenderer: Annotated[
        _Pointer[cEgRenderer],
        Pattern("48 89 3D ? ? ? ? 48 83 C4 ? 5F C3 CC CC 40"),
    ]
    # These are just globals, but we'll store them here for now.
    mgMemoryManager: Annotated[cTkMemoryManager, Pattern("48 8D 0D ? ? ? ? E8 ? ? ? ? E8 ? ? ? ? 80 78")]
    gGameGui: Annotated[cGcNGuiGame, Pattern("48 8D 0D ? ? ? ? F3 0F 11 44 24 ? BA")]
    mBaseBuildingManager: Annotated[
        cGcBaseBuildingManager,
        Pattern("48 8D 0D ? ? ? ? E8 ? ? ? ? 48 8B 0D ? ? ? ? 41 0F 28 CA"),
    ]

    @static_function_hook("40 57 48 83 EC ? 33 FF 48 89 5C 24")
    @staticmethod
    def Initialise(): ...


engine_modules = cEgModules()


class cGcGalaxyVoxelCache(Structure):
    @function_hook("4C 8B DC 49 89 53 ? 55 57 41 54")
    def SpatialQueryFindNearestAlongDir(
        self,
        this: "_Pointer[cGcGalaxyVoxelCache]",
        lFromGCoord: _Pointer[cGcGalacticVoxelCoordinate],
        lvQueryStartPos: _Pointer[basic.cTkVector3],
        lvQueryTraceDir: _Pointer[basic.cTkVector3],
        lQueryResult: _Pointer[SolarQueryResult],
    ) -> c_char: ...


class cGcGalaxyMap(Structure):
    @partial_struct
    class Data(Structure):
        mVoxelCache: Annotated[cGcGalaxyVoxelCache, 0x50]
        mCurrentGalacticCoordinate: Annotated[cGcGalacticVoxelCoordinate, 0x1504]
        # Passed into SolarQueryResult::ComputeLightyearDistanceBetweenSolarSystems in
        # cGcGalaxyMap::Data::DoSolarPopup
        mInitialLocationAssignment: Annotated[SolarQueryResult, 0x1590]

        @function_hook(
            "40 55 53 41 54 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 48 89 B4 24 ? ? ? ? 48 8B F1 "
            "48 8B 0D"
        )
        def RenderNVG(
            self,
            this: "_Pointer[cGcGalaxyMap.Data]",
            a2: c_int64,  # cTkNGuiInput *
            a3: Annotated[bool, c_bool],
        ):
            pass

        @function_hook(
            "48 89 5C 24 ? 48 89 74 24 ? 55 57 41 54 41 55 41 56 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 44 0F "
            "B7 72"
        )
        def DoSolarPopup(
            self, this: "_Pointer[cGcGalaxyMap.Data]", lQueryResult: _Pointer[SolarQueryResult]
        ): ...

        @function_hook("40 55 53 56 57 41 57 48 8D AC 24 ? ? ? ? B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 4C 89 A4 24")
        def Update(self, this: "_Pointer[cGcGalaxyMap.Data]", lfTimeStep: Annotated[float, c_float]): ...


class cGcGalaxyMapUI(Structure):
    class SolarInfoPanel(Structure):
        @function_hook("48 89 4C 24 ? 55 53 41 54 41 55 48 8D AC 24 ? ? ? ? B8")
        def UpdatePanelUI(self, this: "_Pointer[cGcGalaxyMapUI.SolarInfoPanel]"): ...


class cGcPlayerWanted(Structure):
    @function_hook("48 8B C4 F3 0F 11 50 ? 48 89 50 ? 55 53")
    def Update(
        self,
        this: "_Pointer[cGcPlayerWanted]",
        lPlayerPos: _Pointer[basic.cTkVector3],
        lfTimeStep: Annotated[float, c_float],
    ): ...


class cGcFrontendPageClaimBase(Structure):
    @static_function_hook("48 89 5C 24 ? 48 89 54 24 ? 55 57 41 54 41 56")
    @staticmethod
    def DoBaseClaimOptions(
        lpPage: _Pointer[cGcFrontendPage],
        lapResponses: c_uint64,  # std::array<cGcNGuiLayer *,5> *
        leBaseType: Annotated[int, c_uint32],
        lbInsideOtherBase: Annotated[bool, c_bool],
        luiLegacyBase: _Pointer[c_uint16],
    ): ...


@partial_struct
class cTkComponent(Structure):
    _total_size_ = 0x30


@partial_struct
class cGcSimpleInteractionComponent(cTkComponent):
    mpData: Annotated[_Pointer[nmse.cGcSimpleInteractionComponentData], 0x30]
    mfActionTimer: Annotated[float, Field(c_float, 0x4C)]

    @function_hook(
        "48 8B C4 55 41 56 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 48 89 58 ? 4C 8B F1 48 89 70 ? 48 8D 8D"
    )
    def DoAction(self, this: "_Pointer[cGcSimpleInteractionComponent]"): ...


# Dummy values to copy and paste to make adding new things quicker...
# class name(Structure):
#     @function_hook("")
#     def method(self, this: "_Pointer[name]"):
#         ...
